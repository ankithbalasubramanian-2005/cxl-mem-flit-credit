# Release history

2026-11-22 — Initial artifact assembly with a new Git history, source-copy digests, nine archived runs, offline verification results, and paper sources.
