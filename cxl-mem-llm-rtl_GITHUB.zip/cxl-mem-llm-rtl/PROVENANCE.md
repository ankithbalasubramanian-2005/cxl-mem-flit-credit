# Provenance

The original tag name is **tb-v1-frozen**. The original commit hash is **unavailable**. The uploaded judge README contains tagging instructions, but the archives contain no original Git ref or commit object tying those bytes to that tag. The fresh release has its own history.

SOURCE_COPIES.json records the workspace-relative source and SHA-256 for each project file copied from the supplied artifacts. Recovered prompt fragments and project specification are identified in MISSING.md. The judge's own inventory covers each copied source under judge/tb, including its README. selected_rtl/selection.json links the module, archived iteration, and hash. For the source named llm_rtl/TAG/iterN/file, the release location is runs/TAG/iterations/iterN/file. Each of the 18 selected files was checked against that archived iteration.

The baseline arrived as two individually supplied files. S2 R2-dagger refers to the post-experiment repaired copy in improvements/repair_study. The nine candidate histories predate the baseline assessment and repair study. The optional loop replays stored responses.

The copy index uses paths to the supplied evidence workspace, not end-user runtime paths. The compatibility copies in original_project/ and synthesis_bundle/ support the archived drivers. The release wrapper, release metadata, and freshly executed evidence are identified separately. MANIFEST.sha256 covers regular delivery files, other than itself and Git's internal database. Fresh check logs retain runtime paths. No original RTL, test, log or prompt was redacted.
