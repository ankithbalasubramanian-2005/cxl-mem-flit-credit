ANSWER KEY - never place these files in an LLM prompt when reproducing the experiments.

These are the two baseline sources supplied by the project team. Matching hashes are recorded in improvements/baseline/provenance.json. The original sixteen judge mutants were unavailable.
