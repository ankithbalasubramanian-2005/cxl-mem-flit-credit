"""run_loop.py - self-correction loop v3.1.
Per-module repair: passing modules are frozen, every repair starts from the best
version of each module so far, and explicit protections against crashes."""
import argparse, fcntl, hashlib, json, re, shutil, sys
from pathlib import Path

from orchestrator.build_prompt import build_initial
from orchestrator.extractor import extract_code
from orchestrator.checks import check_all
from orchestrator.judge import run_judge
from orchestrator.feedback import format_feedback

FENCE = chr(96) * 3
MODULES = ("flit_packer", "credit_tracker")
DUT = {"flit_packer": "packer", "credit_tracker": "tracker"}
MINIMAL = ("Make the SMALLEST change that fixes the problems: keep every part that "
           "already works exactly as it is, and do not rewrite or restructure the "
           "module. Keep the module headers unchanged. Keep any explanation very short.")
TASK_JUDGE = ("# TASK\nFix the failing module(s) described above. " + MINIMAL +
              " Return only the modules marked as failing, each complete, in its own "
              + FENCE + "systemverilog code block.")
TASK_COMPILE = ("# TASK\nYour previous attempt did not compile or did not match the "
                "interface. Fix the problems described above. " + MINIMAL +
                " Return BOTH complete modules (flit_packer and credit_tracker), each "
                "in its own " + FENCE + "systemverilog code block.")


def code_block(paths):
    parts = []
    for m in MODULES:
        p = paths.get(m)
        if p and Path(p).exists():
            parts.append(FENCE + "systemverilog\n" + Path(p).read_text() + FENCE)
    return "\n".join(parts) or "(no usable code could be extracted)"


def module_scores(r):
    """Failure score per module from the judge summary (0 = passes)."""
    sc = {m: 0 for m in MODULES}
    for line in r.get("summary", "").splitlines():
        if not line.startswith("FAIL"):
            continue
        for m in MODULES:
            if f" {DUT[m]} " not in line:
                continue
            if "<build" in line or "could not run" in line:
                sc[m] += 100                      # does not even build
            elif "does not finish" in line:
                sc[m] += 30                       # hangs
            else:
                sc[m] += max(1, len(re.findall(r"'test_\w+'", line)))
    return sc


def prompt_after_judge(initial, base, status, worse):
    lines = []
    for m in MODULES:
        sc, fb = status[m]
        if sc == 0:
            lines.append(f"## {m}: PASSES all tests. Do not change it and do not "
                         f"include it in your reply.")
            continue
        txt = f"## {m}: FAILS ({sc} failing-test score)\n{fb}"
        if m in worse:
            wsc, wfb = worse[m]
            txt += (f"\n\nNOTE: your most recent attempt at this module was WORSE "
                    f"(score {wsc} versus {sc} for the version above), so it was "
                    f"discarded. Do not repeat that change. Its first problems were:\n"
                    f"{wfb[:700]}")
        lines.append(txt)
    return "\n\n".join([initial,
                        "# YOUR CURRENT VERSION OF EACH MODULE\n" + code_block(base),
                        "# RESULTS OF THE AUTOMATED TESTBENCH\n" + "\n\n".join(lines),
                        TASK_JUDGE])


def prompt_after_compile(initial, paths, stage, fb):
    return "\n\n".join([initial,
                        "# YOUR PREVIOUS ATTEMPT\n" + code_block(paths),
                        f"# FEEDBACK FROM THE AUTOMATED CHECKS (stage: {stage})\n" + fb,
                        TASK_COMPILE])


def make_fake(dirs):
    it = iter(dirs)
    def fake(prompt, repair=False):
        try:
            d = next(it)
        except StopIteration:
            raise RuntimeError("fake LLM ran out of replies")
        text = code_block({m: Path(d) / f"{m}.sv" for m in MODULES})
        return {"text": text, "model": "fake", "prompt_tokens": 0, "output_tokens": 0,
                "thought_tokens": 0, "finish_reason": "STOP", "seconds": 0.0}
    return fake


def run(strategy, tag, max_iter, seed, llm, stuck_limit=3):
    initial = build_initial(strategy)
    root = Path("llm_rtl") / tag
    log_path = Path("results") / f"{tag}.json"
    log, prompt, last_hash, repeats, status = [], initial, None, 0, "max_iter"
    best, shown, worse = {}, {}, {}

    for k in range(max_iter):
        rtl_dir = root / f"iter{k}"
        shutil.rmtree(rtl_dir, ignore_errors=True)
        rtl_dir.mkdir(parents=True)
        (rtl_dir / "prompt.txt").write_text(prompt)

        try:
            resp = llm(prompt, repair=(k > 0))
        except Exception as e:
            status = "llm_error"
            log.append({"iteration": k, "stage": "llm_error", "scores": None,
                        "feedback": str(e)[:400], "feedback_chars": 0,
                        "rtl_dir": str(rtl_dir)})
            log_path.write_text(json.dumps(log, indent=2))
            print(f"[{tag}] iter {k}: LLM ERROR, stopping cleanly: {str(e)[:200]}")
            break

        ex = extract_code(resp["text"], rtl_dir)
        returned = list(ex["saved"])
        for m in ex["missing"]:
            src = shown.get(m)
            if src and Path(src).exists():
                shutil.copy(src, rtl_dir / f"{m}.sv")
        missing = [m for m in MODULES if not (rtl_dir / f"{m}.sv").exists()]
        cut = "MAX_TOKENS" in str(resp.get("finish_reason", ""))

        scores = None
        if cut:
            stage = "truncated"
            fb = ("Your previous reply was cut off because it was too long. Write "
                  "the modules first, with no analysis or working notes.")
        elif missing or not returned:
            stage = "extraction"
            fb = ("Your reply did not contain any module inside a code block. Return "
                  "the failing module(s) in full, each in a systemverilog code block."
                  if not returned else
                  f"Your reply did not contain these modules inside code blocks: "
                  f"{missing}. Return them in full.")
        else:
            c = check_all(rtl_dir)
            if not c["ok"]:
                stage, fb = c["stage"], c["message"]
            else:
                r = run_judge(rtl_dir, seed)
                scores = module_scores(r)
                fbm = {m: format_feedback(r, only=m) for m in MODULES}
                if r["passed"]:
                    stage, fb = "pass", ""
                else:
                    stage, fb = "judge:" + r["category"], format_feedback(r)
                worse = {}
                for m in MODULES:
                    if m not in best or scores[m] < best[m][0]:
                        best[m] = (scores[m], rtl_dir / f"{m}.sv", fbm[m])
                    elif scores[m] > best[m][0]:
                        worse[m] = (scores[m], fbm[m])

        if stage != "pass" and returned and all(
                m in shown and Path(shown[m]).exists()
                and (rtl_dir / f"{m}.sv").read_text() == Path(shown[m]).read_text()
                for m in returned):
            fb = ("WARNING: your reply contained exactly the same code as the version "
                  "you were given, so nothing changed and the failures below are the "
                  "same. You must change the logic to fix them.\n\n" + fb)

        log.append({"iteration": k, "stage": stage, "scores": scores,
                    "model": resp["model"],
                    "prompt_tokens": resp["prompt_tokens"],
                    "output_tokens": resp["output_tokens"],
                    "thought_tokens": resp.get("thought_tokens"),
                    "finish_reason": resp.get("finish_reason"),
                    "llm_seconds": resp["seconds"], "feedback_chars": len(fb),
                    "rtl_dir": str(rtl_dir), "feedback": fb})
        log_path.write_text(json.dumps(log, indent=2))
        print(f"[{tag}] iter {k}: {stage}  scores={scores}  (feedback {len(fb)} chars)")

        if stage == "pass":
            status = "converged"
            break
        h = hashlib.md5(fb.encode()).hexdigest()
        repeats = repeats + 1 if h == last_hash else 1
        last_hash = h
        if repeats >= stuck_limit:
            status = "stuck"
            break

        if stage.startswith("judge") and best:
            base = {m: best[m][1] for m in MODULES}
            prompt = prompt_after_judge(initial, base,
                                        {m: (best[m][0], best[m][2]) for m in MODULES},
                                        worse)
            shown = base
        else:
            paths = {m: rtl_dir / f"{m}.sv" for m in MODULES}
            prompt = prompt_after_compile(initial, paths, stage, fb)
            shown = paths

    print(f"[{tag}] RESULT: {status} after {len(log)} iteration(s); "
          f"best scores: { {m: best[m][0] for m in best} }")
    return status


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--strategy", type=int, default=1)
    ap.add_argument("--tag")
    ap.add_argument("--max-iter", type=int, default=15)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--force", action="store_true", help="overwrite an existing tag")
    ap.add_argument("--fake", nargs="*", help="dry run: folders to use as LLM replies")
    a = ap.parse_args()

    Path("results").mkdir(exist_ok=True)
    lock = open("results/.run_lock", "w")
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        sys.exit("Another run is already running. Stop it first: pkill -f orchestrator.run_loop")

    if a.fake:
        llm, tag = make_fake(a.fake), a.tag or "dryrun"
    else:
        from orchestrator.llm_client import call_llm as llm, quota_remaining
        tag = a.tag or f"strategy{a.strategy}"
        if (Path("results") / f"{tag}.json").exists() and not a.force:
            sys.exit(f"Tag '{tag}' already has results. Use a new tag or --force.")
        rem = quota_remaining()
        print(f"Free requests left today: {rem}")
        if rem is not None and rem < a.max_iter and not a.force:
            sys.exit(f"Only {rem} requests left, below --max-iter {a.max_iter}. "
                     f"Wait for 00:00 UTC, lower --max-iter, or use --force.")
    run(a.strategy, tag, a.max_iter, a.seed, llm)