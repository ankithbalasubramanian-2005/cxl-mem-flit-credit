"""llm_client.py - OpenRouter free model, fixed settings, retries only."""
import os, time, random
import httpx
from dotenv import load_dotenv
from openai import OpenAI, APIStatusError, APIConnectionError, APITimeoutError

load_dotenv()

# ---- Fixed experiment settings: do not change between strategy runs ----
MODEL = os.environ["LLM_MODEL"]
TEMPERATURE = 0.2
MAX_OUTPUT_TOKENS = 60000
REASONING = {"enabled": False}          # first attempt: thinking off
REASONING_FIX = {"effort": "low"}       # repair attempts: thinking on
# ------------------------------------------------------------------------

MAX_RETRIES = 8
BASE_DELAY, MAX_DELAY = 5.0, 90.0
RETRY_CODES = (429, 500, 502, 503, 504)
KEY = os.environ["OPENROUTER_API_KEY"]

_client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=KEY,
                 timeout=900, max_retries=0)


def quota_remaining():
    """Free requests left today, or None if it cannot be read."""
    try:
        r = httpx.get("https://openrouter.ai/api/v1/key",
                      headers={"Authorization": "Bearer " + KEY}, timeout=30)
        return r.json()["data"]["free_model_daily_requests"]["remaining"]
    except Exception:
        return None


def _to_result(r, t0):
    ch = r.choices[0]
    finish = {"length": "MAX_TOKENS", "stop": "STOP"}.get(
        ch.finish_reason, str(ch.finish_reason))
    u = r.usage
    det = getattr(u, "completion_tokens_details", None) if u else None
    return {"text": ch.message.content or "", "model": MODEL,
            "prompt_tokens": getattr(u, "prompt_tokens", 0) or 0,
            "output_tokens": getattr(u, "completion_tokens", 0) or 0,
            "thought_tokens": getattr(det, "reasoning_tokens", 0) or 0,
            "finish_reason": finish, "seconds": round(time.time() - t0, 1)}


def call_llm(prompt: str, repair: bool = False) -> dict:
    reasoning = REASONING_FIX if repair else REASONING
    for attempt in range(MAX_RETRIES):
        t0 = time.time()
        try:
            r = _client.chat.completions.create(
                model=MODEL, temperature=TEMPERATURE, max_tokens=MAX_OUTPUT_TOKENS,
                messages=[{"role": "user", "content": prompt}],
                extra_body={"reasoning": reasoning})
            if r.choices:
                res = _to_result(r, t0)
                if res["finish_reason"] in ("STOP", "MAX_TOKENS"):
                    return res
                why = f"provider ended the reply early ({res['finish_reason']})"
            else:
                why = "empty response"
        except APIStatusError as e:
            if "free-models-per-day" in str(e):
                raise RuntimeError("Daily free limit reached. It resets at 00:00 UTC.") from e
            if e.status_code not in RETRY_CODES:
                raise
            why = f"{e.status_code}: {str(e)[:160]}"
        except (APIConnectionError, APITimeoutError) as e:
            why = type(e).__name__
        delay = min(BASE_DELAY * 2 ** attempt, MAX_DELAY) + random.random()
        print(f"[LLM] retry {attempt + 1}/{MAX_RETRIES} in {delay:.0f}s ({why})")
        time.sleep(delay)
    raise RuntimeError("LLM call failed after all retries")
