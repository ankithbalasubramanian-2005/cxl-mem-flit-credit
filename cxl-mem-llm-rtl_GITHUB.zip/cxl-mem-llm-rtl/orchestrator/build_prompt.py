"""Builds the initial prompt for a strategy from fixed source files."""
from pathlib import Path

P = Path("prompts")

def _read(path):
    # utf-8-sig removes the hidden BOM character at the start of the spec file
    return Path(path).read_text(encoding="utf-8-sig").strip()

def build_initial(strategy: int) -> str:
    parts = [
        _read(P / "role.md"),
        "# SPECIFICATION\n" + _read("docs/spec/design_spec_v2.md"),
        "# INTERFACE CONTRACT\n" + _read("docs/tb/interface_contract.md"),
        "# EXACT MODULE DECLARATIONS (keep these headers unchanged)\n"
        "systemverilog\n" + _read(P / "ports.sv") + "\n",
    ]
    extra = P / f"s{strategy}_extra.md"      # strategy 1 has no extra file
    if extra.exists():
        parts.append(_read(extra))
    parts.append(_read(P / "output_rules.md"))
    return "\n\n".join(parts)