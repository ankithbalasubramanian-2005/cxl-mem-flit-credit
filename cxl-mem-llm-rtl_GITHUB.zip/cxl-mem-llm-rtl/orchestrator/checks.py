"""checks.py - cheap pre-checks run before the (slow) judge."""
import re, subprocess, tempfile
from pathlib import Path

SKELETON = Path("prompts/ports.sv")
MODULES = ["flit_packer", "credit_tracker"]

PORT_RE = re.compile(
    r"\b(input|output|inout)\b\s+(?:(?:logic|wire|reg)\b\s*)?(\[[^\]]*\])?\s*(\w+)")
PARAM_RE = re.compile(r"\bparameter\b\s+(?:int\b|integer\b)?\s*(\w+)")


def _strip_comments(t):
    t = re.sub(r"/\*.*?\*/", "", t, flags=re.S)
    return re.sub(r"//[^\n]*", "", t)


def parse_header(text, module):
    """Return (params, ports) for a module, or None if no module header found."""
    text = _strip_comments(text)
    m = re.search(r"\bmodule\s+" + module + r"\b(.*?)\)\s*;", text, re.S)
    if not m:
        return None
    header = m.group(1)
    params = PARAM_RE.findall(header)
    ports = [(d, w, n) for d, w, n in PORT_RE.findall(header)]
    return params, ports


def run_iverilog(files, extra=()):
    cmd = ["iverilog", "-g2012", *extra, "-o", "/dev/null", *map(str, files)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    return p.returncode, (p.stdout + p.stderr).strip()


def make_wrapper():
    """Build a top module that connects every expected port by name."""
    skel = SKELETON.read_text()
    lines = ["module iface_check;", "  localparam MAX_CHUNKS = 8;"]
    inst = []
    for mod, tag in zip(MODULES, ["fp", "ct"]):
        _, ports = parse_header(skel, mod)
        conns = []
        for d, w, n in ports:
            lines.append(f"  wire {w} {tag}_{n};")
            conns.append(f".{n}({tag}_{n})")
        inst.append(f"  {mod} u_{tag} (" + ", ".join(conns) + ");")
    lines += inst + ["endmodule"]
    return "\n".join(lines) + "\n"


def explain_syntax(msg, rtl_dir, max_items=10):
    """Real compiler errors only: file, line, message and the code itself."""
    by_line, order, other = {}, [], []
    for l in msg.splitlines():
        if ": sorry:" in l or ": warning:" in l:
            continue                                  # harmless Icarus notes
        m = re.match(r"(\S+\.sv):(\d+):\s*(.*)", l)
        if not m:
            if l.strip():
                other.append(l.strip()[:200])         # e.g. "2 error(s) during elaboration."
            continue
        key = (Path(m.group(1)).name, int(m.group(2)))
        if key not in by_line:
            by_line[key] = []
            order.append(key)
        text = m.group(3).strip()
        if text not in by_line[key]:
            by_line[key].append(text)
    out = []
    for fname, n in order[:max_items]:
        src = (Path(rtl_dir) / fname).read_text().splitlines()
        out.append(f"{fname} line {n}: " + "; ".join(by_line[(fname, n)]))
        for k in (n - 1, n):
            if 1 <= k <= len(src):
                out.append(f"    {k:>4} | {src[k - 1].rstrip()[:160]}")
    if len(order) > max_items:
        out.append(f"... and {len(order) - max_items} more lines with errors")
    out.extend(other[:5])
    return "\n".join(out) if out else msg

DECL_HINT = ("\nNote: Icarus Verilog rejects a variable declaration that comes after "
             "an executable statement in the same begin-end block. Declare all local "
             "variables before the first statement of the block, or at module level.")

def check_all(rtl_dir):
    rtl = Path(rtl_dir)
    files = [rtl / f"{m}.sv" for m in MODULES]

    # 1. files exist
    gone = [f.name for f in files if not f.exists()]
    if gone:
        return {"ok": False, "stage": "files", "message": f"Missing files: {gone}"}

    # 2. syntax (only a failing compiler counts)
    rc, msg = run_iverilog(files)
    if rc != 0:
        text = explain_syntax(msg, rtl)
        if re.search(r"^\s+\d+ \|\s+(logic|reg|int|integer|bit)\b", text, re.M):
            text += DECL_HINT
        return {"ok": False, "stage": "syntax", "message": text[:3000]}

    # 3. names + directions
    skel = SKELETON.read_text()
    problems = []
    for mod, f in zip(MODULES, files):
        want = parse_header(skel, mod)
        got = parse_header(f.read_text(), mod)
        if got is None:
            problems.append(f"{mod}: could not read the module header "
                            f"(use the exact header given in the prompt)")
            continue
        wparams, wports = want
        gparams, gports = got
        wmap = {n: d for d, _, n in wports}
        gmap = {n: d for d, _, n in gports}
        for n in wmap:
            if n not in gmap:
                problems.append(f"{mod}: missing port '{n}'")
            elif gmap[n] != wmap[n]:
                problems.append(f"{mod}: port '{n}' must be {wmap[n]}, not {gmap[n]}")
        for n in gmap:
            if n not in wmap:
                problems.append(f"{mod}: extra port '{n}' (not allowed)")
        for p in wparams:
            if p not in gparams:
                problems.append(f"{mod}: missing parameter '{p}'")
    if problems:
        return {"ok": False, "stage": "interface", "message": "\n".join(problems)}

    # 4. widths (Icarus reports mismatches as warnings when connecting by name)
    with tempfile.TemporaryDirectory() as tmp:
        w = Path(tmp) / "iface_check.sv"
        w.write_text(make_wrapper())
        rc, msg = run_iverilog([*files, w], extra=["-Wall"])
    if rc != 0:
        return {"ok": False, "stage": "interface", "message": explain_syntax(msg, rtl)[:3000]}
    width_warn = [l for l in msg.splitlines() if "expects" in l and "bits" in l]
    if width_warn:
        return {"ok": False, "stage": "interface",
                "message": "Port width mismatch:\n" + "\n".join(width_warn)}

    return {"ok": True, "stage": "ok", "message": ""}
