import json, re, difflib, sys
from pathlib import Path

tag = sys.argv[1] if len(sys.argv) > 1 else "s1_run1b"
log = json.load(open(f"results/{tag}.json"))
root = Path("llm_rtl") / tag
prev = {}
for r in log:
    k, fb = r["iteration"], r["feedback"]
    changes = []
    for m in ("flit_packer", "credit_tracker"):
        f = root / f"iter{k}" / f"{m}.sv"
        t = f.read_text().splitlines() if f.exists() else []
        if m in prev:
            n = sum(1 for l in difflib.unified_diff(prev[m], t, lineterm="", n=0)
                    if l[:1] in "+-" and l[:3] not in ("+++", "---"))
            changes.append(f"{m} {n} changed lines")
        prev[m] = t
    nfail = [len(re.findall(r"'test_\w+'", l)) for l in fb.splitlines()
             if l.startswith("FAIL")]
    print(f"iter {k} [{r['stage']}] failing tests listed={nfail} | " + "; ".join(changes))
    lines = fb.splitlines()
    if not r["stage"].startswith("judge"):
        print("    ", lines[0][:120] if lines else "")
        continue
    for i, l in enumerate(lines):
        if "FIRST MISMATCH" in l:
            print("    ", l.strip()[:100])
            shown = 0
            for x in lines[i + 1:]:
                s = x.strip()
                if s.startswith("["):
                    break
                if not s or s.startswith(("inputs this cycle", "recent model events")):
                    continue
                print("        ", s[:100])
                shown += 1
                if shown == 3:
                    break
