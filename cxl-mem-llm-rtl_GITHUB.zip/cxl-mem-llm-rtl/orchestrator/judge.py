"""judge.py - runs the frozen testbench per block, with a time limit for each."""
import os, re, shutil, signal, subprocess, sys

RUNNING = re.compile(r"running tb\.tests\.\w+\.(test_\w+) \((\d+)/(\d+)\)")


def _run(rtl_dir, dut, seed, timeout):
    cmd = [sys.executable, "-u", "scripts/run_tests.py", "--rtl", str(rtl_dir),
           "--dut", dut, "--seed", str(seed)]
    if shutil.which("stdbuf"):                 # line-buffer so a killed run keeps its log
        cmd = ["stdbuf", "-oL", "-eL"] + cmd
    env = dict(os.environ, PYTHONUNBUFFERED="1")
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                         text=True, env=env, start_new_session=True)
    try:
        out, err = p.communicate(timeout=timeout)
        return p.returncode, (out or "") + "\n" + (err or ""), False
    except subprocess.TimeoutExpired:
        os.killpg(p.pid, signal.SIGKILL)       # also kills the simulator it started
        out, err = p.communicate()
        return None, (out or "") + "\n" + (err or ""), True


def run_judge(rtl_dir, seed=1234, timeout=180):
    outs, sums, rcs, hung = [], [], [], []
    for dut in ("packer", "tracker"):
        rc, out, to = _run(rtl_dir, dut, seed, timeout)
        out = "\n".join(l for l in out.splitlines() if "sorry:" not in l)
        outs.append(out)
        if to:
            hung.append(dut)
            ms = RUNNING.findall(out)
            where = (f" while running {ms[-1][0]} (test {ms[-1][1]} of {ms[-1][2]})"
                     if ms else "")
            sums.append(f"FAIL  {dut}  simulation does not finish{where}: no result "
                        f"within {timeout}s. Typical causes: a combinational loop (a "
                        f"signal that depends on itself through assign or always_comb) "
                        f"or a loop that never ends.")
            continue
        rcs.append(rc)
        sm = re.search(r"=+ SUMMARY =+(.*)", out, re.S)
        if sm:
            sums += [l for l in sm.group(1).splitlines()
                     if l.startswith(("PASS", "FAIL"))]
        elif rc != 0:
            sums.append(f"FAIL  {dut}  the testbench could not run")

    output = "\n".join(outs)
    summary = "\n".join(sums)
    mism = re.findall(r"^.*FIRST MISMATCH.*(?:\n[ \t]+.*)*", output, re.M)
    asserts = re.findall(r"^.*AssertionError.*$", output, re.M)
    passed = (not hung) and all(rc == 0 for rc in rcs)

    if passed:
        category = "pass"
    elif mism:
        category = "mismatch"
    elif hung:
        category = "timeout"
    elif asserts:
        category = "assertion"
    else:
        category = "other"

    return {"passed": passed, "category": category,
            "returncode": 0 if passed else 1, "mismatches": mism,
            "assertions": asserts, "summary": summary,
            "tail": summary or "\n".join(output.strip().splitlines()[-25:]),
            "output": output}
