
"""Pulls flit_packer and credit_tracker out of an LLM reply and saves them."""
import re
from pathlib import Path

REQUIRED = ["flit_packer", "credit_tracker"]
FENCE = chr(96) * 3          # three backticks, built in code so they can't get lost

def extract_code(reply: str, out_dir) -> dict:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "raw_reply.txt").write_text(reply)          # always keep the evidence

    # A code block = FENCE + optional language word + newline + code + FENCE
    pattern = FENCE + r"[\w+-]*[ \t]*\n(.*?)" + FENCE
    blocks = re.findall(pattern, reply, re.S)
    code = "\n".join(blocks) if blocks else reply      # no fences? search the whole reply

    found = {}
    for text in (code, reply):             # fall back to the whole reply
        for m in re.finditer(r"\bmodule\s+(\w+)\b.*?\bendmodule\b", text, re.S):
            name = m.group(1)
            if name in REQUIRED and name not in found:
                found[name] = m.group(0).strip() + "\n"
    for m in re.finditer(r"\bmodule\s+(\w+)\b.*?\bendmodule\b", code, re.S):
        name = m.group(1)
        if name in REQUIRED and name not in found:
            found[name] = m.group(0).strip() + "\n"

    for name, text in found.items():
        (out / f"{name}.sv").write_text(text)

    missing = [n for n in REQUIRED if n not in found]
    return {"ok": not missing, "missing": missing, "saved": sorted(found)}

