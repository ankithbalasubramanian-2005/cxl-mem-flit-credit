"""feedback.py - turns a judge result into a short message for the LLM."""
import re

TS = re.compile(r"^\s*\d+(?:\.\d+)?\s*[a-z]{2}\s+(?:ERROR|WARNING|INFO|DEBUG|CRITICAL)\b")
PREFIX = re.compile(r"^\s*\S+\s+\w+\s+\S+\s+")
FIELD = re.compile(r"^\s*([\w.]+)\s+expected\s+(\S+)\s+got\s+(\S+)")
OUTP = re.compile(r"^\s*output\s+(\w+):\s+expected\s+(\S+)\s+got\s+(\S+)")
MAX_LINE = 250
MAX_PER_BLOCK = 3
MAX_FIELDS = 14
MAX_TOTAL = 9000

X_NOTE = ("Note: 'got X' means the output is unknown (undriven) in simulation: "
          "usually a register or signal that is never reset, or is not assigned "
          "on every path of a combinational block.")


def _entry(lines, i):
    block = [PREFIX.sub("", lines[i]).strip()]
    for nxt in lines[i + 1:]:
        if TS.match(nxt):
            break
        if nxt.strip():
            block.append("  " + nxt.strip())
    return block


def _all_entries(out):
    """Every 'FIRST MISMATCH' log entry (one per failing test): (block name, lines)."""
    lines, res = out.splitlines(), []
    for i, l in enumerate(lines):
        if "FIRST MISMATCH" in l and TS.match(l):      # skips traceback copies
            m = re.search(r"\[(\w+)\[", l)
            res.append((m.group(1) if m else "block", _entry(lines, i)))
    return res


def _signature(key, block):
    outs = tuple(sorted(l.split(":")[0].replace("output", "").strip()
                        for l in block if l.strip().startswith("output ")))
    fields, grab = [], False
    for l in block:
        if "field differences" in l:
            grab = True
            continue
        if grab:
            tok = l.split()
            if not tok or tok[0] in ("inputs", "recent"):
                break
            fields.append(tok[0])
    return (key, outs, tuple(fields[:3]))


def mismatch_blocks(entries):
    """Up to MAX_PER_BLOCK different mismatches per block, from different tests."""
    per_block, seen, blocks = {}, set(), []
    for key, block in entries:
        if per_block.get(key, 0) >= MAX_PER_BLOCK:
            continue
        sig = _signature(key, block)
        if sig in seen:
            continue
        seen.add(sig)
        per_block[key] = per_block.get(key, 0) + 1
        blocks.append(block)
    return blocks


def field_summary(entries, key):
    """Every field/output that differed in any failing test of this block."""
    seen = {}
    for k, b in entries:
        if k != key:
            continue
        for l in b[1:]:
            m = FIELD.match(l) or OUTP.match(l)
            if not m or m.group(1) == "flit_out":
                continue
            name, exp, got = m.groups()
            e = seen.setdefault(name, [exp, got, 0])
            e[2] += 1
    if not seen:
        return ""
    rows = [f"  {n}: expected {e[0]}, got {e[1]}  (in {e[2]} failing tests)"
            for n, e in list(seen.items())[:MAX_FIELDS]]
    return (f"All fields/outputs that differed across the failing tests of {key} "
            f"(each failing test stops at its first difference, so this list "
            f"shows many separate bugs; fix all of them):\n" + "\n".join(rows))


def _clean(block):
    has_fields = any("field differences" in l for l in block)
    return [l[:MAX_LINE] for l in block
            if not (has_fields and l.strip().startswith("output flit_out:"))]


def format_feedback(r, only=None):
    """only = 'flit_packer' or 'credit_tracker' limits the message to that module."""
    dut = {"flit_packer": "packer", "credit_tracker": "tracker"}.get(only)
    entries = _all_entries(r.get("output", ""))
    parts = []
    if r.get("summary"):
        failed = [l[:400] for l in r["summary"].splitlines()
                  if l.startswith("FAIL") and (dut is None or f" {dut} " in l)]
        if failed:
            parts.append("Failing test groups:\n" + "\n".join(failed))

    keys = [only] if only else ["flit_packer", "credit_tracker"]
    for key in keys:
        s = field_summary(entries, key)
        if s:
            parts.append(s)

    blocks = mismatch_blocks([e for e in entries if not only or e[0] == only])
    if blocks:
        text = "\n\n".join("\n".join(_clean(b)) for b in blocks)
        parts.append("Example mismatches with full detail (cycle, inputs):\n" + text)
        if re.search(r"got X\b", text):
            parts.append(X_NOTE)
    elif only is None and r.get("assertions"):
        parts.append("Failed rule check:\n" +
                     "\n".join(PREFIX.sub("", a).strip()[:MAX_LINE]
                               for a in r["assertions"][:3]))
    elif only is None and not parts:
        parts.append(r.get("tail", "")[-1500:])

    return "\n\n".join(parts)[:MAX_TOTAL]