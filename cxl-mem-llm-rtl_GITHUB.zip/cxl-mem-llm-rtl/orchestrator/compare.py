import json, sys
from pathlib import Path

TAGS = sys.argv[1:] or ["s1_v32_run1", "s2_final_run1", "s3_final_run1"]
rows = []
for tag in TAGS:
    log = json.load(open(f"results/{tag}.json"))
    stages, best = {}, {"flit_packer": None, "credit_tracker": None}
    for r in log:
        s = r["stage"].split(":")[0]
        stages[s] = stages.get(s, 0) + 1
        for m in best:
            v = (r.get("scores") or {}).get(m)
            if v is not None and (best[m] is None or v < best[m]):
                best[m] = v
    conv = bool(log) and log[-1]["stage"] == "pass"
    pt = sum(r.get("prompt_tokens") or 0 for r in log)
    ot = sum(r.get("output_tokens") or 0 for r in log)
    mins = sum(r.get("llm_seconds") or 0 for r in log) / 60
    rows.append(f"| {tag} | {'Converged' if conv else 'Not converged'} | {len(log)} | "
                f"{best['flit_packer']} | {best['credit_tracker']} | "
                f"{stages.get('judge',0)}/{stages.get('syntax',0)+stages.get('interface',0)}/"
                f"{stages.get('extraction',0)+stages.get('truncated',0)+stages.get('llm_error',0)} | "
                f"{pt/1000:.0f}k / {ot/1000:.0f}k | {mins:.0f} |")
head = ("| Run | Outcome | Iterations | Best packer score | Best tracker score | "
        "Judge / compile / no-code iterations | Tokens in / out | LLM minutes |\n"
        "|---|---|---|---|---|---|---|---|")
out = head + "\n" + "\n".join(rows)
print(out)
Path("results/comparison.md").write_text(out + "\n")
