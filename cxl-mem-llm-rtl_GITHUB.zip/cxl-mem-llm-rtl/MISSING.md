# Missing original materials

| Item | Consequence |
|---|---|
| Original Git objects / ref for tb-v1-frozen | The name is documented in the judge README. Its original commit hash could not be verified. The release commit is a different identifier. |
| Original judge Makefile, tests/model/, scripts/run_tests.py, scripts/make_mutants.py, scripts/run_mutants.py and the original 16 mutant RTL sources | The original make targets and historical mutation score cannot be independently replayed. The uploaded cocotb tests and Python models can be run with the later driver. |
| docs/test_plan.md and docs/mutation_report.md | The testbench README mentions both. Neither was in the supplied source set. |
| orchestrator/summarize_runs.py and demo_strategies.py | The archived summary tables and demo output are present. |
| Original standalone prompt component and specification files with independent upstream hashes | The evidence package's restored components are included. The archived per-iteration prompts are the primary record. |
| Failed synthesis outputs | Nine of the 36 original configurations stop before the stat.json and ltp.txt commands. Their script, input, error logs and status are preserved. |
| Manuscript file under the requested alternate paper title | The supplied TeX/PDF is titled “Verification-Guided Evaluation of LLM-Generated CXL.mem Link-Layer RTL.” Its bytes are preserved. |

The live loop's original judging step needs scripts/run_tests.py and its original support files. The package does not offer a fully equivalent fresh live run until those files are restored.
