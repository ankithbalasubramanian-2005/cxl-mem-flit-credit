"""THE single place where DUT port names are defined (R5).

Logical name (used everywhere in the testbench)  ->  RTL port name.
If an RTL variant uses different names, change ONLY this file.
Contract: docs/tb/interface_contract.md
"""

FLIT_PACKER = {
    "module": "flit_packer",
    "clock": "clk",
    "inputs": {
        "rst_n": "rst_n",
        "msg_valid": "msg_valid",
        "msg_kind": "msg_kind",
        "msg_opcode": "msg_opcode",
        "msg_addr": "msg_addr",
        "msg_tag": "msg_tag",
        "msg_poison": "msg_poison",
        "msg_byte_en": "msg_byte_en",
        "msg_data": "msg_data",
        "chunks_ovr_en": "chunks_ovr_en",
        "chunks_ovr": "chunks_ovr",
        "crd_req_field": "crd_req_field",
        "crd_data_field": "crd_data_field",
        "crd_rsp_field": "crd_rsp_field",
        "force_llcrd": "force_llcrd",
        "flit_ready": "flit_ready",
    },
    "outputs": {
        "msg_ready": "msg_ready",
        "crd_taken": "crd_taken",
        "flit_valid": "flit_valid",
        "flit_out": "flit_out",
        "flit_is_control": "flit_is_control",
        "flit_is_alldata": "flit_is_alldata",
    },
}

CREDIT_TRACKER = {
    "module": "credit_tracker",
    "clock": "clk",
    "inputs": {
        "rst_n": "rst_n",
        "tx_send": "tx_send",
        "rx_crd_valid": "rx_crd_valid",
        "rx_reqcrd": "rx_reqcrd",
        "rx_datacrd": "rx_datacrd",
        "rx_rspcrd": "rx_rspcrd",
        "buf_free": "buf_free",
        "crd_taken": "crd_taken",
    },
    "outputs": {
        "tx_credits_0": "tx_credits_0",
        "tx_credits_1": "tx_credits_1",
        "can_send": "can_send",
        "crd_req_field": "crd_req_field",
        "crd_data_field": "crd_data_field",
        "crd_rsp_field": "crd_rsp_field",
        "crd_pending": "crd_pending",
        "pend_0": "pend_0",
        "pend_1": "pend_1",
    },
}

# Top-level parameter names
PARAM_DIRECTION = "DIRECTION"
