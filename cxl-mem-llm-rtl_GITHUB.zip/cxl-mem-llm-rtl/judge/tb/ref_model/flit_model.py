"""Golden model of the CXL 2.0 CXL.mem flit packer (Link Layer, Ch. 4).

Pure Python. Derived only from docs/spec/design_spec_v2.md and the CXL 2.0
spec (Rev 2.0 v1.0, Oct 26 2020). No cocotb, no RTL access.

Bit numbering (CXL §4.2.5 p.141): slot bit = 8*byte + bit, LSB of a field in
the lowest position. Flit byte n -> flit bit [8n+7:8n] (v2 §8.2).
"""

# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------
FLIT_BITS = 528            # CXL §4.2.2 p.119
SLOT_BITS = 128            # 4 slots x 16B, CXL §4.2.2 p.119
CRC_LSB = 512              # CRC = flit[527:512], v2 §8.2
CRC_VALUE = 0x0000         # v2 §8.3 (D3)
MAX_CHUNKS = 8             # v2 §8.10

M2S = 0                    # DIRECTION parameter values, v2 §8.9
S2M = 1

# Slot format selector encodings, CXL Table 50 p.123
SEL_G0 = 0b000             # data chunk (Slots 1-3)
SEL_H3 = 0b011             # S2M: DRS header + NDR
SEL_H4 = 0b100             # M2S: RwD header
SEL_H5 = 0b101             # M2S: Req
SEL_EMPTY_G = {M2S: 0b100, S2M: 0b101}   # empty generic slot: G4 / G5, v2 §8.4 (D6d)
SEL_EMPTY_H0 = {M2S: SEL_H5, S2M: SEL_H3}  # slot 0 with no message, v2 §8.4 (D6e)

# Opcodes, CXL Tables 30, 36, 39, 42
OP_MEMRD = 0b0001
OP_MEMRDDATA = 0b0010
OP_MEMWR = 0b0001
OP_MEMWRPTL = 0b0010
OP_CMP = 0b000
OP_MEMDATA = 0b000

# Fixed field values, v2 §5 #2-#5
META_FIELD_NOOP = 0b11     # CXL Table 31
META_VALUE = 0b00
SNP_NOOP = 0b000           # CXL Table 33
LD_ID = 0
DEVLOAD_LIGHT = 0b00       # CXL Table 40
TC = 0

# LLCRD, CXL Table 53/54, Figure 78
LLCTRL_LLCRD = 0b0000
LLCRD_SUBTYPE = 0b0000     # v2 §8.5 (D5)
CTL_FMT = 0b000

# Credit encoding, CXL Table 48 p.122
CREDIT_VALUES = (0, 1, 2, 4, 8, 16, 32, 64)
CRD_MEM = 0b1000           # bit 3 = 1 -> CXL.mem


def mask(n):
    return (1 << n) - 1


def put(word, value, lsb, width):
    """Insert value[width-1:0] at word[lsb+width-1:lsb]."""
    assert 0 <= value < (1 << width), (value, width)
    return word | (value << lsb)


def get(word, lsb, width):
    return (word >> lsb) & mask(width)


# ----------------------------------------------------------------------------
# Credit encoding helpers (CXL Table 48; v2 §5 #12)
# ----------------------------------------------------------------------------
def greedy_code(pending):
    """Largest representable credit count <= pending, as Table 48 code [2:0]."""
    if pending <= 0:
        return 0
    v = min(pending, 64)
    code = 0
    for c, val in enumerate(CREDIT_VALUES):
        if val <= v:
            code = c
    return code


def credit_value(code3):
    return CREDIT_VALUES[code3 & 0b111]


def decode_credit_field(field):
    """Return (is_cxl_mem, count) for a 4-bit credit field."""
    return bool(field & CRD_MEM), credit_value(field & 0b111)


# ----------------------------------------------------------------------------
# Header (CXL Table 45; bit positions from Figures 53/54/66; v2 §1.1)
# ----------------------------------------------------------------------------
HDR = {  # name: (lsb, width)
    "Type": (0, 1), "RV": (1, 1), "Ak": (2, 1), "BE": (3, 1), "Sz": (4, 1),
    "Slot0": (5, 3), "Slot1": (8, 3), "Slot2": (11, 3), "Slot3": (14, 3),
    "RSVD": (17, 3), "RspCrd": (20, 4), "ReqCrd": (24, 4), "DataCrd": (28, 4),
}


def pack_header(type_, be, sz, slots, rsp, req, data):
    w = 0
    w = put(w, type_, HDR["Type"][0], 1)
    w = put(w, be, HDR["BE"][0], 1)
    w = put(w, sz, HDR["Sz"][0], 1)
    for i, s in enumerate(slots):
        w = put(w, s, HDR[f"Slot{i}"][0], 3)
    w = put(w, rsp, HDR["RspCrd"][0], 4)
    w = put(w, req, HDR["ReqCrd"][0], 4)
    w = put(w, data, HDR["DataCrd"][0], 4)
    return w  # Ak = 0 (v2 §5 #11), RV = RSVD = 0 (CXL p.120)


# ----------------------------------------------------------------------------
# Messages: field lists (name, width) in slot bit order, LSB first.
# Offsets are absolute Slot-0 bit positions.
# ----------------------------------------------------------------------------
# M2S Req, CXL Table 29 / Figure 54 (H5); v2 §2.3
REQ_FIELDS = [("Valid", 1), ("MemOpcode", 4), ("SnpType", 3), ("MetaField", 2),
              ("MetaValue", 2), ("Tag", 16), ("Address_51_5", 47), ("TC", 2),
              ("LD_ID", 4), ("RSVD", 6)]
# M2S RwD, CXL Table 35 / Figure 53 (H4); v2 §2.4
RWD_FIELDS = [("Valid", 1), ("MemOpcode", 4), ("SnpType", 3), ("MetaField", 2),
              ("MetaValue", 2), ("Tag", 16), ("Address_51_6", 46), ("Poison", 1),
              ("TC", 2), ("LD_ID", 4), ("RSVD", 6)]
# S2M DRS, CXL Table 41 / Figure 66; v2 §2.5
DRS_FIELDS = [("Valid", 1), ("Opcode", 3), ("MetaField", 2), ("MetaValue", 2),
              ("Tag", 16), ("Poison", 1), ("LD_ID", 4), ("DevLoad", 2), ("RSVD", 9)]
# S2M NDR, CXL Table 38 / Figure 66; v2 §2.6
NDR_FIELDS = [("Valid", 1), ("Opcode", 3), ("MetaField", 2), ("MetaValue", 2),
              ("Tag", 16), ("LD_ID", 4), ("DevLoad", 2)]

MSG_LSB = 32        # message starts after the 32-bit header (v2 §8.1)
DRS_LSB = 32        # H3 first position  [71:32]
NDR_LSB = 72        # H3 second position [101:72]


def _pack_fields(fields, values, lsb):
    w, pos = 0, lsb
    for name, width in fields:
        w = put(w, values.get(name, 0), pos, width)
        pos += width
    return w


def unpack_fields(fields, word, lsb):
    out, pos = {}, lsb
    for name, width in fields:
        out[name] = get(word, pos, width)
        pos += width
    return out


def field_width_sum(fields):
    return sum(w for _, w in fields)


def pack_req(opcode, addr, tag):
    return _pack_fields(REQ_FIELDS, {
        "Valid": 1, "MemOpcode": opcode & 0xF, "SnpType": SNP_NOOP,
        "MetaField": META_FIELD_NOOP, "MetaValue": META_VALUE, "Tag": tag,
        "Address_51_5": (addr >> 5) & mask(47), "TC": TC, "LD_ID": LD_ID}, MSG_LSB)


def pack_rwd(opcode, addr, tag, poison):
    return _pack_fields(RWD_FIELDS, {
        "Valid": 1, "MemOpcode": opcode & 0xF, "SnpType": SNP_NOOP,
        "MetaField": META_FIELD_NOOP, "MetaValue": META_VALUE, "Tag": tag,
        "Address_51_6": (addr >> 6) & mask(46), "Poison": poison, "TC": TC,
        "LD_ID": LD_ID}, MSG_LSB)


def pack_drs(opcode, tag, poison):
    return _pack_fields(DRS_FIELDS, {
        "Valid": 1, "Opcode": opcode & 0x7, "MetaField": META_FIELD_NOOP,
        "MetaValue": META_VALUE, "Tag": tag, "Poison": poison, "LD_ID": LD_ID,
        "DevLoad": DEVLOAD_LIGHT}, DRS_LSB)


def pack_ndr(opcode, tag):
    return _pack_fields(NDR_FIELDS, {
        "Valid": 1, "Opcode": opcode & 0x7, "MetaField": META_FIELD_NOOP,
        "MetaValue": META_VALUE, "Tag": tag, "LD_ID": LD_ID,
        "DevLoad": DEVLOAD_LIGHT}, NDR_LSB)


# ----------------------------------------------------------------------------
# Message description
# ----------------------------------------------------------------------------
class Msg:
    """One message as offered on the msg_* inputs."""

    def __init__(self, kind, opcode, addr=0, tag=0, poison=0, byte_en=0,
                 data=0, chunks_ovr=None):
        self.kind = kind            # DIR0: 0 Req / 1 RwD ; DIR1: 0 NDR / 1 DRS
        self.opcode = opcode
        self.addr = addr
        self.tag = tag
        self.poison = poison
        self.byte_en = byte_en
        self.data = data            # MAX_CHUNKS*128-bit integer
        self.chunks_ovr = chunks_ovr

    def __repr__(self):
        ov = "" if self.chunks_ovr is None else f", chunks_ovr={self.chunks_ovr}"
        return (f"Msg(kind={self.kind}, op={self.opcode:#x}, addr={self.addr:#x}, "
                f"tag={self.tag:#06x}, poison={self.poison}{ov})")


def data_chunk(data, i):
    return get(data, 128 * i, 128)


def msg_is_data(direction, kind):
    return kind == 1        # RwD (DIR0) or DRS (DIR1)


def msg_be(direction, msg):
    # BE=1 only for M2S RwD MemWrPtl (CXL Table 36/47; §4.2.2 p.121; v2 §8.7)
    return int(direction == M2S and msg.kind == 1 and (msg.opcode & 0xF) == OP_MEMWRPTL)


def msg_chunks(direction, msg):
    """Ordered list of 128-bit chunks that follow the header (v2 §8.12)."""
    if msg.chunks_ovr is not None:
        return [data_chunk(msg.data, i) for i in range(msg.chunks_ovr)]
    if not msg_is_data(direction, msg.kind):
        return []
    chunks = [data_chunk(msg.data, i) for i in range(4)]      # Sz=1: 4 chunks
    if msg_be(direction, msg):
        chunks.append(msg.byte_en & mask(64))                  # Figure 57 BE chunk
    return chunks


def slot0_message(direction, msg):
    """Message bits of Slot 0 (above the header) and the Slot0 selector."""
    if direction == M2S:
        if msg.kind == 0:
            return pack_req(msg.opcode, msg.addr, msg.tag), SEL_H5
        return pack_rwd(msg.opcode, msg.addr, msg.tag, msg.poison), SEL_H4
    if msg.kind == 1:
        return pack_drs(msg.opcode, msg.tag, msg.poison), SEL_H3
    return pack_ndr(msg.opcode, msg.tag), SEL_H3


def assemble(slots, crc=CRC_VALUE):
    f = 0
    for k, s in enumerate(slots):
        f |= (s & mask(SLOT_BITS)) << (SLOT_BITS * k)
    return f | (crc << CRC_LSB)


def build_protocol_flit(direction, msg, chunks, crd):
    """Protocol flit: Slot 0 = header + optional message; Slots 1..3 = chunks or empty.

    crd = (req_field, data_field, rsp_field).
    """
    if msg is None:
        msg_bits, sel0, sz, be = 0, SEL_EMPTY_H0[direction], 0, 0
    else:
        msg_bits, sel0 = slot0_message(direction, msg)
        sz = int(msg_is_data(direction, msg.kind))
        be = msg_be(direction, msg)
    sels = [sel0]
    gslots = []
    for k in range(3):
        if k < len(chunks):
            sels.append(SEL_G0)
            gslots.append(chunks[k])
        else:
            sels.append(SEL_EMPTY_G[direction])
            gslots.append(0)
    req, data, rsp = crd
    hdr = pack_header(0, be, sz, sels, rsp, req, data)
    return assemble([hdr | msg_bits] + gslots)


def build_alldata_flit(chunks):
    assert len(chunks) == 4
    return assemble(chunks)       # Figure 47: no header


def build_llcrd_flit(crd):
    """LLCRD control flit, CXL Figure 78 / Table 54; v2 §8.5."""
    req, data, rsp = crd
    s0 = 0
    s0 = put(s0, 1, 0, 1)                    # T=1
    s0 = put(s0, CTL_FMT, 5, 3)
    s0 = put(s0, rsp, 20, 4)
    s0 = put(s0, req, 24, 4)
    s0 = put(s0, data, 28, 4)
    s0 = put(s0, LLCTRL_LLCRD, 32, 4)
    s0 = put(s0, LLCRD_SUBTYPE, 36, 4)
    return assemble([s0, 0, 0, 0])


# ----------------------------------------------------------------------------
# Cycle-level packer model (v2 §8.12)
# ----------------------------------------------------------------------------
PACKER_INPUTS = ("rst_n", "msg_valid", "msg_kind", "msg_opcode", "msg_addr",
                 "msg_tag", "msg_poison", "msg_byte_en", "msg_data",
                 "chunks_ovr_en", "chunks_ovr", "crd_req_field",
                 "crd_data_field", "crd_rsp_field", "force_llcrd", "flit_ready")
PACKER_OUTPUTS = ("msg_ready", "crd_taken", "flit_valid", "flit_out",
                  "flit_is_control", "flit_is_alldata")


def msg_from_inputs(inp):
    return Msg(kind=inp["msg_kind"], opcode=inp["msg_opcode"], addr=inp["msg_addr"],
               tag=inp["msg_tag"], poison=inp["msg_poison"],
               byte_en=inp["msg_byte_en"], data=inp["msg_data"],
               chunks_ovr=inp["chunks_ovr"] if inp["chunks_ovr_en"] else None)


class FlitPackerModel:
    def __init__(self, direction):
        assert direction in (M2S, S2M)
        self.direction = direction
        self.reset()

    def reset(self):
        self.flit_valid = 0
        self.flit_out = 0
        self.flit_is_control = 0
        self.flit_is_alldata = 0
        self.rem = []          # rollover chunks still to send
        self.lat = 0           # latched force_llcrd

    # -- combinational view -------------------------------------------------
    def _decide(self, inp):
        if not inp["rst_n"]:
            return "reset"
        if self.flit_valid and not inp["flit_ready"]:
            return "hold"
        if self.rem:
            return "roll"
        if self.lat or inp["force_llcrd"]:
            return "llcrd"
        if inp["msg_valid"]:
            return "msg"
        return "none"

    def outputs(self, inp):
        d = self._decide(inp)
        slot_free = inp["rst_n"] and (not self.flit_valid or inp["flit_ready"])
        msg_ready = int(bool(slot_free and not self.rem
                             and not (self.lat or inp["force_llcrd"])))
        crd_taken = int(d in ("llcrd", "msg") or (d == "roll" and len(self.rem) <= 3))
        return {"msg_ready": msg_ready, "crd_taken": crd_taken,
                "flit_valid": self.flit_valid, "flit_out": self.flit_out,
                "flit_is_control": self.flit_is_control,
                "flit_is_alldata": self.flit_is_alldata}

    # -- clock edge ------------------------------------------------------------
    def step(self, inp):
        """Advance one rising edge. Returns a description of the event (or None)."""
        d = self._decide(inp)
        crd = (inp["crd_req_field"], inp["crd_data_field"], inp["crd_rsp_field"])
        llcrd_eff = int(bool(self.lat or inp["force_llcrd"]))
        event = None
        if d == "reset":
            self.reset()
            return "reset"
        if d == "hold":
            self.lat = llcrd_eff
            return None
        if d == "none":
            self.flit_valid = 0
            self.flit_out = 0
            self.flit_is_control = 0
            self.flit_is_alldata = 0
            self.lat = llcrd_eff
            return None
        self.flit_valid = 1
        if d == "roll":
            if len(self.rem) > 3:                  # CXL §4.2.5: >3 -> all-data flit
                self.flit_out = build_alldata_flit(self.rem[:4])
                self.rem = self.rem[4:]
                self.flit_is_control, self.flit_is_alldata = 0, 1
                event = ("alldata", None)
            else:                                  # 1..3 -> Slots 1.. of next flit
                self.flit_out = build_protocol_flit(self.direction, None, self.rem, crd)
                event = ("rollover_flit", len(self.rem))
                self.rem = []
                self.flit_is_control, self.flit_is_alldata = 0, 0
            self.lat = llcrd_eff
        elif d == "llcrd":
            self.flit_out = build_llcrd_flit(crd)
            self.flit_is_control, self.flit_is_alldata = 1, 0
            self.lat = 0
            event = ("llcrd", None)
        else:  # msg
            m = msg_from_inputs(inp)
            chunks = msg_chunks(self.direction, m)
            self.flit_out = build_protocol_flit(self.direction, m, chunks[:3], crd)
            self.rem = chunks[3:]
            self.flit_is_control, self.flit_is_alldata = 0, 0
            self.lat = llcrd_eff
            event = ("msg", m, len(chunks))
        return event


# ----------------------------------------------------------------------------
# Readable decoding (used by the scoreboard's mismatch report)
# ----------------------------------------------------------------------------
def decode_flit(flit, direction, is_control=None, is_alldata=None):
    """Return an ordered dict of named fields for a flit (best-effort view)."""
    out = {}
    if is_alldata:
        for k in range(4):
            out[f"chunk{k}"] = hex(get(flit, 128 * k, 128))
        out["CRC"] = hex(get(flit, CRC_LSB, 16))
        return out
    s0 = get(flit, 0, 128)
    for name, (lsb, w) in HDR.items():
        out[f"hdr.{name}"] = get(s0, lsb, w)
    if is_control or get(s0, 0, 1) == 1:
        out["ctl.CTL_FMT"] = get(s0, 5, 3)
        out["ctl.LLCTRL"] = get(s0, 32, 4)
        out["ctl.SubType"] = get(s0, 36, 4)
        out["ctl.bytes5_7"] = get(s0, 40, 24)
        out["ctl.Payload"] = hex(get(s0, 64, 64))
    elif direction == M2S:
        fields = REQ_FIELDS if out["hdr.Slot0"] == SEL_H5 else RWD_FIELDS
        tag = "req" if out["hdr.Slot0"] == SEL_H5 else "rwd"
        for k, v in unpack_fields(fields, s0, MSG_LSB).items():
            out[f"{tag}.{k}"] = v
        out["slot0.pad"] = get(s0, 119, 9)
    else:
        for k, v in unpack_fields(DRS_FIELDS, s0, DRS_LSB).items():
            out[f"drs.{k}"] = v
        for k, v in unpack_fields(NDR_FIELDS, s0, NDR_LSB).items():
            out[f"ndr.{k}"] = v
        out["slot0.pad"] = get(s0, 102, 26)
    for k in range(1, 4):
        out[f"slot{k}"] = hex(get(flit, 128 * k, 128))
    out["CRC"] = hex(get(flit, CRC_LSB, 16))
    return out
