"""Golden reference model (pure Python, no cocotb, no RTL access)."""
