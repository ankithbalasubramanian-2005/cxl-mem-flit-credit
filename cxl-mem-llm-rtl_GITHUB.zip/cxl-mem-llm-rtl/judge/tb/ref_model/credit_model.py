"""Golden model of the CXL.mem credit tracker (Link Layer, CXL 2.0 Ch. 4).

Pure Python, derived from docs/spec/design_spec_v2.md §1.2, §1.3, §4, §8.8,
§8.12 and CXL 2.0 Tables 48/49, §4.2.2 p.121, §4.2.7 p.146.
"""
from .flit_model import CRD_MEM, credit_value, greedy_code, M2S, S2M

TRACKER_INPUTS = ("rst_n", "tx_send", "rx_crd_valid", "rx_reqcrd", "rx_datacrd",
                  "rx_rspcrd", "buf_free", "crd_taken")
TRACKER_OUTPUTS = ("tx_credits_0", "tx_credits_1", "can_send", "crd_req_field",
                   "crd_data_field", "crd_rsp_field", "crd_pending", "pend_0",
                   "pend_1")

# Which received field credits which sender channel (CXL Table 49; v2 §1.3, §8.12)
#   DIR0 host  : ch0 = M2S Req <- ReqCrd,  ch1 = M2S RwD <- DataCrd
#   DIR1 device: ch0 = S2M NDR <- RspCrd,  ch1 = S2M DRS <- DataCrd
RX_FIELD_FOR_SENDER = {M2S: ("rx_reqcrd", "rx_datacrd"),
                       S2M: ("rx_rspcrd", "rx_datacrd")}
# Which outgoing field carries which pending-return channel
#   DIR0 host  : pend0 = S2M NDR -> RspCrd,  pend1 = S2M DRS -> DataCrd, ReqCrd reserved
#   DIR1 device: pend0 = M2S Req -> ReqCrd,  pend1 = M2S RwD -> DataCrd, RspCrd reserved
TX_FIELD_FOR_PENDING = {M2S: ("crd_rsp_field", "crd_data_field"),
                        S2M: ("crd_req_field", "crd_data_field")}


class CreditTrackerModel:
    def __init__(self, direction, rx_depth=16, credit_max=64, pend_max=255):
        assert direction in (M2S, S2M)
        self.direction = direction
        self.rx_depth = rx_depth
        self.credit_max = credit_max       # sender counters saturate, §4.2.7 p.146
        self.pend_max = pend_max
        self.reset()

    def reset(self):
        self.snd = [0, 0]                  # filled by returned credits (v2 §8.8)
        self.pend = [self.rx_depth] * 2    # Rx starts with its buffer count (§4.2.7)

    def fields(self):
        f = {"crd_req_field": 0, "crd_data_field": 0, "crd_rsp_field": 0}
        for i, name in enumerate(TX_FIELD_FOR_PENDING[self.direction]):
            f[name] = CRD_MEM | greedy_code(self.pend[i])   # bit3 = 1 always (D4a)
        return f

    def outputs(self, inp=None):
        out = {"tx_credits_0": self.snd[0], "tx_credits_1": self.snd[1],
               "can_send": int(self.snd[0] != 0) | (int(self.snd[1] != 0) << 1),
               "crd_pending": int(self.pend[0] != 0 or self.pend[1] != 0),
               "pend_0": self.pend[0], "pend_1": self.pend[1]}
        out.update(self.fields())
        return out

    def step(self, inp):
        if not inp["rst_n"]:
            self.reset()
            return
        f = self.fields()
        new_snd = []
        for i in range(2):
            add = 0
            if inp["rx_crd_valid"]:
                field = inp[RX_FIELD_FOR_SENDER[self.direction][i]]
                if field & CRD_MEM:                    # CXL.cache credits discarded
                    add = credit_value(field & 0b111)
            dec = 1 if ((inp["tx_send"] >> i) & 1) and self.snd[i] != 0 else 0
            new_snd.append(min(self.snd[i] - dec + add, self.credit_max))
        new_pend = []
        for i in range(2):
            taken = 0
            if inp["crd_taken"]:
                taken = credit_value(f[TX_FIELD_FOR_PENDING[self.direction][i]] & 0b111)
            free = (inp["buf_free"] >> i) & 1
            new_pend.append(min(self.pend[i] - taken + free, self.pend_max))
        self.snd, self.pend = new_snd, new_pend
