"""credit_tracker tests: group B (credit tracking) and E2 (random).

Lock-step with the golden model every cycle, plus explicit spec checks.
Test IDs match docs/tb/test_plan.md.
"""
import os
import random

import cocotb

from tb import dut_ports
from tb.harness.clock_reset import apply_reset, start_clock
from tb.harness.coverage import Coverage
from tb.harness.lockstep import LockstepBench
from tb.ref_model.credit_model import CreditTrackerModel
from tb.ref_model.flit_model import M2S, S2M
from tb.tests.packer_env import seed_rng

RX_DEPTH = int(os.environ.get("TB_RX_DEPTH", "16"))
COV = Coverage("credit_tracker")
COV.define("sender_level", ["0", "1-15", "16-63", "64"])
COV.define("pending_level", ["0", "1-15", "16-254", "255"])
COV.define("greedy_code", [str(c) for c in range(1, 8)])

IDLE = dict(rst_n=1, tx_send=0, rx_crd_valid=0, rx_reqcrd=0, rx_datacrd=0,
            rx_rspcrd=0, buf_free=0, crd_taken=0)


def _lvl_snd(v):
    return "0" if v == 0 else "64" if v >= 64 else "16-63" if v >= 16 else "1-15"


def _lvl_pend(v):
    return "0" if v == 0 else "255" if v >= 255 else "16-254" if v >= 16 else "1-15"


class TrackerEnv:
    def __init__(self, dut):
        self.dut = dut
        self.dir = int(os.environ.get("TB_DIRECTION", "0"))
        self.model = CreditTrackerModel(self.dir, rx_depth=RX_DEPTH)
        self.bench = LockstepBench(dut, dut_ports.CREDIT_TRACKER, self.model,
                                   f"credit_tracker[D{self.dir}]", self.dir)
        self.bench.listeners.append(self._cov)
        # names of the received fields that credit sender ch0 / ch1 (Table 49)
        self.rx0, self.rx1 = (("rx_reqcrd", "rx_datacrd") if self.dir == M2S
                              else ("rx_rspcrd", "rx_datacrd"))
        # outgoing fields for pending ch0 / ch1, and the reserved one
        if self.dir == M2S:
            self.tx0, self.tx1, self.txr = "crd_rsp_field", "crd_data_field", "crd_req_field"
        else:
            self.tx0, self.tx1, self.txr = "crd_req_field", "crd_data_field", "crd_rsp_field"

    def _cov(self, inp, out, event):
        if not inp.get("rst_n", 1) or "X" in out.values():
            return
        for k in ("tx_credits_0", "tx_credits_1"):
            COV.hit("sender_level", _lvl_snd(out[k]))
        for k in ("pend_0", "pend_1"):
            COV.hit("pending_level", _lvl_pend(out[k]))
        if inp["crd_taken"]:
            for k in (self.tx0, self.tx1):
                if out[k] & 7:
                    COV.hit("greedy_code", str(out[k] & 7))

    async def start(self):
        start_clock(self.dut, dut_ports.CREDIT_TRACKER)
        await apply_reset(self.bench, idle=IDLE)

    async def cycle(self, **kw):
        return await self.bench.cycle(dict(IDLE, **kw))


@cocotb.test()
async def test_b1_reset_values(dut):
    env = TrackerEnv(dut)
    await env.start()
    o = await env.cycle()
    assert o["tx_credits_0"] == 0 and o["tx_credits_1"] == 0 and o["can_send"] == 0, \
        "sender counters start at 0 (credits arrive from the receiver, §4.2.7)"
    assert o["pend_0"] == RX_DEPTH and o["pend_1"] == RX_DEPTH, \
        "Rx return counters start at the buffer count (§4.2.7 p.146)"
    assert o[env.tx0] == 0b1000 | 5 and o[env.tx1] == 0b1000 | 5, "16 credits = code 101"
    assert o[env.txr] == 0, "reserved field = 0000"
    assert o["crd_pending"] == 1


@cocotb.test()
async def test_b2_return_and_consume(dut):
    env = TrackerEnv(dut)
    await env.start()
    await env.cycle(rx_crd_valid=1, **{env.rx0: 0b1011, env.rx1: 0b1010})   # +4, +2
    o = await env.cycle()
    assert (o["tx_credits_0"], o["tx_credits_1"]) == (4, 2)
    await env.cycle(tx_send=0b01)
    await env.cycle(tx_send=0b11)
    o = await env.cycle()
    assert (o["tx_credits_0"], o["tx_credits_1"]) == (2, 1)
    # simultaneous consume + return
    await env.cycle(tx_send=0b11, rx_crd_valid=1, **{env.rx0: 0b1001, env.rx1: 0b1001})
    o = await env.cycle()
    assert (o["tx_credits_0"], o["tx_credits_1"]) == (2, 1)


@cocotb.test()
async def test_b3_exhaustion_no_underflow(dut):
    env = TrackerEnv(dut)
    await env.start()
    await env.cycle(rx_crd_valid=1, **{env.rx0: 0b1010})       # 2 credits on ch0
    for _ in range(2):
        await env.cycle(tx_send=0b01)
    o = await env.cycle()
    assert o["tx_credits_0"] == 0 and (o["can_send"] & 1) == 0, "sender blocked at 0"
    for _ in range(3):
        await env.cycle(tx_send=0b11)                           # illegal sends at 0
    o = await env.cycle()
    assert o["tx_credits_0"] == 0 and o["tx_credits_1"] == 0, "no underflow"


@cocotb.test()
async def test_b4_saturation_no_overflow(dut):
    env = TrackerEnv(dut)
    await env.start()
    for _ in range(3):
        await env.cycle(rx_crd_valid=1, **{env.rx0: 0b1111, env.rx1: 0b1110})  # +64, +32
    o = await env.cycle()
    assert o["tx_credits_0"] == 64 and o["tx_credits_1"] == 64, "saturate at CREDIT_MAX"
    for _ in range(300):
        await env.cycle(buf_free=0b11)
    o = await env.cycle()
    assert o["pend_0"] == 255 and o["pend_1"] == 255, "pending saturates at 255"


@cocotb.test()
async def test_b5_greedy_drain(dut):
    env = TrackerEnv(dut)
    await env.start()
    # drain the initial RX_DEPTH credits, then build pend0 = 3 and pend1 = 100
    while env.model.pend != [0, 0]:
        await env.cycle(crd_taken=1)
    for i in range(100):
        await env.cycle(buf_free=0b11 if i < 3 else 0b10)
    seq0, seq1 = [], []
    for _ in range(4):
        o = await env.cycle(crd_taken=1)
        seq0.append(o[env.tx0])
        seq1.append(o[env.tx1])
    assert seq0 == [0b1010, 0b1001, 0b1000, 0b1000], f"3 -> 2 then 1, got {seq0}"
    assert seq1 == [0b1111, 0b1110, 0b1011, 0b1000], f"100 -> 64, 32, 4, got {seq1}"
    # 15 -> 8, 4, 2, 1 (exercises every small code, incl. code 100 = 8 credits)
    for _ in range(15):
        await env.cycle(buf_free=0b01)
    seq = [(await env.cycle(crd_taken=1))[env.tx0] for _ in range(5)]
    assert seq == [0b1100, 0b1011, 0b1010, 0b1001, 0b1000], f"15 -> 8,4,2,1, got {seq}"


@cocotb.test()
async def test_b6_channel_mapping(dut):
    env = TrackerEnv(dut)
    await env.start()
    # each received field alone
    for name in ("rx_reqcrd", "rx_datacrd", "rx_rspcrd"):
        await env.cycle(rst_n=0)
        await env.cycle(rx_crd_valid=1, **{name: 0b1001})
        o = await env.cycle()
        exp0 = 1 if name == env.rx0 else 0
        exp1 = 1 if name == env.rx1 else 0
        assert (o["tx_credits_0"], o["tx_credits_1"]) == (exp0, exp1), \
            f"{name} must credit only its Table-49 channel (DIRECTION={env.dir})"
    # pending ch0 only -> only its outgoing field changes
    await env.cycle(rst_n=0)
    while env.model.pend != [0, 0]:
        await env.cycle(crd_taken=1)
    await env.cycle(buf_free=0b01)
    o = await env.cycle()
    assert o[env.tx0] == 0b1001 and o[env.tx1] == 0b1000 and o[env.txr] == 0


@cocotb.test()
async def test_b7_ignore_cache_and_reserved(dut):
    env = TrackerEnv(dut)
    await env.start()
    await env.cycle(rx_crd_valid=1, rx_reqcrd=0b0111, rx_datacrd=0b0111, rx_rspcrd=0b0111)
    o = await env.cycle()
    assert o["tx_credits_0"] == 0 and o["tx_credits_1"] == 0, "CXL.cache credits discarded"
    await env.cycle(rx_crd_valid=0, **{env.rx0: 0b1111})
    o = await env.cycle()
    assert o["tx_credits_0"] == 0, "fields ignored when rx_crd_valid=0"


@cocotb.test()
async def test_b8_select_bit(dut):
    env = TrackerEnv(dut)
    await env.start()
    for _ in range(40):
        o = await env.cycle(crd_taken=1)
        assert o[env.tx0] & 0b1000 and o[env.tx1] & 0b1000, "bit3 = 1 (CXL.mem), Table 48"
        assert o[env.txr] == 0


@cocotb.test()
async def test_e2_tracker_random(dut):
    env = TrackerEnv(dut)
    await env.start()
    rng, _ = seed_rng(dut, 202)
    for it in range(5):
        sub = rng.getrandbits(32)
        dut._log.info(f"E2 iteration {it}: sub-seed {sub}")
        r = random.Random(sub)
        p_free = r.choice([0.05, 0.3, 0.9])
        for _ in range(600):
            await env.cycle(
                rst_n=0 if r.random() < 0.003 else 1,
                tx_send=r.getrandbits(2) if r.random() < 0.5 else 0,
                rx_crd_valid=int(r.random() < 0.3),
                rx_reqcrd=r.getrandbits(4), rx_datacrd=r.getrandbits(4),
                rx_rspcrd=r.getrandbits(4),
                buf_free=(int(r.random() < p_free) | (int(r.random() < p_free) << 1)),
                crd_taken=int(r.random() < 0.2))


@cocotb.test()
async def test_zz_coverage(dut):
    env = TrackerEnv(dut)
    await env.start()
    dut._log.info("\n" + COV.report())
    assert not COV.missing(), f"coverage holes: {COV.missing()}"
