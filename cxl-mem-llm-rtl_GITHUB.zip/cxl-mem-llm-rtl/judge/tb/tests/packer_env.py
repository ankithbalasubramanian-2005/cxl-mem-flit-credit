"""Test environment for flit_packer: message source, flit sink, coverage hooks."""
import os

import cocotb

from tb import dut_ports
from tb.harness.clock_reset import apply_reset, start_clock
from tb.harness.coverage import Coverage
from tb.harness.lockstep import LockstepBench
from tb.ref_model import flit_model as fm

COV = Coverage("flit_packer")      # shared by all tests of one simulation run


def direction():
    return int(os.environ.get("TB_DIRECTION", "0"))


def opcodes_for(d):
    if d == fm.M2S:
        return [(0, fm.OP_MEMRD, "MemRd"), (0, fm.OP_MEMRDDATA, "MemRdData"),
                (1, fm.OP_MEMWR, "MemWr"), (1, fm.OP_MEMWRPTL, "MemWrPtl")]
    return [(0, fm.OP_CMP, "Cmp"), (1, fm.OP_MEMDATA, "MemData")]


def define_cov(d):
    COV.define("opcode", [n for _, _, n in opcodes_for(d)])
    COV.define("rollover_len", ["0", "1", "2", "3", ">3"])
    COV.define("llcrd_event", ["idle", "deferred_by_rollover", "priority_over_msg",
                               "latched_under_backpressure"])
    COV.define("backpressure", ["stall_cycle"])


def op_name(d, kind, opcode):
    for k, o, n in opcodes_for(d):
        if k == kind and o == opcode:
            return n
    return f"other({kind},{opcode})"


IDLE = dict(rst_n=1, msg_valid=0, msg_kind=0, msg_opcode=0, msg_addr=0, msg_tag=0,
            msg_poison=0, msg_byte_en=0, msg_data=0, chunks_ovr_en=0, chunks_ovr=0,
            crd_req_field=0, crd_data_field=0, crd_rsp_field=0, force_llcrd=0,
            flit_ready=1)


def msg_inputs(m):
    return dict(msg_valid=1, msg_kind=m.kind, msg_opcode=m.opcode, msg_addr=m.addr,
                msg_tag=m.tag, msg_poison=m.poison, msg_byte_en=m.byte_en,
                msg_data=m.data, chunks_ovr_en=int(m.chunks_ovr is not None),
                chunks_ovr=m.chunks_ovr or 0)


class PackerEnv:
    def __init__(self, dut):
        self.dut = dut
        self.dir = direction()
        define_cov(self.dir)
        self.model = fm.FlitPackerModel(self.dir)
        self.bench = LockstepBench(dut, dut_ports.FLIT_PACKER, self.model,
                                   f"flit_packer[D{self.dir}]", self.dir)
        self.queue = []          # messages waiting to be offered
        self.flits = []          # consumed flits: dicts
        self.accepted = []       # accepted messages
        self.crd = (0, 0, 0)     # credit fields driven to the packer
        self.bench.listeners.append(self._observe)

    async def start(self):
        start_clock(self.dut, dut_ports.FLIT_PACKER)
        await apply_reset(self.bench, idle=IDLE)

    def _observe(self, inp, out, event):
        if inp.get("rst_n", 1) and out.get("flit_valid") == 1 and inp["flit_ready"]:
            self.flits.append(dict(cycle=self.bench.cycle_no, flit=out["flit_out"],
                                   ctrl=out["flit_is_control"],
                                   alldata=out["flit_is_alldata"]))
        if event and event[0] == "msg":
            m, n = event[1], event[2]
            COV.hit("opcode", op_name(self.dir, m.kind, m.opcode))
            r = max(0, n - 3)
            COV.hit("rollover_len", ">3" if r > 3 else str(r))
        if event and event[0] == "llcrd":
            COV.hit("llcrd_event", "priority_over_msg" if inp["msg_valid"] else "idle")

    async def cycle(self, force_llcrd=0, flit_ready=1, rst_n=1, offer=True):
        inp = dict(IDLE, rst_n=rst_n, force_llcrd=force_llcrd, flit_ready=flit_ready)
        inp["crd_req_field"], inp["crd_data_field"], inp["crd_rsp_field"] = self.crd
        if offer and self.queue:
            inp.update(msg_inputs(self.queue[0]))
        # coverage of LLCRD situations, judged on the model state before the edge
        if force_llcrd and rst_n:
            if self.model.rem:
                COV.hit("llcrd_event", "deferred_by_rollover")
            if self.model.flit_valid and not flit_ready:
                COV.hit("llcrd_event", "latched_under_backpressure")
        if self.model.flit_valid and not flit_ready:
            COV.hit("backpressure", "stall_cycle")
        out = await self.bench.cycle(inp)
        if rst_n and inp["msg_valid"] and out["msg_ready"] == 1:
            self.accepted.append(self.queue.pop(0))
        if not rst_n:
            self.queue.clear()
        return out

    def busy(self):
        return bool(self.queue or self.model.rem or self.model.lat or self.model.flit_valid)

    async def drain(self, max_cycles=200, ready_fn=None):
        n = 0
        while self.busy():
            await self.cycle(flit_ready=ready_fn(n) if ready_fn else 1)
            n += 1
            assert n < max_cycles, "drain timeout: DUT/model did not finish"
        await self.cycle()

    async def send(self, msgs, ready_fn=None):
        self.queue.extend(msgs)
        await self.drain(ready_fn=ready_fn)


def rand_msg(rng, d, allow_ovr=True):
    kind, opcode, _ = rng.choice(opcodes_for(d))
    ovr = rng.randint(0, fm.MAX_CHUNKS) if (allow_ovr and rng.random() < 0.3) else None
    return fm.Msg(kind=kind, opcode=opcode, addr=rng.getrandbits(52),
                  tag=rng.getrandbits(16), poison=rng.getrandbits(1),
                  byte_en=rng.getrandbits(64), data=rng.getrandbits(128 * fm.MAX_CHUNKS),
                  chunks_ovr=ovr)


def seed_rng(dut, salt):
    """Per-test RNG from the run seed (TB_SEED, set by scripts/run_tests.py).

    Reproduce a failure with: python scripts/run_tests.py --seed <TB_SEED>
    """
    import random
    base = int(os.environ.get("TB_SEED", str(cocotb.RANDOM_SEED)))
    seed = (base * 1000003 + salt) & 0xFFFFFFFF
    dut._log.info(f"RANDOM SEED: run seed TB_SEED={base}, test seed={seed}")
    return random.Random(seed), seed
