"""flit_packer tests: groups A (packing), C (rollover), D (LLCRD), E (random).

Every test runs in lock-step with the golden model (all outputs compared every
cycle). Most tests ALSO assert decoded fields against expectations written
directly from the spec, so they stay meaningful independent of the model.
Test IDs match docs/tb/test_plan.md.
"""
import cocotb

from tb.ref_model import flit_model as fm
import random

from tb.tests.packer_env import COV, PackerEnv, opcodes_for, rand_msg, seed_rng

M2S, S2M = fm.M2S, fm.S2M


def dec(env, f):
    return fm.decode_flit(f["flit"], env.dir, f["ctrl"], f["alldata"])


def chunks_data(vals):
    return sum(v << (128 * i) for i, v in enumerate(vals))


def check_common_header(h, sz, be):
    assert h["hdr.Type"] == 0, "protocol flit must have Type=0 (Table 46)"
    assert h["hdr.RV"] == 0 and h["hdr.RSVD"] == 0, "reserved header bits must be 0"
    assert h["hdr.Ak"] == 0, "Ak tied to 0 (simplification #11)"
    assert h["hdr.Sz"] == sz, f"Sz expected {sz}"
    assert h["hdr.BE"] == be, f"BE expected {be}"
    assert h["CRC"] == "0x0", "CRC tied to 0 (D3)"


def expected_layout(n):
    """Per spec §4.2.5 rule table: list of (kind, chunk indices) for n chunks."""
    seq = [("hdr", list(range(min(n, 3))))]
    rem = list(range(3, n))
    while len(rem) > 3:
        seq.append(("alldata", rem[:4]))
        rem = rem[4:]
    if rem:
        seq.append(("roll", rem))
    return seq


def check_layout(env, flits, n, chunk_vals):
    exp = expected_layout(n)
    assert len(flits) == len(exp), f"{n} chunks: expected {len(exp)} flits, got {len(flits)}"
    empty_g = fm.SEL_EMPTY_G[env.dir]
    for f, (kind, idx) in zip(flits, exp):
        d = dec(env, f)
        if kind == "alldata":
            assert f["alldata"] == 1 and f["ctrl"] == 0, "all-data flit flags"
            for k in range(4):
                assert d[f"chunk{k}"] == hex(chunk_vals[idx[k]]), f"all-data chunk {k}"
            continue
        assert f["alldata"] == 0 and f["ctrl"] == 0
        for k in range(1, 4):
            sel = d[f"hdr.Slot{k}"]
            if k - 1 < len(idx):
                assert sel == fm.SEL_G0, f"Slot{k} must be G0 (data)"
                assert d[f"slot{k}"] == hex(chunk_vals[idx[k - 1]]), f"Slot{k} chunk"
            else:
                assert sel == empty_g, f"Slot{k} must be empty"
                assert d[f"slot{k}"] == "0x0"


# ===========================================================================
# Group A
# ===========================================================================
@cocotb.test()
async def test_a1_m2s_req_opcodes(dut):
    env = PackerEnv(dut)
    await env.start()
    if env.dir != M2S:
        dut._log.info("A1 is M2S-only: skipped for DIRECTION=1")
        return
    for op in (fm.OP_MEMRD, fm.OP_MEMRDDATA):
        env.flits.clear()
        addr, tag = 0xA_BCDE_F012_3460 | 0x20, 0x1357 + op
        await env.send([fm.Msg(kind=0, opcode=op, addr=addr, tag=tag)])
        assert len(env.flits) == 1, "a Req has no data: exactly one flit"
        d = dec(env, env.flits[0])
        check_common_header(d, sz=0, be=0)
        assert d["hdr.Slot0"] == fm.SEL_H5, "M2S Req uses H5 (Table 50)"
        for k in (1, 2, 3):
            assert d[f"hdr.Slot{k}"] == fm.SEL_EMPTY_G[M2S]
        assert d["req.Valid"] == 1
        assert d["req.MemOpcode"] == op, "Table 30 encoding"
        assert d["req.SnpType"] == 0 and d["req.MetaField"] == 0b11
        assert d["req.MetaValue"] == 0 and d["req.TC"] == 0 and d["req.LD_ID"] == 0
        assert d["req.RSVD"] == 0 and d["slot0.pad"] == 0
        assert d["req.Address_51_5"] == addr >> 5
        assert d["req.Tag"] == tag


@cocotb.test()
async def test_a2_m2s_rwd_opcodes(dut):
    env = PackerEnv(dut)
    await env.start()
    if env.dir != M2S:
        dut._log.info("A2 is M2S-only: skipped for DIRECTION=1")
        return
    vals = [0x1111, 0x2222, 0x3333, 0x4444]
    for op, be in ((fm.OP_MEMWR, 0), (fm.OP_MEMWRPTL, 1)):
        env.flits.clear()
        m = fm.Msg(kind=1, opcode=op, addr=0x1234_5678_9AC0, tag=0xBEEF, poison=1,
                   byte_en=0x0123_4567_89AB_CDEF, data=chunks_data(vals))
        await env.send([m])
        d0 = dec(env, env.flits[0])
        check_common_header(d0, sz=1, be=be)
        assert d0["hdr.Slot0"] == fm.SEL_H4, "M2S RwD uses H4 (Table 50)"
        assert d0["rwd.Valid"] == 1 and d0["rwd.MemOpcode"] == op, "Table 36 encoding"
        assert d0["rwd.Poison"] == 1 and d0["rwd.Tag"] == 0xBEEF
        assert d0["rwd.Address_51_6"] == m.addr >> 6
        all_chunks = vals + ([m.byte_en] if be else [])
        check_layout(env, env.flits, len(all_chunks), all_chunks)
        if be:
            d1 = dec(env, env.flits[1])
            assert d1["slot2"] == hex(m.byte_en), "BE chunk (Fig. 57) is the last data slot"


@cocotb.test()
async def test_a3_req_vs_rwd_addr_bit5(dut):
    env = PackerEnv(dut)
    await env.start()
    if env.dir != M2S:
        dut._log.info("A3 is M2S-only: skipped for DIRECTION=1")
        return
    base = 0xF_0F0F_0F0F_0F00
    for addr in (base | 0x20, base | 0x3F, base):
        env.flits.clear()
        await env.send([fm.Msg(kind=0, opcode=fm.OP_MEMRD, addr=addr, tag=1)])
        d = dec(env, env.flits[0])
        assert d["req.Address_51_5"] & 1 == (addr >> 5) & 1, "Req must carry Addr[5]"
    rwd_flits = []
    for addr in (base | 0x20, base):          # differ only in bit 5
        env.flits.clear()
        await env.send([fm.Msg(kind=1, opcode=fm.OP_MEMWR, addr=addr, tag=2,
                               data=chunks_data([9, 9, 9, 9]))])
        rwd_flits.append(env.flits[0]["flit"])
        d = dec(env, env.flits[0])
        assert d["rwd.Address_51_6"] == addr >> 6
        assert d["rwd.Poison"] == 0, "Addr[5] must not leak into Poison (bit 106)"
    assert rwd_flits[0] == rwd_flits[1], "RwD flit must not depend on Addr[5]"


@cocotb.test()
async def test_a4_s2m_ndr_drs(dut):
    env = PackerEnv(dut)
    await env.start()
    if env.dir != S2M:
        dut._log.info("A4 is S2M-only: skipped for DIRECTION=0")
        return
    env.flits.clear()
    await env.send([fm.Msg(kind=0, opcode=fm.OP_CMP, tag=0xC0DE, addr=0xFFFF)])
    assert len(env.flits) == 1
    d = dec(env, env.flits[0])
    check_common_header(d, sz=0, be=0)
    assert d["hdr.Slot0"] == fm.SEL_H3, "S2M uses H3 (D6c)"
    assert d["ndr.Valid"] == 1 and d["ndr.Opcode"] == fm.OP_CMP and d["ndr.Tag"] == 0xC0DE
    assert d["ndr.MetaField"] == 0b11 and d["ndr.DevLoad"] == 0 and d["ndr.LD_ID"] == 0
    assert all(d[f"drs.{k}"] == 0 for k, _ in fm.DRS_FIELDS), "unused DRS position must be all 0"
    vals = [0xA1, 0xA2, 0xA3, 0xA4]
    env.flits.clear()
    await env.send([fm.Msg(kind=1, opcode=fm.OP_MEMDATA, tag=0x0BAD, poison=1,
                           data=chunks_data(vals))])
    d = dec(env, env.flits[0])
    check_common_header(d, sz=1, be=0)
    assert d["drs.Valid"] == 1 and d["drs.Opcode"] == fm.OP_MEMDATA
    assert d["drs.Tag"] == 0x0BAD and d["drs.Poison"] == 1 and d["drs.RSVD"] == 0
    assert all(d[f"ndr.{k}"] == 0 for k, _ in fm.NDR_FIELDS), "unused NDR position must be all 0"
    check_layout(env, env.flits, 4, vals)


@cocotb.test()
async def test_a5_worked_example_memrd(dut):
    """Design spec v2 §6, reproduced field by field."""
    env = PackerEnv(dut)
    await env.start()
    tid, addr = 0x00A5, 0x0000_0012_3456_7880
    if env.dir == M2S:
        env.crd = (0b0000, 0b1001, 0b1000)      # host returns 1 DRS credit
        await env.send([fm.Msg(kind=0, opcode=fm.OP_MEMRD, addr=addr, tag=tid)])
        d = dec(env, env.flits[0])
        check_common_header(d, sz=0, be=0)
        assert d["hdr.Slot0"] == 0b101
        assert d["req.MemOpcode"] == 0b0001 and d["req.SnpType"] == 0b000
        assert d["req.MetaField"] == 0b11 and d["req.Address_51_5"] == addr >> 5
        assert d["req.Tag"] == tid and d["req.LD_ID"] == 0
        assert d["hdr.DataCrd"] == 0b1001 and d["hdr.ReqCrd"] == 0
    else:
        env.crd = (0b1001, 0b0000, 0b0000)      # device returns 1 Req credit
        vals = [0xD0, 0xD1, 0xD2, 0xD3]
        await env.send([fm.Msg(kind=1, opcode=fm.OP_MEMDATA, tag=tid, data=chunks_data(vals))])
        assert len(env.flits) == 2, "64B DRS = H3 flit + rollover-1 flit (not all-data)"
        d0, d1 = dec(env, env.flits[0]), dec(env, env.flits[1])
        assert d0["hdr.Slot0"] == fm.SEL_H3 and d0["hdr.Sz"] == 1
        assert d0["drs.Opcode"] == 0b000 and d0["drs.Tag"] == tid
        assert d0["hdr.ReqCrd"] == 0b1001
        assert d1["hdr.Slot0"] == fm.SEL_H3 and d1["drs.Valid"] == 0 and d1["ndr.Valid"] == 0
        assert d1["slot1"] == hex(0xD3) and env.flits[1]["alldata"] == 0


@cocotb.test()
async def test_a6_back_to_back(dut):
    env = PackerEnv(dut)
    await env.start()
    rng, _ = seed_rng(dut, 6)
    msgs = [rand_msg(rng, env.dir, allow_ovr=False) for _ in range(30)]
    env.queue.extend(msgs)
    first = env.bench.cycle_no
    await env.drain()
    assert env.accepted == msgs, "every message accepted, in order"
    n_flits = sum(len(expected_layout(len(fm.msg_chunks(env.dir, m)))) for m in msgs)
    assert len(env.flits) == n_flits
    # with flit_ready=1 there must be no idle gap: one flit per cycle
    assert env.flits[-1]["cycle"] - env.flits[0]["cycle"] == n_flits - 1, "gap in output"
    assert env.flits[0]["cycle"] - first <= 2


@cocotb.test()
async def test_a7_backpressure(dut):
    env = PackerEnv(dut)
    await env.start()
    rng, _ = seed_rng(dut, 7)
    msgs = [rand_msg(rng, env.dir) for _ in range(40)]
    await env.send(msgs, ready_fn=lambda n: rng.random() < 0.4)
    assert env.accepted == msgs, "no message may be dropped under backpressure"
    n_flits = sum(len(expected_layout(len(fm.msg_chunks(env.dir, m)))) for m in msgs)
    assert len(env.flits) == n_flits, "every flit consumed exactly once"


@cocotb.test()
async def test_a8_reset_mid_traffic(dut):
    env = PackerEnv(dut)
    await env.start()
    m = fm.Msg(kind=1, opcode=fm.OP_MEMWR if env.dir == M2S else fm.OP_MEMDATA,
               data=chunks_data(range(1, 9)), chunks_ovr=8, tag=5)
    env.queue.append(m)
    await env.cycle()          # accepted, rollover of 5 pending
    await env.cycle()          # all-data flit
    await env.cycle(rst_n=0)   # reset in the middle of the rollover
    await env.cycle(rst_n=0)
    out = await env.cycle()
    assert out["flit_valid"] == 0, "after reset no flit may be presented"
    env.flits.clear()
    await env.send([fm.Msg(kind=0, opcode=fm.OP_MEMRD if env.dir == M2S else fm.OP_CMP, tag=6)])
    assert len(env.flits) == 1, "after reset the old rollover must be gone"


@cocotb.test()
async def test_a9_header_fields_and_credits(dut):
    env = PackerEnv(dut)
    await env.start()
    rng, _ = seed_rng(dut, 9)
    for _ in range(25):
        env.crd = (rng.getrandbits(4), rng.getrandbits(4), rng.getrandbits(4))
        env.flits.clear()
        m = rand_msg(rng, env.dir, allow_ovr=False)
        await env.send([m])
        d = dec(env, env.flits[0])
        assert (d["hdr.ReqCrd"], d["hdr.DataCrd"], d["hdr.RspCrd"]) == env.crd, \
            "credit fields must be copied from crd_*_field into the header"
        assert d["hdr.RV"] == 0 and d["hdr.Ak"] == 0 and d["hdr.RSVD"] == 0
        assert d["CRC"] == "0x0"


# ===========================================================================
# Group C — rollover (CXL §4.2.5)
# ===========================================================================
async def _rollover_case(dut, n_values):
    env = PackerEnv(dut)
    await env.start()
    for n in n_values:
        for kind in (1, 0):
            vals = [0x100 * (kind + 1) + i for i in range(fm.MAX_CHUNKS)]
            op = [o for k, o, _ in opcodes_for(env.dir) if k == kind][0]
            env.flits.clear()
            await env.send([fm.Msg(kind=kind, opcode=op, tag=n, data=chunks_data(vals),
                                   chunks_ovr=n)])
            check_layout(env, env.flits, n, vals)


@cocotb.test()
async def test_c1_rollover_0(dut):
    await _rollover_case(dut, [0, 1, 2, 3])


@cocotb.test()
async def test_c2_rollover_1(dut):
    await _rollover_case(dut, [4])


@cocotb.test()
async def test_c3_rollover_2(dut):
    await _rollover_case(dut, [5])


@cocotb.test()
async def test_c4_rollover_3(dut):
    await _rollover_case(dut, [6])


@cocotb.test()
async def test_c5_rollover_gt3(dut):
    await _rollover_case(dut, [7, 8])


@cocotb.test()
async def test_c6_chunks_sweep(dut):
    await _rollover_case(dut, list(range(0, fm.MAX_CHUNKS + 1)))


# ===========================================================================
# Group D — LLCRD
# ===========================================================================
def check_llcrd(d, f, crd):
    assert f["ctrl"] == 1 and f["alldata"] == 0, "LLCRD: flit_is_control=1"
    assert d["hdr.Type"] == 1, "control flit Type=1 (Table 46)"
    assert d["ctl.CTL_FMT"] == 0 and d["ctl.LLCTRL"] == 0 and d["ctl.SubType"] == 0
    assert d["ctl.bytes5_7"] == 0 and d["ctl.Payload"] == "0x0"
    assert (d["hdr.ReqCrd"], d["hdr.DataCrd"], d["hdr.RspCrd"]) == crd
    assert d["hdr.Ak"] == 0 and d["hdr.RV"] == 0
    for k in (1, 2, 3):
        assert d[f"slot{k}"] == "0x0", "LLCRD: Slots 1-3 reserved (Fig. 78)"
    assert d["CRC"] == "0x0"


@cocotb.test()
async def test_d1_llcrd_idle_format(dut):
    env = PackerEnv(dut)
    await env.start()
    env.crd = (0b1011, 0b1110, 0b1001)
    await env.cycle(force_llcrd=1)
    await env.drain()
    assert len(env.flits) == 1
    check_llcrd(dec(env, env.flits[0]), env.flits[0], env.crd)


@cocotb.test()
async def test_d2_llcrd_not_mid_rollover(dut):
    env = PackerEnv(dut)
    await env.start()
    m = fm.Msg(kind=1, opcode=fm.OP_MEMWR if env.dir == M2S else fm.OP_MEMDATA,
               data=chunks_data(range(1, 9)), chunks_ovr=8)
    env.queue.append(m)
    await env.cycle()                 # header flit decided, rollover 5 pending
    await env.cycle(force_llcrd=1)    # request during rollover (one-cycle pulse)
    await env.drain()
    kinds = ["C" if f["ctrl"] else "A" if f["alldata"] else "P" for f in env.flits]
    assert kinds == ["P", "A", "P", "C"], f"LLCRD must wait for the rollover: got {kinds}"


@cocotb.test()
async def test_d3_llcrd_priority_over_msg(dut):
    env = PackerEnv(dut)
    await env.start()
    op = fm.OP_MEMRD if env.dir == M2S else fm.OP_CMP
    env.queue.append(fm.Msg(kind=0, opcode=op, tag=0x33))
    out = await env.cycle(force_llcrd=1)       # message and LLCRD both pending
    assert out["msg_ready"] == 0, "message must wait while an LLCRD is pending"
    await env.drain()
    kinds = ["C" if f["ctrl"] else "P" for f in env.flits]
    assert kinds == ["C", "P"], f"LLCRD has priority at a free boundary: got {kinds}"
    # LLCRD requested during a rollover with a message waiting: rollover, LLCRD, message
    env.flits.clear()
    env.queue.append(fm.Msg(kind=1, opcode=fm.OP_MEMWR if env.dir == M2S else fm.OP_MEMDATA,
                            data=chunks_data([1, 2, 3, 4])))
    env.queue.append(fm.Msg(kind=0, opcode=op, tag=0x44))
    await env.cycle()
    await env.cycle(force_llcrd=1)
    await env.drain()
    kinds = ["C" if f["ctrl"] else "P" for f in env.flits]
    assert kinds == ["P", "P", "C", "P"], f"got {kinds}"


@cocotb.test()
async def test_d4_llcrd_latched_under_backpressure(dut):
    env = PackerEnv(dut)
    await env.start()
    op = fm.OP_MEMRD if env.dir == M2S else fm.OP_CMP
    env.queue.append(fm.Msg(kind=0, opcode=op, tag=0x55))
    await env.cycle()                              # flit decided
    await env.cycle(flit_ready=0, force_llcrd=1)   # stalled + one-cycle LLCRD pulse
    await env.cycle(flit_ready=0)
    await env.drain()
    kinds = ["C" if f["ctrl"] else "P" for f in env.flits]
    assert kinds == ["P", "C"], f"LLCRD pulse during a stall must not be lost: got {kinds}"


# ===========================================================================
# Group E — constrained random
# ===========================================================================
@cocotb.test()
async def test_e1_packer_random(dut):
    env = PackerEnv(dut)
    await env.start()
    rng, seed = seed_rng(dut, 101)
    for it in range(6):
        sub = rng.getrandbits(32)
        dut._log.info(f"E1 iteration {it}: sub-seed {sub}")
        r = random.Random(sub)
        p_ready = r.choice([1.0, 0.8, 0.5, 0.2])
        for _ in range(400):
            if r.random() < 0.15 and len(env.queue) < 4:
                env.queue.append(rand_msg(r, env.dir))
            env.crd = (r.getrandbits(4), r.getrandbits(4), r.getrandbits(4))
            rst = 0 if r.random() < 0.004 else 1
            await env.cycle(force_llcrd=int(r.random() < 0.04),
                            flit_ready=int(r.random() < p_ready), rst_n=rst)
        await env.drain(max_cycles=400)


@cocotb.test()
async def test_zz_coverage(dut):
    """Prints the functional coverage of this run and fails if a goal was missed."""
    env = PackerEnv(dut)     # (re)defines the bins; counts accumulate across tests
    await env.start()
    dut._log.info("\n" + COV.report())
    assert not COV.missing(), f"coverage holes: {COV.missing()}"
