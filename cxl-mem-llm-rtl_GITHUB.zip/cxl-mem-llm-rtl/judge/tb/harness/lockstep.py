"""Lock-step runner: drives one cycle of inputs, compares every DUT output with
the golden model, then advances the model.

Per cycle:
  1. FallingEdge  -> drive this cycle's inputs
  2. ReadOnly     -> sample DUT outputs (registered + combinational settle)
  3. compare with model.outputs(inputs)   (skipped until the first reset edge)
  4. model.step(inputs)                   (models the next rising edge)
"""
from cocotb.triggers import FallingEdge, ReadOnly

from .io import Driver, Monitor
from .scoreboard import Scoreboard


class LockstepBench:
    def __init__(self, dut, ports, model, name, direction):
        self.dut = dut
        self.ports = ports
        self.model = model
        self.drv = Driver(dut, ports)
        self.mon = Monitor(dut, ports)
        self.sb = Scoreboard(name, direction, dut._log)
        self.cycle_no = 0
        self.synced = False      # outputs are only defined after the first reset edge
        self.history = []
        self.listeners = []      # callables(inputs, outputs, event)

    async def cycle(self, inputs):
        await FallingEdge(getattr(self.dut, self.ports["clock"]))
        self.drv.drive(inputs)
        await ReadOnly()
        actual = self.mon.sample()
        if self.synced:
            expected = self.model.outputs(inputs)
            self.sb.compare(self.cycle_no, inputs, expected, actual, self.history)
        event = self.model.step(inputs)
        if not inputs.get("rst_n", 1):
            self.synced = True
        if event:
            self.history.append((self.cycle_no, event))
        for fn in self.listeners:
            fn(inputs, actual, event)
        self.cycle_no += 1
        return actual
