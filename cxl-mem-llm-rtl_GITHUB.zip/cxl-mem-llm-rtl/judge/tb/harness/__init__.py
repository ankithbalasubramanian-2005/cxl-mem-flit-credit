"""DUT-agnostic cocotb harness: driver, monitor, scoreboard, clock/reset, coverage."""
