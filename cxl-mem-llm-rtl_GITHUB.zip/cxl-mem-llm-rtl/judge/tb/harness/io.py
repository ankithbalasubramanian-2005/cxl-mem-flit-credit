"""Driver and monitor: move dicts of logical signals to/from the DUT.

Signal names are resolved only through tb/dut_ports.py.
"""


class Driver:
    def __init__(self, dut, ports):
        self.handles = {k: getattr(dut, v) for k, v in ports["inputs"].items()}
        self.widths = {k: len(h) for k, h in self.handles.items()}

    def drive(self, values):
        for k, h in self.handles.items():
            v = int(values.get(k, 0))
            h.value = v & ((1 << self.widths[k]) - 1)


class Monitor:
    """Samples outputs. Unresolvable values (X/Z) are returned as the string 'X'."""

    def __init__(self, dut, ports):
        self.handles = {k: getattr(dut, v) for k, v in ports["outputs"].items()}

    def sample(self):
        out = {}
        for k, h in self.handles.items():
            try:
                out[k] = int(h.value)
            except ValueError:
                out[k] = "X"
        return out
