"""Clock and reset helpers."""
import cocotb
from cocotb.clock import Clock

CLK_PERIOD_NS = 10


def start_clock(dut, ports):
    clk = getattr(dut, ports["clock"])
    cocotb.start_soon(Clock(clk, CLK_PERIOD_NS, unit="ns").start())


async def apply_reset(bench, cycles=3, idle=None):
    """Hold rst_n low for `cycles` cycles (synchronous reset), then release."""
    idle = dict(idle or {})
    for _ in range(cycles):
        await bench.cycle(dict(idle, rst_n=0))
