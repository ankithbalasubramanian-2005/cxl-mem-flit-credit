"""Simple functional-coverage counters (bins -> hit counts)."""


class Coverage:
    def __init__(self, name):
        self.name = name
        self.groups = {}   # group -> {bin: count}
        self.goals = {}    # group -> list of bins that must be hit

    def define(self, group, bins):
        self.groups.setdefault(group, {b: 0 for b in bins})
        self.goals[group] = list(bins)

    def hit(self, group, b):
        g = self.groups.setdefault(group, {})
        g[b] = g.get(b, 0) + 1

    def missing(self):
        return [(g, b) for g, bins in self.goals.items()
                for b in bins if self.groups[g].get(b, 0) == 0]

    def report(self):
        lines = [f"===== FUNCTIONAL COVERAGE: {self.name} ====="]
        for g, bins in self.groups.items():
            cells = ", ".join(f"{b}:{c}" for b, c in bins.items())
            lines.append(f"  {g:28s} {cells}")
        miss = self.missing()
        lines.append("  ALL GOALS HIT" if not miss else f"  MISSING: {miss}")
        return "\n".join(lines)
