"""Scoreboard: compares DUT outputs with the golden model, reports the first
mismatch in readable, field-level form, and stops the test."""
from tb.ref_model.flit_model import decode_flit


class Mismatch(AssertionError):
    pass


def _fmt(v):
    return v if isinstance(v, str) else hex(v)


class Scoreboard:
    def __init__(self, name, direction, log):
        self.name = name
        self.direction = direction
        self.log = log
        self.checks = 0

    def compare(self, cycle, inputs, expected, actual, history):
        self.checks += 1
        bad = [k for k in expected if actual.get(k) != expected[k]]
        if not bad:
            return
        lines = [f"[{self.name}] FIRST MISMATCH at cycle {cycle} (DIRECTION={self.direction})"]
        for k in bad:
            lines.append(f"  output {k}: expected {_fmt(expected[k])}  got {_fmt(actual[k])}")
        if "flit_out" in bad and not isinstance(actual["flit_out"], str):
            exp_d = decode_flit(expected["flit_out"], self.direction,
                                expected.get("flit_is_control"), expected.get("flit_is_alldata"))
            act_d = decode_flit(actual["flit_out"], self.direction,
                                expected.get("flit_is_control"), expected.get("flit_is_alldata"))
            lines.append("  flit_out field differences (decoded with the EXPECTED flit type):")
            for f in exp_d:
                if exp_d[f] != act_d.get(f):
                    lines.append(f"    {f:22s} expected {exp_d[f]}  got {act_d.get(f)}")
        lines.append("  inputs this cycle: " + ", ".join(
            f"{k}={_fmt(v)}" for k, v in inputs.items() if k != "msg_data"))
        if history:
            lines.append("  recent model events: " + "; ".join(str(h) for h in history[-6:]))
        msg = "\n".join(lines)
        self.log.error(msg)
        raise Mismatch(msg)
