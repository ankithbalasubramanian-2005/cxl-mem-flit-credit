# Third-party materials

The unmodified IEEEtran.cls v1.8b in docs/paper is by its named contributors and distributed under the LaTeX Project Public License v1.3. Its original copyright and file-list notice appear in the class. The upstream distribution is https://ctan.org/pkg/ieeetran.

The project refers to the CXL specification. The Consortium retains its rights. The reference link is in README.md. The specification and IEEE sample paper are excluded. The compiled PDF and figure PDFs here are the supplied project's own outputs.

cocotb, pytest, Icarus Verilog, YoWASP/Yosys, slang, ABC, and Python are external dependencies. Install them separately. Their console banners and attribution notices are preserved in the evidence. Model responses and generated RTL are preserved as research records with their provenance. The project license applies to the contributors' rights. The MIT and CC BY grants do not alter third-party rights or model service terms.
