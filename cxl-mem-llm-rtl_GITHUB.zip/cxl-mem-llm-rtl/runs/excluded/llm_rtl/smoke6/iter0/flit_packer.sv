module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam int SLOT_BITS = 128;
  localparam int FLIT_BITS = 528;

  logic [3:0]  rem;
  logic        lat;
  logic        slot_free;
  logic        llcrd_eff;
  logic        msg_accepted;
  logic [3:0]  n_chunks;
  logic [127:0] chunk_list [0:MAX_CHUNKS-1];
  logic        is_rwd, is_req, is_drs, is_ndr;
  logic        is_memwr, is_memwrptl, is_memrd, is_memrddata;
  logic        is_cmp, is_memdata;
  logic        sz_bit, be_bit;
  logic [2:0]  slot0_fmt, slot1_fmt, slot2_fmt, slot3_fmt;
  logic [127:0] slot0, slot1, slot2, slot3;
  logic [15:0]  crc_val;
  logic [527:0] flit_next;
  logic         flit_valid_next, flit_is_control_next, flit_is_alldata_next;
  logic         crd_taken_next;

  assign is_rwd      = (DIRECTION == 0) &&  msg_kind;
  assign is_req      = (DIRECTION == 0) && !msg_kind;
  assign is_drs      = (DIRECTION == 1) &&  msg_kind;
  assign is_ndr      = (DIRECTION == 1) && !msg_kind;

  assign is_memwr     = is_rwd && (msg_opcode == 4'h1);
  assign is_memwrptl  = is_rwd && (msg_opcode == 4'h2);
  assign is_memrd     = is_req && (msg_opcode == 4'h1);
  assign is_memrddata = is_req && (msg_opcode == 4'h2);
  assign is_cmp       = is_ndr && (msg_opcode[2:0] == 3'h0);
  assign is_memdata   = is_drs && (msg_opcode[2:0] == 3'h0);

  assign sz_bit = is_rwd | is_drs;
  assign be_bit = is_memwrptl;

  assign slot_free = !flit_valid || flit_ready;
  assign llcrd_eff = lat || force_llcrd;
  assign msg_ready = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  always_comb begin
    n_chunks = 0;
    for (int i = 0; i < MAX_CHUNKS; i++) chunk_list[i] = '0;
    if (chunks_ovr_en) begin
      n_chunks = chunks_ovr;
      for (int i = 0; i < MAX_CHUNKS; i++)
        if (i < chunks_ovr) chunk_list[i] = msg_data[128*i +: 128];
    end else if (is_memwr || is_memdata) begin
      n_chunks = 4;
      for (int i = 0; i < 4; i++) chunk_list[i] = msg_data[128*i +: 128];
    end else if (is_memwrptl) begin
      n_chunks = 5;
      for (int i = 0; i < 4; i++) chunk_list[i] = msg_data[128*i +: 128];
      chunk_list[4] = {64'b0, msg_byte_en};
    end
  end

  always_comb begin
    slot0_fmt = (DIRECTION == 0) ? (is_rwd ? 3'b100 : 3'b101) : 3'b011;
    slot1_fmt = 3'b000;
    slot2_fmt = 3'b000;
    slot3_fmt = 3'b000;
  end

  function automatic logic [127:0] build_slot0_m2s_req(
    input logic [3:0] opcode, input logic [51:0] addr, input logic [15:0] tag
  );
    logic [127:0] s;
    begin
      s = '0;
      s[32]   = 1'b1;
      s[36:33] = opcode;
      s[39:37] = 3'b000;
      s[41:40] = 2'b11;
      s[43:42] = 2'b00;
      s[59:44] = tag;
      s[106:60] = addr[51:5];
      s[108:107] = 2'b00;
      s[112:109] = 4'b0000;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_m2s_rwd(
    input logic [3:0] opcode, input logic [51:0] addr, input logic [15:0] tag,
    input logic poison
  );
    logic [127:0] s;
    begin
      s = '0;
      s[32]   = 1'b1;
      s[36:33] = opcode;
      s[39:37] = 3'b000;
      s[41:40] = 2'b11;
      s[43:42] = 2'b00;
      s[59:44] = tag;
      s[105:60] = addr[51:6];
      s[106]    = poison;
      s[108:107] = 2'b00;
      s[112:109] = 4'b0000;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_s2m_drs(
    input logic [2:0] opcode, input logic [15:0] tag, input logic poison
  );
    logic [127:0] s;
    begin
      s = '0;
      s[32]   = 1'b1;
      s[35:33] = opcode;
      s[37:36] = 2'b11;
      s[39:38] = 2'b00;
      s[55:40] = tag;
      s[56]    = poison;
      s[60:57] = 4'b0000;
      s[62:61] = 2'b00;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_s2m_ndr(
    input logic [2:0] opcode, input logic [15:0] tag
  );
    logic [127:0] s;
    begin
      s = '0;
      s[72]   = 1'b1;
      s[75:73] = opcode;
      s[77:76] = 2'b11;
      s[79:78] = 2'b00;
      s[95:80] = tag;
      s[99:96] = 4'b0000;
      s[101:100] = 2'b00;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_llcrd(
    input logic [3:0] reqcrd, input logic [3:0] datacrd, input logic [3:0] rspcrd
  );
    logic [127:0] s;
    begin
      s = '0;
      s[0]   = 1'b1;
      s[1]   = 1'b0;
      s[2]   = 1'b0;
      s[7:5] = 3'b000;
      s[23:20] = rspcrd;
      s[27:24] = reqcrd;
      s[31:28] = datacrd;
      s[35:32] = 4'b0000;
      s[39:36] = 4'b0000;
      return s;
    end
  endfunction

  always_comb begin
    slot0 = '0;
    slot1 = '0;
    slot2 = '0;
    slot3 = '0;
    flit_next = '0;
    flit_valid_next = 1'b0;
    flit_is_control_next = 1'b0;
    flit_is_alldata_next = 1'b0;
    crd_taken_next = 1'b0;
    msg_accepted = 1'b0;

    if (slot_free) begin
      if (rem > 0) begin
        if (rem > 3) begin
          flit_is_alldata_next = 1'b1;
          slot0 = chunk_list[0];
          slot1 = chunk_list[1];
          slot2 = chunk_list[2];
          slot3 = chunk_list[3];
          for (int i = 0; i < MAX_CHUNKS-4; i++) chunk_list[i] = chunk_list[i+4];
          rem = rem - 4;
        end else begin
          slot0 = '0;
          for (int i = 0; i < rem; i++) begin
            case (i)
              0: slot1 = chunk_list[0];
              1: slot2 = chunk_list[1];
              2: slot3 = chunk_list[2];
            endcase
          end
          for (int i = 0; i < MAX_CHUNKS-rem; i++) chunk_list[i] = chunk_list[i+rem];
          rem = 0;
          crd_taken_next = 1'b1;
        end
        flit_valid_next = 1'b1;
        lat = llcrd_eff;
      end else if (llcrd_eff) begin
        slot0 = build_slot0_llcrd(crd_req_field, crd_data_field, crd_rsp_field);
        slot1 = '0; slot2 = '0; slot3 = '0;
        flit_is_control_next = 1'b1;
        flit_valid_next = 1'b1;
        crd_taken_next = 1'b1;
        lat = 1'b0;
      end else if (msg_valid) begin
        msg_accepted = 1'b1;
        if (DIRECTION == 0) begin
          if (is_req) slot0 = build_slot0_m2s_req(msg_opcode, msg_addr, msg_tag);
          else        slot0 = build_slot0_m2s_rwd(msg_opcode, msg_addr, msg_tag, msg_poison);
        end else begin
          if (is_drs) slot0 = build_slot0_s2m_drs(msg_opcode[2:0], msg_tag, msg_poison);
          else        slot0 = build_slot0_s2m_ndr(msg_opcode[2:0], msg_tag);
        end
        if (n_chunks > 3) begin
          slot1 = chunk_list[0];
          slot2 = chunk_list[1];
          slot3 = chunk_list[2];
          for (int i = 0; i < MAX_CHUNKS-3; i++) chunk_list[i] = chunk_list[i+3];
          rem = n_chunks - 3;
        end else begin
          for (int i = 0; i < n_chunks; i++) begin
            case (i)
              0: slot1 = chunk_list[0];
              1: slot2 = chunk_list[1];
              2: slot3 = chunk_list[2];
            endcase
          end
          rem = 0;
        end
        flit_valid_next = 1'b1;
        crd_taken_next = 1'b1;
        lat = llcrd_eff;
      end else begin
        flit_valid_next = 1'b0;
        lat = llcrd_eff;
      end
    end else begin
      lat = llcrd_eff;
    end

    if (flit_valid_next && !flit_is_control_next && !flit_is_alldata_next) begin
      logic [31:0] hdr;
      hdr = '0;
      hdr[0]   = 1'b0;
      hdr[1]   = 1'b0;
      hdr[2]   = 1'b0;
      hdr[3]   = be_bit;
      hdr[4]   = sz_bit;
      hdr[7:5] = slot0_fmt;
      hdr[10:8] = slot1_fmt;
      hdr[13:11] = slot2_fmt;
      hdr[16:14] = slot3_fmt;
      hdr[19:17] = 3'b000;
      hdr[23:20] = crd_rsp_field;
      hdr[27:24] = crd_req_field;
      hdr[31:28] = crd_data_field;
      slot0[31:0] = hdr;
    end

    crc_val = 16'h0000;
    flit_next = {crc_val, slot3, slot2, slot1, slot0};
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid      <= 1'b0;
      flit_out        <= '0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem             <= 4'd0;
      lat             <= 1'b0;
      crd_taken       <= 1'b0;
    end else begin
      flit_valid      <= flit_valid_next;
      flit_out        <= flit_next;
      flit_is_control <= flit_is_control_next;
      flit_is_alldata <= flit_is_alldata_next;
      rem             <= rem;
      lat             <= lat;
      crd_taken       <= crd_taken_next;
    end
  end

endmodule
