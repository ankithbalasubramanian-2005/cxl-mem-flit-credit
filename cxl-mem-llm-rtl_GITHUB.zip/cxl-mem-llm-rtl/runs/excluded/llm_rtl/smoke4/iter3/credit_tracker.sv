module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  // Internal registers
  logic [6:0] snd[0:1];   // sender credit counters
  logic [7:0] pend[0:1];  // pending-return counters

  // Helper function to decode credit field to count
  function automatic logic [6:0] decode_credit(logic [3:0] field);
    logic [2:0] exp = field[2:0];
    logic sel = field[3];
    // Only CXL.mem (sel=1) is used; others are discarded (return 0)
    if (sel == 1'b0) return 7'b0;
    case (exp)
      3'b000: return 7'b1;
      3'b001: return 7'b2;
      3'b010: return 7'b4;
      3'b011: return 7'b8;
      3'b100: return 7'b16;
      3'b101: return 7'b32;
      3'b110: return 7'b64;
      default: return 7'b0;
    endcase
  endfunction

  // Helper function to encode count to credit field (greedy largest-first)
  function automatic logic [3:0] encode_credit(logic [6:0] count);
    if (count == 0) return 4'b0000;
    // Greedy decomposition: try 64,32,16,8,4,2,1
    if (count >= 64) return 4'b1111; // 64 credits, bit3=1
    if (count >= 32) return 4'b1110;
    if (count >= 16) return 4'b1101;
    if (count >= 8)  return 4'b1100;
    if (count >= 4)  return 4'b1011;
    if (count >= 2)  return 4'b1010;
    // count == 1
    return 4'b1001;
  endfunction

  // Sequential logic for counters
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] <= 7'b0;
      snd[1] <= 7'b0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      // Update sender counters based on tx_send and received credits
      if (tx_send[0]) begin
        if (snd[0] > 0) snd[0] <= snd[0] - 1;
        else snd[0] <= 7'b0;
      end
      if (tx_send[1]) begin
        if (snd[1] > 0) snd[1] <= snd[1] - 1;
        else snd[1] <= 7'b0;
      end

      // Add credits from received fields (only if rx_crd_valid)
      if (rx_crd_valid) begin
        if (DIRECTION == 0) begin
          // Host side: rx_reqcrd -> sender ch0, rx_datacrd -> sender ch1
          snd[0] <= snd[0] + decode_credit(rx_reqcrd);
          snd[1] <= snd[1] + decode_credit(rx_datacrd);
        end else begin
          // Device side: rx_rspcrd -> sender ch0, rx_datacrd -> sender ch1
          snd[0] <= snd[0] + decode_credit(rx_rspcrd);
          snd[1] <= snd[1] + decode_credit(rx_datacrd);
        end
        // Saturate
        if (snd[0] > CREDIT_MAX) snd[0] <= CREDIT_MAX;
        if (snd[1] > CREDIT_MAX) snd[1] <= CREDIT_MAX;
      end

      // Update pending counters based on buf_free and crd_taken
      if (buf_free[0]) begin
        if (pend[0] < PEND_MAX) pend[0] <= pend[0] + 1;
        else pend[0] <= PEND_MAX;
      end
      if (buf_free[1]) begin
        if (pend[1] < PEND_MAX) pend[1] <= pend[1] + 1;
        else pend[1] <= PEND_MAX;
      end

      if (crd_taken) begin
        // Determine which field was sent based on direction
        if (DIRECTION == 0) begin
          // Host side: crd_req_field -> pending ch0, crd_data_field -> pending ch1
          if (pend[0] >= decode_credit(crd_req_field)) pend[0] <= pend[0] - decode_credit(crd_req_field);
          else pend[0] <= 7'b0;
          if (pend[1] >= decode_credit(crd_data_field)) pend[1] <= pend[1] - decode_credit(crd_data_field);
          else pend[1] <= 7'b0;
        end else begin
          // Device side: crd_req_field -> pending ch0, crd_data_field -> pending ch1
          if (pend[0] >= decode_credit(crd_req_field)) pend[0] <= pend[0] - decode_credit(crd_req_field);
          else pend[0] <= 7'b0;
          if (pend[1] >= decode_credit(crd_data_field)) pend[1] <= pend[1] - decode_credit(crd_data_field);
          else pend[1] <= 7'b0;
        end
      end
    end
  end

  // Combinational outputs
  always_comb begin
    // can_send
    can_send[0] = (snd[0] > 0);
    can_send[1] = (snd[1] > 0);

    // crd_pending
    crd_pending = (pend[0] > 0) || (pend[1] > 0);

    // crd_req_field, crd_data_field, crd_rsp_field (only one is used per direction)
    if (DIRECTION == 0) begin
      crd_req_field = encode_credit(pend[0]); // pending for M2S Req
      crd_data_field = encode_credit(pend[1]); // pending for M2S RwD
      crd_rsp_field = 4'b0000; // reserved
    end else begin
      crd_req_field = encode_credit(pend[0]); // pending for S2M Req
      crd_data_field = encode_credit(pend[1]); // pending for S2M DRS
      crd_rsp_field = 4'b0000; // reserved
    end

    // pend_0, pend_1
    pend_0 = pend[0];
    pend_1 = pend[1];

    // tx_credits_0, tx_credits_1
    tx_credits_0 = snd[0];
    tx_credits_1 = snd[1];
  end

endmodule
