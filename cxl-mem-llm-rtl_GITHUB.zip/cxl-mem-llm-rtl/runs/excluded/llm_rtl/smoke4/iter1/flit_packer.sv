module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  // State registers
  logic [2:0]   rem;                 // remaining chunks to send
  logic         llcrd_latch;         // latched force_llcrd
  logic [527:0] flit_reg;            // registered flit output
  logic         flit_valid_reg;
  logic         flit_is_control_reg;
  logic         flit_is_alldata_reg;

  // Internal signals
  logic         slot_free;
  logic         llcrd_eff;
  logic         msg_ready_comb;
  logic         crd_taken_comb;
  logic [527:0] flit_comb;
  logic         flit_is_control_comb;
  logic         flit_is_alldata_comb;
  logic [127:0] slot0;
  logic [127:0] slot1;
  logic [127:0] slot2;
  logic [127:0] slot3;
  logic [15:0]  crc = 16'h0000;     // D3: CRC is always zero
  logic [3:0]   slot_fmt[0:3];      // slot format selectors
  logic [127:0] chunk_data[0:7];    // chunk storage for rollover
  logic [3:0]   chunk_fmt[0:7];     // format for each chunk (G0=000)
  logic [127:0] msg_chunk[0:7];     // message-specific chunk list
  logic [3:0]   msg_fmt;            // Slot0 format for the message (H4/H5/H3)
  logic [127:0] msg_header;         // header + message content in Slot0
  logic [3:0]   hdr_sz;             // Sz field for header (0/1)
  logic         hdr_be;             // BE field for header (0/1)
  logic [3:0]   hdr_type;           // Type field (0=protocol,1=control)
  logic [1:0]   hdr_rv_ak;          // RV[1] and Ak (Ak tied to 0)
  logic [3:0]   hdr_slot[0:3];      // slot format fields in header
  logic [3:0]   hdr_reqcrd;         // credit fields
  logic [3:0]   hdr_datacrd;
  logic [3:0]   hdr_rspcrd;
  logic [3:0]   hdr_llctrl;         // LLCRD specific field
  logic [3:0]   hdr_subtype;        // Subtype for LLCRD

  // Helper functions
  function automatic logic [127:0] build_slot0(
    logic [3:0] fmt,
    logic [127:0] content
  );
    // Slot0 = 32b header + up to 96b message
    // Header bits [31:0] are fixed for the format
    // For H4/H5/H3 the header is defined in spec; we build it here.
    // For simplicity, we treat content as the full 128b slot and mask out unused bits.
    // The actual header bits are placed in the lower 32b of the slot.
    // The message content starts at bit 32.
    // We assume content already contains the correct header+message.
    return {content[127:32], content[31:0]};
  endfunction

  function automatic void decode_message(
    output logic [127:0] header,
    output logic [3:0]   fmt,
    output logic [3:0]   sz,
    output logic         be,
    output logic [127:0] chunk0,
    output logic [127:0] chunk1,
    output logic [127:0] chunk2,
    output logic [127:0] chunk3
  );
    // Determine message type based on DIRECTION and msg_kind
    if (DIRECTION == 0) begin
      // M2S
      if (msg_kind == 0) begin
        // Req (H5)
        fmt = 4'b0101; // H5
        sz  = 1'b0;    // No data message
        be  = 1'b0;
        // Build header per spec (87 bits)
        logic [87:0] hdr;
        hdr[0] = 1'b1;                     // Valid
        hdr[4:1] = msg_opcode[3:0];        // MemOpcode
        hdr[7:5] = 3'b000;                 // SnpType (No-Op)
        hdr[9:8] = 2'b11;                  // MetaField (No-Op)
        hdr[11:10] = 2'b00;                // MetaValue
        hdr[27:12] = msg_tag[15:0];        // Tag
        hdr[53:28] = msg_addr[51:5];       // Address[51:5]
        hdr[55:54] = 2'b00;                // TC (reserved)
        hdr[59:56] = 4'b0000;              // LD-ID (0)
        hdr[87:60] = {6{1'b0}};            // RSVD
        // Pad to 128b
        header = {hdr, {9{1'b0}}};
        // No data chunks for Req
        chunk0 = 128'h0;
        chunk1 = 128'h0;
        chunk2 = 128'h0;
        chunk3 = 128'h0;
      end else begin
        // RwD (H4)
        fmt = 4'b0100; // H4
        sz  = 1'b1;    // Data message (full line)
        be  = (msg_opcode == 4'b0010) ? 1'b1 : 1'b0; // MemWrPtl sets BE=1
        // Build header per spec (87 bits)
        logic [87:0] hdr;
        hdr[0] = 1'b1;                     // Valid
        hdr[4:1] = msg_opcode[3:0];        // MemOpcode
        hdr[7:5] = 3'b000;                 // SnpType
        hdr[9:8] = 2'b11;                  // MetaField
        hdr[11:10] = 2'b00;                // MetaValue
        hdr[27:12] = msg_tag[15:0];        // Tag
        hdr[46:28] = msg_addr[51:6];       // Address[51:6]
        hdr[47] = msg_poison;              // Poison
        hdr[49:48] = 2'b00;                // TC
        hdr[53:50] = 4'b0000;              // LD-ID
        hdr[87:54] = {6{1'b0}};            // RSVD
        header = {hdr, {9{1'b0}}};
        // Determine chunk list
        if (msg_opcode == 4'b0001) begin // MemWr
          // 4 data chunks from msg_data[0..3]
          chunk0 = msg_data[127:0];
          chunk1 = msg_data[255:128];
          chunk2 = msg_data[383:256];
          chunk3 = msg_data[511:384];
        end else if (msg_opcode == 4'b0010) begin // MemWrPtl
          // 4 data chunks + 1 BE chunk (chunks 0..3 data, chunk4 BE)
          chunk0 = msg_data[127:0];
          chunk1 = msg_data[255:128];
          chunk2 = msg_data[383:256];
          chunk3 = msg_data[511:384];
          // BE chunk is stored in chunk4 (index 4) but we only have 4 slots in a flit.
          // The BE chunk will be placed in the next flit as a separate chunk.
          // For now, we treat BE as a separate chunk that will be scheduled later.
          // We'll store it in a separate variable.
        end
      end
    end else begin
      // S2M
      if (msg_kind == 0) begin
        // NDR (H3 second message)
        fmt = 4'b0011; // H3
        sz  = 1'b0;    // No data message
        be  = 1'b0;
        // Build header per spec (30 bits)
        logic [29:0] hdr;
        hdr[0] = 1'b1;                     // Valid
        hdr[3:1] = msg_opcode[2:0];        // Opcode (Cmp)
        hdr[5:4] = 2'b11;                  // MetaField
        hdr[7:6] = 2'b00;                  // MetaValue
        hdr[22:8] = msg_tag[15:0];         // Tag
        hdr[23] = msg_poison;              // Poison (not present in NDR? spec says NDR has no poison; but we keep for consistency)
        hdr[27:24] = 4'b0000;              // LD-ID
        hdr[29:28] = 2'b00;                // DevLoad
        header = {hdr, {98{1'b0}}};
        chunk0 = 128'h0;
        chunk1 = 128'h0;
        chunk2 = 128'h0;
        chunk3 = 128'h0;
      end else begin
        // DRS (H3 first message)
        fmt = 4'b0011; // H3
        sz  = 1'b1;    // Data message (full line)
        be  = 1'b0;
        // Build header per spec (40 bits)
        logic [39:0] hdr;
        hdr[0] = 1'b1;                     // Valid
        hdr[3:1] = msg_opcode[2:0];        // Opcode (MemData)
        hdr[5:4] = 2'b11;                  // MetaField
        hdr[7:6] = 2'b00;                  // MetaValue
        hdr[22:8] = msg_tag[15:0];         // Tag
        hdr[23] = msg_poison;              // Poison
        hdr[27:24] = 4'b0000;              // LD-ID
        hdr[29:28] = 2'b00;                // DevLoad
        hdr[39:30] = {10{1'b0}};           // RSVD
        header = {hdr, {88{1'b0}}};
        // 4 data chunks from msg_data[0..3]
        chunk0 = msg_data[127:0];
        chunk1 = msg_data[255:128];
        chunk2 = msg_data[383:256];
        chunk3 = msg_data[511:384];
      end
    end
  endfunction

  // Determine chunk list based on override or natural count
  always_comb begin
    // Compute natural chunk count
    logic [3:0] natural_chunks = 4'b0;
    if (DIRECTION == 0) begin
      if (msg_kind == 0) begin
        natural_chunks = 4'b0; // Req has no data
      end else begin
        if (msg_opcode == 4'b0001) natural_chunks = 4'b0100; // 4 chunks
        else if (msg_opcode == 4'b0010) natural_chunks = 4'b0101; // 5 chunks (4 data + BE)
      end
    end else begin
      if (msg_kind == 0) begin
        natural_chunks = 4'b0; // NDR has no data
      end else begin
        natural_chunks = 4'b0100; // DRS has 4 chunks
      end
    end

    // Use override if enabled
    if (chunks_ovr_en) begin
      natural_chunks = chunks_ovr;
    end

    // Fill msg_chunk array
    for (int i = 0; i < MAX_CHUNKS; i++) begin
      if (i < natural_chunks) begin
        msg_chunk[i] = msg_data[128*(i+1)-1 : 128*i];
      end else begin
        msg_chunk[i] = 128'h0;
      end
    end
  end

  // Build slot formats and slot contents for a given flit
  always_comb begin
    // Default slot formats
    slot_fmt[0] = 4'b0000; // placeholder
    slot_fmt[1] = 4'b0000;
    slot_fmt[2] = 4'b0000;
    slot_fmt[3] = 4'b0000;

    // Determine slot formats based on direction and message type
    if (DIRECTION == 0) begin
      // M2S
      if (msg_kind == 0) begin
        // Req: Slot0 = H5 (101), Slots1-3 = G0 (000) if data, else empty
        slot_fmt[0] = 4'b0101;
        slot_fmt[1] = 4'b0000;
        slot_fmt[2] = 4'b0000;
        slot_fmt[3] = 4'b0000;
      end else begin
        // RwD: Slot0 = H4 (100)
        slot_fmt[0] = 4'b0100;
        slot_fmt[1] = 4'b0000;
        slot_fmt[2] = 4'b0000;
        slot_fmt[3] = 4'b0000;
      end
    end else begin
      // S2M: both DRS and NDR use H3 (011)
      slot_fmt[0] = 4'b0011;
      slot_fmt[1] = 4'b0000;
      slot_fmt[2] = 4'b0000;
      slot_fmt[3] = 4'b0000;
    end

    // For data chunks (G0), format is always 000
    // We'll set slot_fmt for slots that carry data chunks later.
  end

  // Determine header fields (credit fields, type, etc.)
  always_comb begin
    // Default header fields
    hdr_type = 1'b0; // protocol flit
    hdr_rv_ak = 2'b00; // RV=0, Ak=0 (tied)
    hdr_sz = 1'b0;
    hdr_be = 1'b0;
    hdr_slot = '{default: 4'b0};
    hdr_reqcrd = crd_req_field;
    hdr_datacrd = crd_data_field;
    hdr_rspcrd = crd_rsp_field;
    hdr_llctrl = 4'b0000;
    hdr_subtype = 4'b0000;

    // Build header bits according to spec
    // We'll construct the 32-bit header based on slot format and credit fields.
    // For simplicity, we'll generate the header in the flit_comb block.
  end

  // Flit construction logic
  always_comb begin
    // Default outputs
    flit_comb = {crc, {128{slot3}}, {128{slot2}}, {128{slot1}}, {128{slot0}}};
    flit_is_control_comb = 1'b0;
    flit_is_alldata_comb = 1'b0;
    crd_taken_comb = 1'b0;
    msg_ready_comb = 1'b0;

    // Determine if we are in rollover mode
    if (rem > 0) begin
      // Rollover flit
      // According to spec, if rem > 3, it's an all-data flit.
      if (rem > 3) begin
        // All-data flit: slots 0-3 are data chunks, no header
        flit_is_alldata_comb = 1'b1;
        // Fill slots with the next 4 chunks from chunk_data
        slot0 = chunk_data[0];
        slot1 = chunk_data[1];
        slot2 = chunk_data[2];
        slot3 = chunk_data[3];
        // Update rem
        rem = rem - 4;
        // No credit taken for all-data flit
        crd_taken_comb = 1'b0;
      end else begin
        // Protocol flit with rem chunks in slots 1..rem
        // Slot0 is empty (no message)
        slot0 = {128{1'b0}};
        // Fill slots 1..rem with chunks
        slot1 = (rem >= 1) ? chunk_data[0] : 128'h0;
        slot2 = (rem >= 2) ? chunk_data[1] : 128'h0;
        slot3 = (rem >= 3) ? chunk_data[2] : 128'h0;
        // Slot4? Not present.
        // Set slot formats: Slot0 = H5/H4/H3 (depending on direction), Slots1..rem = G0
        // For simplicity, we set slot_fmt based on direction and message type.
        // We'll compute slot_fmt in a separate block.
        // Credit taken for protocol flit
        crd_taken_comb = 1'b1;
      end
    end else if (llcrd_eff) begin
      // LLCRD flit
      flit_is_control_comb = 1'b1;
      // Build LLCRD header per spec
      // Type=1, RV=0, Ak=0, RSVD[4:3]=0, CTL_FMT=000, RSVD[15:8]=0, RSVD[19:16]=0, RspCrd, ReqCrd, DataCrd, LLCTRL=0000, SubType=0000, payload=0
      logic [31:0] llcr_header;
      llcr_header[0] = 1'b1; // Type
      llcr_header[1] = 1'b0; // RV
      llcr_header[2] = 1'b0; // Ak
      llcr_header[4:3] = 2'b00; // RSVD
      llcr_header[7:5] = 3'b000; // CTL_FMT
      llcr_header[15:8] = 8'b0; // RSVD
      llcr_header[19:16] = 4'b0; // RSVD
      llcr_header[23:20] = hdr_rspcrd; // RspCrd
      llcr_header[27:24] = hdr_reqcrd; // ReqCrd
      llcr_header[31:28] = hdr_datacrd; // DataCrd
      // LLCTRL and SubType occupy bits [35:32] and [39:36]
      llcr_header[35:32] = 4'b0000; // LLCTRL
      llcr_header[39:36] = 4'b0000; // SubType
      // Bytes 5-7 are zero (bits 63:40)
      // Payload bits 127:64 are zero
      // Slot0 = llcr_header + zeros for bytes 5-7 and payload
      slot0 = {llcr_header, {64{1'b0}}};
      slot1 = 128'h0;
      slot2 = 128'h0;
      slot3 = 128'h0;
      // Credit taken for LLCRD
      crd_taken_comb = 1'b1;
    end else if (msg_valid && slot_free && rem == 0) begin
      // New message flit
      // Determine message type and build header
      // We'll call decode_message to get header, fmt, sz, be, and chunks
      // For now, placeholder
      slot0 = 128'h0;
      slot1 = 128'h0;
      slot2 = 128'h0;
      slot3 = 128'h0;
      // Credit taken for protocol flit
      crd_taken_comb = 1'b1;
      msg_ready_comb = 1'b1;
    end else begin
      // No flit
      flit_comb = {crc, {128{slot3}}, {128{slot2}}, {128{slot1}}, {128{slot0}}};
      flit_is_control_comb = 1'b0;
      flit_is_alldata_comb = 1'b0;
      crd_taken_comb = 1'b0;
      msg_ready_comb = 1'b0;
    end
  end

  // Sequential logic for registers
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid_reg <= 1'b0;
      flit_reg <= {crc, {128{slot3}}, {128{slot2}}, {128{slot1}}, {128{slot0}}};
      flit_is_control_reg <= 1'b0;
      flit_is_alldata_reg <= 1'b0;
      llcrd_latch <= 1'b0;
      rem <= 3'b0;
      // Initialize chunk_data
      for (int i = 0; i < MAX_CHUNKS; i++) begin
        chunk_data[i] <= 128'h0;
      end
    end else begin
      // Latch force_llcrd
      llcrd_latch <= force_llcrd;

      // Update flit outputs based on combinational logic
      flit_valid_reg <= flit_comb.flit_valid; // placeholder
      flit_reg <= flit_comb;
      flit_is_control_reg <= flit_is_control_comb;
      flit_is_alldata_reg <= flit_is_alldata_comb;
      crd_taken <= crd_taken_comb;
      msg_ready <= msg_ready_comb;

      // Update rollover buffer
      if (rem > 0) begin
        // If we are sending a rollover flit, update rem
        if (rem > 3) begin
          rem <= rem - 4;
        end else begin
          rem <= 3'b0;
        end
      end

      // Update chunk_data with message chunks when a new message is accepted
      if (msg_valid && msg_ready_comb) begin
        // Copy message chunks into chunk_data
        for (int i = 0; i < MAX_CHUNKS; i++) begin
          chunk_data[i] <= msg_chunk[i];
        end
        // Reset rem based on message chunk count
        if (chunks_ovr_en) begin
          rem <= chunks_ovr;
        end else begin
          // Determine natural chunk count
          if (DIRECTION == 0) begin
            if (msg_kind == 0) begin
              rem <= 4'b0;
            end else begin
              if (msg_opcode == 4'b0001) rem <= 4'b0100;
              else if (msg_opcode == 4'b0010) rem <= 4'b0101;
            end
          end else begin
            if (msg_kind == 0) begin
              rem <= 4'b0;
            end else begin
              rem <= 4'b0100;
            end
          end
        end
      end
    end
  end

  // Output assignments
  assign flit_valid = flit_valid_reg;
  assign flit_out = flit_reg;
  assign flit_is_control = flit_is_control_reg;
  assign flit_is_alldata = flit_is_alldata_reg;

endmodule
