module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G3 = 3'b011;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_MEMRD      = 4'b0001;
  localparam logic [3:0] OP_M2S_MEMRDDATA  = 4'b0010;
  localparam logic [3:0] OP_M2S_MEMWR      = 4'b0001;
  localparam logic [3:0] OP_M2S_MEMWRPTL   = 4'b0010;
  localparam logic [2:0] OP_S2M_CMP        = 3'b000;
  localparam logic [2:0] OP_S2M_MEMDATA    = 3'b000;

  logic [3:0] rem;
  logic       lat;

  logic [127:0] slot0, slot1, slot2, slot3;
  logic [15:0]  crc16;
  logic [527:0] flit_next;
  logic         flit_valid_next;
  logic         flit_is_control_next;
  logic         flit_is_alldata_next;
  logic [3:0]   rem_next;
  logic         lat_next;
  logic         crd_taken_next;

  logic slot_free;
  logic llcrd_eff;
  logic msg_accepted;

  logic [127:0] chunks [0:MAX_CHUNKS-1];
  logic [3:0]   n_chunks;
  logic         sz_hdr;
  logic         be_hdr;

  assign slot_free = !flit_valid || flit_ready;
  assign llcrd_eff = lat || force_llcrd;
  assign msg_ready = rst_n && slot_free && (rem == 4'd0) && !llcrd_eff;

  always_comb begin
    for (int i = 0; i < MAX_CHUNKS; i++) chunks[i] = 128'h0;
    n_chunks = 4'd0;
    sz_hdr   = 1'b0;
    be_hdr   = 1'b0;

    if (chunks_ovr_en) begin
      n_chunks = chunks_ovr;
      for (int i = 0; i < MAX_CHUNKS; i++)
        if (i < chunks_ovr) chunks[i] = msg_data[128*i +: 128];
    end else begin
      if (DIRECTION == 0) begin
        if (msg_kind == 1'b1) begin
          if (msg_opcode == OP_M2S_MEMWR) begin
            sz_hdr = 1'b1; be_hdr = 1'b0; n_chunks = 4'd4;
            for (int i = 0; i < 4; i++) chunks[i] = msg_data[128*i +: 128];
          end else if (msg_opcode == OP_M2S_MEMWRPTL) begin
            sz_hdr = 1'b1; be_hdr = 1'b1; n_chunks = 4'd5;
            for (int i = 0; i < 4; i++) chunks[i] = msg_data[128*i +: 128];
            chunks[4] = {64'h0, msg_byte_en};
          end
        end
      end else begin
        if (msg_kind == 1'b1) begin
          sz_hdr = 1'b1; be_hdr = 1'b0; n_chunks = 4'd4;
          for (int i = 0; i < 4; i++) chunks[i] = msg_data[128*i +: 128];
        end
      end
    end
  end

  function automatic logic [127:0] build_slot0_m2s_req(
    input logic [3:0] opcode, input logic [51:0] addr,
    input logic [15:0] tag, input logic [3:0] slot0_sel
  );
    logic [127:0] s;
    begin
      s = 128'h0;
      s[32]   = 1'b1;
      s[36:33] = opcode;
      s[39:37] = 3'b000;
      s[41:40] = 2'b11;
      s[43:42] = 2'b00;
      s[59:44] = tag;
      s[106:60] = addr[51:5];
      s[108:107] = 2'b00;
      s[112:109] = 4'b0000;
      s[118:113] = 6'b0;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_m2s_rwd(
    input logic [3:0] opcode, input logic [51:0] addr,
    input logic [15:0] tag, input logic poison, input logic [3:0] slot0_sel
  );
    logic [127:0] s;
    begin
      s = 128'h0;
      s[32]   = 1'b1;
      s[36:33] = opcode;
      s[39:37] = 3'b000;
      s[41:40] = 2'b11;
      s[43:42] = 2'b00;
      s[59:44] = tag;
      s[105:60] = addr[51:6];
      s[106]    = poison;
      s[108:107] = 2'b00;
      s[112:109] = 4'b0000;
      s[118:113] = 6'b0;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_s2m_drs(
    input logic [2:0] opcode, input logic [15:0] tag,
    input logic poison, input logic [3:0] slot0_sel
  );
    logic [127:0] s;
    begin
      s = 128'h0;
      s[32]   = 1'b1;
      s[35:33] = opcode;
      s[37:36] = 2'b11;
      s[39:38] = 2'b00;
      s[55:40] = tag;
      s[56]    = poison;
      s[60:57] = 4'b0000;
      s[62:61] = 2'b00;
      s[71:63] = 9'b0;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_s2m_ndr(
    input logic [2:0] opcode, input logic [15:0] tag,
    input logic [3:0] slot0_sel
  );
    logic [127:0] s;
    begin
      s = 128'h0;
      s[72]   = 1'b1;
      s[75:73] = opcode;
      s[77:76] = 2'b11;
      s[79:78] = 2'b00;
      s[95:80] = tag;
      s[99:96] = 4'b0000;
      s[101:100] = 2'b00;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_s2m_h3(
    input logic [2:0] drs_opc, input logic [15:0] drs_tag, input logic drs_poison,
    input logic [2:0] ndr_opc, input logic [15:0] ndr_tag,
    input logic drs_valid, input logic ndr_valid
  );
    logic [127:0] s;
    begin
      s = 128'h0;
      if (drs_valid) begin
        s[32]   = 1'b1;
        s[35:33] = drs_opc;
        s[37:36] = 2'b11;
        s[39:38] = 2'b00;
        s[55:40] = drs_tag;
        s[56]    = drs_poison;
        s[60:57] = 4'b0000;
        s[62:61] = 2'b00;
        s[71:63] = 9'b0;
      end
      if (ndr_valid) begin
        s[72]   = 1'b1;
        s[75:73] = ndr_opc;
        s[77:76] = 2'b11;
        s[79:78] = 2'b00;
        s[95:80] = ndr_tag;
        s[99:96] = 4'b0000;
        s[101:100] = 2'b00;
      end
      return s;
    end
  endfunction

  function automatic logic [31:0] build_header(
    input logic type_bit, input logic be, input logic sz,
    input logic [2:0] s0, input logic [2:0] s1, input logic [2:0] s2, input logic [2:0] s3,
    input logic [3:0] rsp, input logic [3:0] req, input logic [3:0] dat
  );
    logic [31:0] h;
    begin
      h = 32'h0;
      h[0]   = type_bit;
      h[1]   = 1'b0;
      h[2]   = 1'b0;
      h[3]   = be;
      h[4]   = sz;
      h[7:5] = s0;
      h[10:8] = s1;
      h[13:11] = s2;
      h[16:14] = s3;
      h[19:17] = 3'b0;
      h[23:20] = rsp;
      h[27:24] = req;
      h[31:28] = dat;
      return h;
    end
  endfunction

  function automatic logic [127:0] build_llcrd_slot0(
    input logic [3:0] rsp, input logic [3:0] req, input logic [3:0] dat
  );
    logic [127:0] s;
    begin
      s = 128'h0;
      s[0]   = 1'b1;
      s[1]   = 1'b0;
      s[2]   = 1'b0;
      s[4:3] = 2'b0;
      s[7:5] = 3'b000;
      s[15:8] = 8'h0;
      s[19:16] = 4'h0;
      s[23:20] = rsp;
      s[27:24] = req;
      s[31:28] = dat;
      s[35:32] = 4'b0000;
      s[39:36] = 4'b0000;
      s[63:40] = 24'h0;
      s[127:64] = 64'h0;
      return s;
    end
  endfunction

  always_comb begin
    flit_next           = 528'h0;
    flit_valid_next     = 1'b0;
    flit_is_control_next = 1'b0;
    flit_is_alldata_next = 1'b0;
    rem_next            = rem;
    lat_next            = lat;
    crd_taken_next      = 1'b0;

    if (slot_free) begin
      if (rem > 4'd0) begin
        if (rem > 4'd3) begin
          flit_next[127:0]   = chunks[n_chunks - rem];
          flit_next[255:128] = chunks[n_chunks - rem + 1];
          flit_next[383:256] = chunks[n_chunks - rem + 2];
          flit_next[511:384] = chunks[n_chunks - rem + 3];
          flit_next[527:512] = 16'h0;
          flit_valid_next     = 1'b1;
          flit_is_alldata_next = 1'b1;
          rem_next            = rem - 4'd4;
          lat_next            = llcrd_eff;
        end else begin
          logic [31:0] hdr;
          logic [2:0]  s1_sel, s2_sel, s3_sel;
          logic [127:0] s0_msg;
          if (DIRECTION == 0) begin
            s0_msg = 128'h0;
            s1_sel = (rem >= 1) ? SLOT_G0 : SLOT_G4;
            s2_sel = (rem >= 2) ? SLOT_G0 : SLOT_G4;
            s3_sel = (rem >= 3) ? SLOT_G0 : SLOT_G4;
            hdr = build_header(1'b0, 1'b0, 1'b0,
                               SLOT_H5, s1_sel, s2_sel, s3_sel,
                               crd_rsp_field, 4'b0000, crd_data_field);
          end else begin
            s0_msg = 128'h0;
            s1_sel = (rem >= 1) ? SLOT_G0 : SLOT_G5;
            s2_sel = (rem >= 2) ? SLOT_G0 : SLOT_G5;
            s3_sel = (rem >= 3) ? SLOT_G0 : SLOT_G5;
            hdr = build_header(1'b0, 1'b0, 1'b0,
                               SLOT_H3, s1_sel, s2_sel, s3_sel,
                               4'b0000, crd_req_field, crd_data_field);
          end
          flit_next[31:0] = hdr;
          flit_next[127:32] = s0_msg;
          if (rem >= 4'd1) flit_next[255:128] = chunks[n_chunks - rem];
          if (rem >= 4'd2) flit_next[383:256] = chunks[n_chunks - rem + 1];
          if (rem >= 4'd3) flit_next[511:384] = chunks[n_chunks - rem + 2];
          flit_next[527:512] = 16'h0;
          flit_valid_next     = 1'b1;
          rem_next            = 4'd0;
          crd_taken_next      = 1'b1;
          lat_next            = llcrd_eff;
        end
      end else if (llcrd_eff) begin
        logic [127:0] s0;
        s0 = build_llcrd_slot0(crd_rsp_field, crd_req_field, crd_data_field);
        flit_next[127:0] = s0;
        flit_next[511:128] = 384'h0;
        flit_next[527:512] = 16'h0;
        flit_valid_next     = 1'b1;
        flit_is_control_next = 1'b1;
        lat_next            = 1'b0;
        crd_taken_next      = 1'b1;
      end else if (msg_valid) begin
        logic [31:0] hdr;
        logic [2:0]  s1, s2, s3;
        logic [127:0] s0_msg;
        if (DIRECTION == 0) begin
          if (msg_kind == 1'b0) begin
            s0_msg = build_slot0_m2s_req(msg_opcode, msg_addr, msg_tag, SLOT_H5);
            hdr = build_header(1'b0, 1'b0, 1'b0,
                               SLOT_H5, SLOT_G4, SLOT_G4, SLOT_G4,
                               crd_rsp_field, 4'b0000, crd_data_field);
          end else begin
            s0_msg = build_slot0_m2s_rwd(msg_opcode, msg_addr, msg_tag, msg_poison, SLOT_H4);
            hdr = build_header(1'b0, be_hdr, sz_hdr,
                               SLOT_H4,
                               (n_chunks >= 1) ? SLOT_G0 : SLOT_G4,
                               (n_chunks >= 2) ? SLOT_G0 : SLOT_G4,
                               (n_chunks >= 3) ? SLOT_G0 : SLOT_G4,
                               crd_rsp_field, 4'b0000, crd_data_field);
          end
        end else begin
          if (msg_kind == 1'b0) begin
            s0_msg = build_slot0_s2m_h3(3'b000, 16'h0, 1'b0,
                                        msg_opcode[2:0], msg_tag,
                                        1'b0, 1'b1);
            hdr = build_header(1'b0, 1'b0, 1'b0,
                               SLOT_H3, SLOT_G5, SLOT_G5, SLOT_G5,
                               4'b0000, crd_req_field, crd_data_field);
          end else begin
            s0_msg = build_slot0_s2m_h3(msg_opcode[2:0], msg_tag, msg_poison,
                                        3'b000, 16'h0,
                                        1'b1, 1'b0);
            hdr = build_header(1'b0, 1'b0, sz_hdr,
                               SLOT_H3,
                               (n_chunks >= 1) ? SLOT_G0 : SLOT_G5,
                               (n_chunks >= 2) ? SLOT_G0 : SLOT_G5,
                               (n_chunks >= 3) ? SLOT_G0 : SLOT_G5,
                               4'b0000, crd_req_field, crd_data_field);
          end
        end
        flit_next[31:0] = hdr;
        flit_next[127:32] = s0_msg;
        if (n_chunks >= 1) flit_next[255:128] = chunks[0];
        if (n_chunks >= 2) flit_next[383:256] = chunks[1];
        if (n_chunks >= 3) flit_next[511:384] = chunks[2];
        flit_next[527:512] = 16'h0;
        flit_valid_next = 1'b1;
        if (n_chunks > 3) rem_next = n_chunks - 4'd3;
        else rem_next = 4'd0;
        crd_taken_next = 1'b1;
        lat_next = llcrd_eff;
      end else begin
        flit_valid_next = 1'b0;
        lat_next = llcrd_eff;
      end
    end else begin
      lat_next = llcrd_eff;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid     <= 1'b0;
      flit_out       <= 528'h0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem            <= 4'd0;
      lat            <= 1'b0;
    end else begin
      flit_valid     <= flit_valid_next;
      flit_out       <= flit_next;
      flit_is_control <= flit_is_control_next;
      flit_is_alldata <= flit_is_alldata_next;
      rem            <= rem_next;
      lat            <= lat_next;
    end
  end

  assign crd_taken = crd_taken_next;

endmodule
