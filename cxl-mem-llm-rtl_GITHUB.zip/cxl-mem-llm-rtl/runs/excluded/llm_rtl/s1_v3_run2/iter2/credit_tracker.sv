module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [1:0];
  logic [7:0] pend [1:0];
  logic [6:0] snd_nxt [1:0];
  logic [7:0] pend_nxt [1:0];

  function automatic logic [6:0] dec_credit(input logic [3:0] f);
    logic [6:0] v;
    begin
      if (!f[3]) v = 7'd0;
      else case (f[2:0])
        3'b000: v = 7'd0;
        3'b001: v = 7'd1;
        3'b010: v = 7'd2;
        3'b011: v = 7'd4;
        3'b100: v = 7'd8;
        3'b101: v = 7'd16;
        3'b110: v = 7'd32;
        3'b111: v = 7'd64;
      endcase
      return v;
    end
  endfunction

  function automatic logic [3:0] enc_credit(input logic [7:0] cnt);
    logic [3:0] f;
    begin
      if (cnt == 0) f = 4'b1000;
      else if (cnt >= 64) f = 4'b1111;
      else if (cnt >= 32) f = 4'b1110;
      else if (cnt >= 16) f = 4'b1101;
      else if (cnt >= 8)  f = 4'b1100;
      else if (cnt >= 4)  f = 4'b1011;
      else if (cnt >= 2)  f = 4'b1010;
      else                f = 4'b1001;
      return f;
    end
  endfunction

  always_comb begin
    // Combinational outputs from registered pend
    crd_pending = (pend[0] != 8'd0) || (pend[1] != 8'd0);
    pend_0 = pend[0];
    pend_1 = pend[1];

    if (DIRECTION == 0) begin
      crd_req_field  = 4'b0000;
      crd_data_field = enc_credit(pend[1]);
      crd_rsp_field  = enc_credit(pend[0]);
    end else begin
      crd_req_field  = enc_credit(pend[0]);
      crd_data_field = enc_credit(pend[1]);
      crd_rsp_field  = 4'b0000;
    end
  end

  always_comb begin
    for (int i = 0; i < 2; i++) begin
      logic [6:0] add;
      add = 7'd0;
      if (rx_crd_valid) begin
        if (DIRECTION == 0) begin
          if (i == 0) add = dec_credit(rx_reqcrd);
          else        add = dec_credit(rx_datacrd);
        end else begin
          if (i == 0) add = dec_credit(rx_rspcrd);
          else        add = dec_credit(rx_datacrd);
        end
      end
      snd_nxt[i] = snd[i] + add;
      if (tx_send[i] && snd[i] != 7'd0) snd_nxt[i] = snd_nxt[i] - 7'd1;
      if (snd_nxt[i] > CREDIT_MAX) snd_nxt[i] = CREDIT_MAX;

      pend_nxt[i] = pend[i] + buf_free[i];
      if (crd_taken) begin
        logic [7:0] val;
        if (DIRECTION == 0) begin
          val = (i == 0) ? dec_credit(crd_rsp_field) : dec_credit(crd_data_field);
        end else begin
          val = (i == 0) ? dec_credit(crd_req_field) : dec_credit(crd_data_field);
        end
        if (pend_nxt[i] >= val) pend_nxt[i] = pend_nxt[i] - val;
        else pend_nxt[i] = 8'd0;
      end
      if (pend_nxt[i] > PEND_MAX) pend_nxt[i] = PEND_MAX;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] <= 7'd0;
      snd[1] <= 7'd0;
      pend[0] <= RX_DEPTH[7:0];
      pend[1] <= RX_DEPTH[7:0];
    end else begin
      snd[0] <= snd_nxt[0];
      snd[1] <= snd_nxt[1];
      pend[0] <= pend_nxt[0];
      pend[1] <= pend_nxt[1];
    end
  end

  assign tx_credits_0 = snd_nxt[0];
  assign tx_credits_1 = snd_nxt[1];
  assign can_send[0] = (snd_nxt[0] != 7'd0);
  assign can_send[1] = (snd_nxt[1] != 7'd0);

endmodule
