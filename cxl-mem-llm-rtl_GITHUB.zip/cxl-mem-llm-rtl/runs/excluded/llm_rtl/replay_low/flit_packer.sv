module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_MEMRD     = 4'b0001;
  localparam logic [3:0] OP_M2S_MEMRDDATA = 4'b0010;
  localparam logic [3:0] OP_M2S_MEMWR     = 4'b0001;
  localparam logic [3:0] OP_M2S_MEMWRPTL  = 4'b0010;
  localparam logic [2:0] OP_S2M_CMP       = 3'b000;
  localparam logic [2:0] OP_S2M_MEMDATA   = 3'b000;

  // Registered state
  logic [3:0] rem;
  logic       lat;
  logic [127:0] chunk_buf [0:MAX_CHUNKS-1];
  logic [3:0] total_chunks;
  logic [2:0] rollover_slot0_fmt;
  logic       rollover_sz_bit;
  logic       rollover_be_bit;

  // Combinational signals
  logic slot_free;
  logic llcrd_eff;
  logic msg_ready_int;

  logic [527:0] flit_next;
  logic         flit_valid_next;
  logic         flit_is_control_next;
  logic         flit_is_alldata_next;
  logic [3:0]   rem_next;
  logic         lat_next;
  logic         crd_taken_next;

  logic [127:0] slot0;
  logic [127:0] slot1, slot2, slot3;
  logic [15:0]  crc16;

  // Combinational: next-state logic
  always_comb begin
    slot_free    = !flit_valid || flit_ready;
    llcrd_eff    = lat || force_llcrd;
    msg_ready_int = rst_n && slot_free && (rem == 0) && !llcrd_eff;

    // Defaults
    flit_next = '0;
    flit_valid_next = 1'b0;
    flit_is_control_next = 1'b0;
    flit_is_alldata_next = 1'b0;
    rem_next = rem;
    lat_next = lat;
    crd_taken_next = 1'b0;
    crc16 = 16'h0000;

    // Build slot0 for LLCRD (used if llcrd_eff)
    logic [127:0] llcrd_slot0;
    llcrd_slot0 = '0;
    llcrd_slot0[0] = 1'b1;                 // Type = 1 (Control)
    llcrd_slot0[1] = 1'b0;                 // RV
    llcrd_slot0[2] = 1'b0;                 // Ak
    llcrd_slot0[4:3] = 2'b00;              // BE=0, Sz=0
    llcrd_slot0[7:5] = 3'b000;             // CTL_FMT = 000
    llcrd_slot0[15:8] = 8'h00;             // RSVD
    llcrd_slot0[19:16] = 4'h0;             // RSVD
    llcrd_slot0[23:20] = crd_rsp_field;    // RspCrd
    llcrd_slot0[27:24] = crd_req_field;    // ReqCrd
    llcrd_slot0[31:28] = crd_data_field;   // DataCrd
    llcrd_slot0[35:32] = 4'b0000;          // LLCTRL = 0000 (LLCRD)
    llcrd_slot0[39:36] = 4'b0000;          // SubType = 0000
    llcrd_slot0[63:40] = 24'h000000;       // RSVD
    llcrd_slot0[127:64] = 64'h0;           // Payload = 0

    if (slot_free) begin
      // Priority 1: Rollover
      if (rem > 0) begin
        if (rem > 4'd3) begin
          // All-data flit: 4 data chunks
          flit_next[127:0]   = chunk_buf[total_chunks - rem];
          flit_next[255:128] = chunk_buf[total_chunks - rem + 1];
          flit_next[383:256] = chunk_buf[total_chunks - rem + 2];
          flit_next[511:384] = chunk_buf[total_chunks - rem + 3];
          flit_next[527:512] = crc16;
          flit_valid_next = 1'b1;
          flit_is_alldata_next = 1'b1;
          rem_next = rem - 4;
          lat_next = llcrd_eff;
          crd_taken_next = 1'b0; // no header on all-data flit
        end else begin
          // Protocol flit with rollover chunks in slots 1..rem
          // Build empty header slot0
          slot0 = '0;
          slot0[0] = 1'b0; // Type = Protocol
          slot0[1] = 1'b0; // RV
          slot0[2] = 1'b0; // Ak
          slot0[3] = 1'b0; // BE = 0 (no new data message)
          slot0[4] = 1'b0; // Sz = 0
          slot0[7:5] = rollover_slot0_fmt;
          if (DIRECTION == 0) begin
            slot0[10:8] = SLOT_G4;
            slot0[13:11] = SLOT_G4;
            slot0[16:14] = SLOT_G4;
          end else begin
            slot0[10:8] = SLOT_G5;
            slot0[13:11] = SLOT_G5;
            slot0[16:14] = SLOT_G5;
          end
          slot0[19:17] = 3'b000;
          slot0[23:20] = crd_rsp_field;
          slot0[27:24] = crd_req_field;
          slot0[31:28] = crd_data_field;
          // Message part all zeros (Valid=0)

          flit_next[127:0] = slot0;
          if (rem >= 1) flit_next[255:128] = chunk_buf[total_chunks - rem];
          if (rem >= 2) flit_next[383:256] = chunk_buf[total_chunks - rem + 1];
          if (rem >= 3) flit_next[511:384] = chunk_buf[total_chunks - rem + 2];
          flit_next[527:512] = crc16;
          flit_valid_next = 1'b1;
          rem_next = 0;
          lat_next = llcrd_eff;
          crd_taken_next = 1'b1;
        end
      end
      // Priority 2: LLCRD
      else if (llcrd_eff) begin
        flit_next[127:0] = llcrd_slot0;
        flit_next[527:128] = '0;
        flit_next[527:512] = crc16;
        flit_valid_next = 1'b1;
        flit_is_control_next = 1'b1;
        lat_next = 1'b0;
        crd_taken_next = 1'b1;
      end
      // Priority 3: New message
      else if (msg_valid) begin
        // Determine message parameters and build chunk buffer
        logic [3:0] n_chunks;
        logic       sz_bit, be_bit;
        logic [2:0] slot0_fmt;
        logic [127:0] msg_slot0;

        // Compute message-specific fields
        n_chunks = 0;
        sz_bit = 1'b0;
        be_bit = 1'b0;
        slot0_fmt = SLOT_H5;
        msg_slot0 = '0;

        if (DIRECTION == 0) begin // M2S
          if (msg_kind == 1'b0) begin // Req
            slot0_fmt = SLOT_H5;
            msg_slot0[32] = 1'b1; // Valid at bit 32 of slot
            msg_slot0[36:33] = msg_opcode;
            msg_slot0[39:37] = 3'b000; // SnpType
            msg_slot0[41:40] = 2'b11;  // MetaField
            msg_slot0[43:42] = 2'b00;  // MetaValue
            msg_slot0[59:44] = msg_tag;
            msg_slot0[106:60] = msg_addr[51:5];
            msg_slot0[108:107] = 2'b00; // TC
            msg_slot0[112:109] = 4'b0000; // LD-ID
            msg_slot0[118:113] = 6'b000000; // RSVD
            n_chunks = 0;
          end else begin // RwD
            slot0_fmt = SLOT_H4;
            msg_slot0[32] = 1'b1;
            msg_slot0[36:33] = msg_opcode;
            msg_slot0[39:37] = 3'b000;
            msg_slot0[41:40] = 2'b11;
            msg_slot0[43:42] = 2'b00;
            msg_slot0[59:44] = msg_tag;
            msg_slot0[105:60] = msg_addr[51:6];
            msg_slot0[106] = msg_poison;
            msg_slot0[108:107] = 2'b00;
            msg_slot0[112:109] = 4'b0000;
            msg_slot0[118:113] = 6'b000000;
            sz_bit = 1'b1;
            if (msg_opcode == OP_M2S_MEMWRPTL) begin
              be_bit = 1'b1;
            end
          end
        end else begin // S2M
          if (msg_kind == 1'b0) begin // NDR
            slot0_fmt = SLOT_H3;
            msg_slot0[72] = 1'b1; // Valid at bit 72 (second message in H3)
            msg_slot0[75:73] = msg_opcode[2:0];
            msg_slot0[77:76] = 2'b11;
            msg_slot0[79:78] = 2'b00;
            msg_slot0[95:80] = msg_tag;
            msg_slot0[99:96] = 4'b0000;
            msg_slot0[101:100] = 2'b00;
            n_chunks = 0;
          end else begin // DRS
            slot0_fmt = SLOT_H3;
            msg_slot0[32] = 1'b1; // Valid at bit 32 (first message in H3)
            msg_slot0[35:33] = msg_opcode[2:0];
            msg_slot0[37:36] = 2'b11;
            msg_slot0[39:38] = 2'b00;
            msg_slot0[55:40] = msg_tag;
            msg_slot0[56] = msg_poison;
            msg_slot0[60:57] = 4'b0000;
            msg_slot0[62:61] = 2'b00;
            msg_slot0[71:63] = 9'b0;
            sz_bit = 1'b1;
            n_chunks = 4;
          end
        end

        // Override chunk count if enabled
        if (chunks_ovr_en) begin
          n_chunks = chunks_ovr;
        end

        // Fill chunk buffer
        for (int i = 0; i < MAX_CHUNKS; i++) begin
          chunk_buf[i] = '0; // default
        end
        if (DIRECTION == 0) begin
          if (msg_kind == 1'b1) begin // RwD
            if (msg_opcode == OP_M2S_MEMWRPTL) begin
              // 4 data chunks + 1 BE chunk
              for (int i = 0; i < 4; i++) begin
                chunk_buf[i] = msg_data[128*i +: 128];
              end
              // BE chunk: BE[31:0] in bytes 0-3, BE[63:32] in bytes 4-7, rest 0
              chunk_buf[4] = {64'h0, msg_byte_en};
              total_chunks = (chunks_ovr_en) ? chunks_ovr : 5;
            end else begin // MemWr
              for (int i = 0; i < 4; i++) begin
                chunk_buf[i] = msg_data[128*i +: 128];
              end
              total_chunks = (chunks_ovr_en) ? chunks_ovr : 4;
            end
          end else begin // Req
            total_chunks = 0;
          end
        end else begin // S2M
          if (msg_kind == 1'b1) begin // DRS
            for (int i = 0; i < 4; i++) begin
              chunk_buf[i] = msg_data[128*i +: 128];
            end
            total_chunks = (chunks_ovr_en) ? chunks_ovr : 4;
          end else begin // NDR
            total_chunks = 0;
          end
        end

        // Build first flit
        slot0 = '0;
        slot0[0] = 1'b0; // Type
        slot0[1] = 1'b0; // RV
        slot0[2] = 1'b0; // Ak
        slot0[3] = be_bit;
        slot0[4] = sz_bit;
        slot0[7:5] = slot0_fmt;
        if (DIRECTION == 0) begin
          slot0[10:8] = SLOT_G4;
          slot0[13:11] = SLOT_G4;
          slot0[16:14] = SLOT_G4;
        end else begin
          slot0[10:8] = SLOT_G5;
          slot0[13:11] = SLOT_G5;
          slot0[16:14] = SLOT_G5;
        end
        slot0[19:17] = 3'b000;
        slot0[23:20] = crd_rsp_field;
        slot0[27:24] = crd_req_field;
        slot0[31:28] = crd_data_field;
        slot0[127:32] = msg_slot0[127:32]; // message occupies bits 127:32

        flit_next[127:0] = slot0;
        if (total_chunks >= 1) flit_next[255:128] = chunk_buf[0];
        if (total_chunks >= 2) flit_next[383:256] = chunk_buf[1];
        if (total_chunks >= 3) flit_next[511:384] = chunk_buf[2];
        flit_next[527:512] = crc16;
        flit_valid_next = 1'b1;

        // Save rollover state
        if (total_chunks > 3) begin
          rem_next = total_chunks - 3;
          rollover_slot0_fmt = slot0_fmt;
          rollover_sz_bit = sz_bit;
          rollover_be_bit = be_bit;
        end else begin
          rem_next = 0;
        end
        lat_next = llcrd_eff;
        crd_taken_next = 1'b1;
      end
      // Priority 4: Idle
      else begin
        flit_valid_next = 1'b0;
        lat_next = llcrd_eff;
      end
    end else begin
      // Output register full, hold state
      lat_next = llcrd_eff;
    end
  end

  // Sequential registers
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid     <= 1'b0;
      flit_out       <= '0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem            <= 4'd0;
      lat            <= 1'b0;
      total_chunks   <= 4'd0;
      rollover_slot0_fmt <= 3'd0;
      rollover_sz_bit <= 1'b0;
      rollover_be_bit <= 1'b0;
      for (int i = 0; i < MAX_CHUNKS; i++) begin
        chunk_buf[i] <= '0;
      end
    end else begin
      flit_valid     <= flit_valid_next;
      flit_out       <= flit_next;
      flit_is_control <= flit_is_control_next;
      flit_is_alldata <= flit_is_alldata_next;
      rem            <= rem_next;
      lat            <= lat_next;
      if (msg_valid && msg_ready_int) begin
        total_chunks <= total_chunks; // already set in combinational? Need to capture total_chunks from combinational.
        // Actually total_chunks is computed in combinational block but not passed to sequential.
        // We'll compute total_chunks in combinational and store it in a signal, then register it.
      end
    end
  end

  // We need to register total_chunks and chunk_buf when a new message is accepted.
  // Let's move the chunk buffer loading and total_chunks computation to a separate always_comb that feeds registers.
  // But we already have the logic in the big always_comb. We can register the computed values.
  // We'll add registers for the chunk buffer and total_chunks, and update them when msg_valid && msg_ready_int.

  // However, the above always_comb already computes chunk_buf and total_chunks as combinational variables.
  // We need to store them in registers. Let's restructure: have a separate always_comb for message decoding that outputs the chunk buffer and total_chunks, then register them when message accepted.

  // Given the complexity, we'll keep the current structure but add registers for chunk_buf and total_chunks that are updated in the sequential block when msg_valid && msg_ready_int.
  // We'll compute the chunk buffer and total_chunks in a separate always_comb that is only used when loading.

  // But to avoid major rewrite, we can compute the chunk buffer and total_chunks in the same always_comb and then assign them to registers in the sequential block using the same condition.
  // However, the always_comb block above uses chunk_buf and total_chunks from registers for rollover. So we need to update the registers when a new message starts.

  // Let's create a separate always_comb for message decoding that produces the chunk buffer and total_chunks for the current message inputs.
  // Then in the sequential block, when msg_valid && msg_ready_int, we load those into registers.

  // We'll do that now.

endmodule
