module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [0:1];
  logic [7:0] pend [0:1];

  logic [6:0] snd_next [0:1];
  logic [7:0] pend_next [0:1];

  logic [6:0] add_snd [0:1];
  logic [7:0] sub_pend [0:1];

  function automatic logic [6:0] dec_crd(input logic [3:0] f);
    logic [2:0] v;
    v = f[2:0];
    case (v)
      3'b000: dec_crd = 7'd0;
      3'b001: dec_crd = 7'd1;
      3'b010: dec_crd = 7'd2;
      3'b011: dec_crd = 7'd4;
      3'b100: dec_crd = 7'd8;
      3'b101: dec_crd = 7'd16;
      3'b110: dec_crd = 7'd32;
      3'b111: dec_crd = 7'd64;
    endcase
  endfunction

  function automatic logic [3:0] enc_crd(input logic [7:0] cnt);
    logic [2:0] e;
    if (cnt >= 64) e = 3'b111;
    else if (cnt >= 32) e = 3'b110;
    else if (cnt >= 16) e = 3'b101;
    else if (cnt >= 8)  e = 3'b100;
    else if (cnt >= 4)  e = 3'b011;
    else if (cnt >= 2)  e = 3'b010;
    else if (cnt >= 1)  e = 3'b001;
    else                e = 3'b000;
    enc_crd = {1'b1, e};
  endfunction

  always_comb begin
    add_snd[0] = 7'd0;
    add_snd[1] = 7'd0;
    if (rx_crd_valid) begin
      if (DIRECTION == 0) begin
        if (rx_reqcrd[3]) add_snd[0] = dec_crd(rx_reqcrd);
        if (rx_datacrd[3]) add_snd[1] = dec_crd(rx_datacrd);
      end else begin
        if (rx_rspcrd[3]) add_snd[0] = dec_crd(rx_rspcrd);
        if (rx_datacrd[3]) add_snd[1] = dec_crd(rx_datacrd);
      end
    end

    sub_pend[0] = 8'd0;
    sub_pend[1] = 8'd0;
    if (crd_taken) begin
      if (DIRECTION == 0) begin
        if (crd_rsp_field[3]) sub_pend[0] = dec_crd(crd_rsp_field);
        if (crd_data_field[3]) sub_pend[1] = dec_crd(crd_data_field);
      end else begin
        if (crd_req_field[3]) sub_pend[0] = dec_crd(crd_req_field);
        if (crd_data_field[3]) sub_pend[1] = dec_crd(crd_data_field);
      end
    end

    for (int i = 0; i < 2; i++) begin
      logic [6:0] snd_tmp;
      logic [7:0] pend_tmp;
      snd_tmp = snd[i];
      if (tx_send[i] && snd_tmp != 0) snd_tmp = snd_tmp - 1;
      snd_tmp = snd_tmp + add_snd[i];
      if (snd_tmp > CREDIT_MAX) snd_tmp = CREDIT_MAX;
      snd_next[i] = snd_tmp;

      pend_tmp = pend[i];
      if (pend_tmp >= sub_pend[i]) pend_tmp = pend_tmp - sub_pend[i];
      else pend_tmp = 0;
      pend_tmp = pend_tmp + buf_free[i];
      if (pend_tmp > PEND_MAX) pend_tmp = PEND_MAX;
      pend_next[i] = pend_tmp;
    end
  end

  always_comb begin
    can_send[0] = (snd[0] != 0);
    can_send[1] = (snd[1] != 0);

    crd_req_field  = 4'b0000;
    crd_data_field = 4'b0000;
    crd_rsp_field  = 4'b0000;

    if (DIRECTION == 0) begin
      if (pend[0] > 0) crd_rsp_field  = enc_crd(pend[0]);
      if (pend[1] > 0) crd_data_field = enc_crd(pend[1]);
    end else begin
      if (pend[0] > 0) crd_req_field  = enc_crd(pend[0]);
      if (pend[1] > 0) crd_data_field = enc_crd(pend[1]);
    end

    crd_pending = (pend[0] > 0) || (pend[1] > 0);
    pend_0 = pend[0];
    pend_1 = pend[1];
    tx_credits_0 = snd[0];
    tx_credits_1 = snd[1];
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0]  <= 7'd0;
      snd[1]  <= 7'd0;
      pend[0] <= RX_DEPTH[7:0];
      pend[1] <= RX_DEPTH[7:0];
    end else begin
      snd[0]  <= snd_next[0];
      snd[1]  <= snd_next[1];
      pend[0] <= pend_next[0];
      pend[1] <= pend_next[1];
    end
  end

endmodule
