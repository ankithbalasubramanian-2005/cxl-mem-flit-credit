module flit_packer #(
  parameter int DIRECTION  = 0,     // 0 = M2S, 1 = S2M
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_takn,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  // Slot format selectors (CXL Table 50)
  localparam logic [2:0] SEL_G0    = 3'b000;
  localparam logic [2:0] SEL_H3    = 3'b011;
  localparam logic [2:0] SEL_H4    = 3'b100;
  localparam logic [2:0] SEL_H5    = 3'b101;
  localparam logic [2:0] SEL_EMPTY = (DIRECTION == 0) ? 3'b100 : 3'b101; // G4 / G5
  localparam logic [2:0] SEL_NOMSG = (DIRECTION == 0) ? SEL_H5 : SEL_H3;

  // ---------------- state ----------------
  logic [128*MAX_CHUNKS-1:0] rbuf;      // chunks of the message in flight
  logic [3:0]                rd_idx;    // next chunk index in rbuf
  logic [3:0]                rem;       // rollover chunks remaining
  logic                      lat;       // latched force_llcrd

  // ---------------- header (Table 45, Fig. 53/54/66) ----------------
  function automatic logic [31:0] hdr(input logic type_, input logic be, input logic sz,
                                      input logic [2:0] s0, input logic [2:0] s1,
                                      input logic [2:0] s2, input logic [2:0] s3);
    hdr = {crd_data_field, crd_req_field, crd_rsp_field, 3'b000,
           s3, s2, s1, s0, sz, be, 1'b0 /*Ak*/, 1'b0 /*RV*/, type_};
  endfunction

  // ---------------- message of the current input ----------------
  logic        is_data, be_on;
  logic [3:0]  total;
  logic [127:0] mchunk [0:MAX_CHUNKS-1];
  logic [95:0] msg_bits;                 // Slot-0 bits [127:32]
  logic [2:0]  sel0;

  always_comb begin
    is_data = msg_kind;
    be_on   = (DIRECTION == 0) && msg_kind && (msg_opcode == 4'b0010);
    if (chunks_ovr_en)      total = chunks_ovr;
    else if (!is_data)      total = 4'd0;
    else                    total = be_on ? 4'd5 : 4'd4;
    for (int i = 0; i < MAX_CHUNKS; i++) begin
      if (!chunks_ovr_en && be_on && i == 4) mchunk[i] = {64'b0, msg_byte_en};
      else                                   mchunk[i] = msg_data[128*i +: 128];
    end
    msg_bits = '0;
    if (DIRECTION == 0) begin
      if (!msg_kind) begin  // M2S Req, Fig. 54
        msg_bits[86:0] = {6'b0, 4'b0, 2'b0, msg_addr[51:5], msg_tag,
                          2'b00, 2'b11, 3'b000, msg_opcode, 1'b1};
        sel0 = SEL_H5;
      end else begin        // M2S RwD, Fig. 53
        msg_bits[86:0] = {6'b0, 4'b0, 2'b0, msg_poison, msg_addr[51:6], msg_tag,
                          2'b00, 2'b11, 3'b000, msg_opcode, 1'b1};
        sel0 = SEL_H4;
      end
    end else begin
      sel0 = SEL_H3;
      if (msg_kind)         // DRS at [71:32], Fig. 66
        msg_bits[39:0]  = {9'b0, 2'b00, 4'b0, msg_poison, msg_tag,
                           2'b00, 2'b11, msg_opcode[2:0], 1'b1};
      else                  // NDR at [101:72]
        msg_bits[69:40] = {2'b00, 4'b0, msg_tag, 2'b00, 2'b11, msg_opcode[2:0], 1'b1};
    end
  end

  // ---------------- decision ----------------
  logic slot_free, llcrd_eff, dec_roll, dec_llcrd, dec_msg, dec_none;
  always_comb begin
    slot_free = !flit_valid || flit_ready;
    llcrd_eff = lat || force_llcrd;
    dec_roll  = rst_n && slot_free && (rem != 0);
    dec_llcrd = rst_n && slot_free && (rem == 0) && llcrd_eff;
    dec_msg   = rst_n && slot_free && (rem == 0) && !llcrd_eff && msg_valid;
    dec_none  = rst_n && slot_free && (rem == 0) && !llcrd_eff && !msg_valid;
    msg_ready = rst_n && slot_free && (rem == 0) && !llcrd_eff;
    crd_takn = dec_llcrd || dec_msg || (dec_roll && rem <= 4'd3);
  end

  // ---------------- next flit ----------------
  logic [527:0] nxt_flit;
  logic [2:0]   s [1:3];
  logic [127:0] g [1:3];

  always_comb begin
    nxt_flit = '0;
    for (int k = 1; k <= 3; k++) begin s[k] = SEL_EMPTY; g[k] = '0; end
    if (dec_roll && rem > 4'd3) begin
      for (int k = 0; k < 4; k++)
        nxt_flit[128*k +: 128] = rbuf[128*(rd_idx+k) +: 128];
    end else if (dec_roll) begin
      for (int k = 1; k <= 3; k++)
        if (k <= rem) begin s[k] = SEL_G0; g[k] = rbuf[128*(rd_idx+k-1) +: 128]; end
      nxt_flit[127:0]   = {96'b0, hdr(1'b0, 1'b0, 1'b0, SEL_NOMSG, s[1], s[2], s[3])};
      nxt_flit[255:128] = g[1];
      nxt_flit[383:256] = g[2];
      nxt_flit[511:384] = g[3];
    end else if (dec_llcrd) begin   // Fig. 78
      nxt_flit[127:0] = {64'b0, 24'b0, 4'b0000 /*SubType*/, 4'b0000 /*LLCTRL*/,
                         crd_data_field, crd_req_field, crd_rsp_field, 4'b0,
                         8'b0, 3'b000 /*CTL_FMT*/, 2'b0, 1'b0, 1'b0, 1'b1};
    end else if (dec_msg) begin
      for (int k = 1; k <= 3; k++)
        if (k <= total) begin s[k] = SEL_G0; g[k] = mchunk[k-1]; end
      nxt_flit[127:0]   = {msg_bits, hdr(1'b0, be_on, is_data, sel0, s[1], s[2], s[3])};
      nxt_flit[255:128] = g[1];
      nxt_flit[383:256] = g[2];
      nxt_flit[511:384] = g[3];
    end
  end

  // ---------------- registers ----------------
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid <= 1'b0; flit_out <= '0; flit_is_control <= 1'b0; flit_is_alldata <= 1'b0;
      rem <= '0; rd_idx <= '0; lat <= 1'b0; rbuf <= '0;
    end else if (!slot_free) begin
      lat <= llcrd_eff;
    end else begin
      flit_out        <= nxt_flit;
      flit_valid      <= !dec_none;
      flit_is_control <= dec_llcrd;
      flit_is_alldata <= dec_roll && (rem > 4'd3);
      lat             <= dec_llcrd ? 1'b0 : llcrd_eff;
      if (dec_roll) begin
        if (rem > 4'd3) begin rem <= rem - 4'd4; rd_idx <= rd_idx + 4'd4; end
        else            begin rem <= '0; end
      end else if (dec_msg) begin
        for (int i = 0; i < MAX_CHUNKS; i++) rbuf[128*i +: 128] <= mchunk[i];
        rd_idx <= 4'd3;
        rem    <= (total > 4'd3) ? total - 4'd3 : 4'd0;
      end
    end
  end

endmodule
