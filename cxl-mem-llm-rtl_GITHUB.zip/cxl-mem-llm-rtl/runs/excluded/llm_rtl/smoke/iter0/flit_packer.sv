module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  // Opcode definitions
  localparam logic [3:0] MemRd      = 4'b0001;
  localparam logic [3:0] MemRdData  = 4'b0010;
  localparam logic [3:0] MemWr      = 4'b0001;
  localparam logic [3:0] MemWrPtl   = 4'b0010;
  localparam logic [2:0] Cmp        = 3'b000;
  localparam logic [2:0] MemData    = 3'b000;

  // Message type enumeration
  typedef enum logic [2:0] {
    MT_Req   = 3'b000,
    MT_RwD   = 3'b001,
    MT_NDR   = 3'b010,
    MT_DRS   = 3'b011
  } msg_type_t;

  // Internal registers
  reg [3:0] rem;                     // remaining chunks to send
  reg [3:0] chunk_idx;               // index of next chunk to send
  reg [3:0] total_chunks;            // total chunks for current message
  reg [2:0] cur_msg_type;            // current message type
  reg [3:0] cur_msg_opcode;
  reg [51:0] cur_msg_addr;
  reg [15:0] cur_msg_tag;
  reg cur_msg_poison;
  reg [63:0] cur_msg_byte_en;
  reg [128*MAX_CHUNKS-1:0] cur_msg_data;
  reg [127:0] chunk_list[0:7];       // chunk storage
  reg lat;                           // latched force_llcrd

  // Output registers
  reg flit_valid_reg;
  reg [527:0] flit_out_reg;
  reg flit_is_control_reg;
  reg flit_is_alldata_reg;

  // Internal wires
  wire slot_free = !flit_valid_reg || flit_ready;
  wire llcrd_eff = lat || force_llcrd;
  wire msg_ready_internal = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  // Priority selection for next flit
  wire rollover = (rem > 0);
  wire llcrd   = llcrd_eff && !rollover;
  wire new_msg = msg_valid && msg_ready_internal && !rollover && !llcrd;

  // Output ports
  assign msg_ready = msg_ready_internal;
  assign crd_taken = (flit_valid_reg && !flit_is_alldata_reg) ? 1'b1 : 1'b0;
  assign flit_valid = flit_valid_reg;
  assign flit_out   = flit_out_reg;
  assign flit_is_control = flit_is_control_reg;
  assign flit_is_alldata  = flit_is_alldata_reg;

  // Helper functions for slot format selectors
  function automatic [2:0] get_slot_fmt(input int direction, input bit is_data);
    if (is_data) begin
      return 3'b000; // G0
    end else begin
      if (direction == 0) begin
        return 3'b100; // G4 (M2S empty)
      end else begin
        return 3'b101; // G5 (S2M empty)
      end
    end
  endfunction

  // Helper function to generate message bits for M2S Req (H5)
  function automatic [95:0] make_msg_bits_req(input logic [3:0] opcode,
                                             input logic [51:0] addr,
                                             input logic [15:0] tag);
    // Message bits (96 bits) little-endian: Valid (bit0), opcode bits1-4, etc.
    return {
      1'b1,                     // Valid
      opcode,                   // MemOpcode (4 bits)
      3'b000,                   // SnpType (000)
      2'b11,                    // MetaField (11)
      2'b00,                    // MetaValue (00)
      tag,                      // Tag (16 bits)
      addr[51:5],               // Address[51:5] (47 bits)
      2'b00,                    // TC (00)
      4'b0000,                  // LD-ID (0000)
      6'b0,                     // RSVD (000000)
      9'b0                      // Pad (000000000)
    };
  endfunction

  // Helper function to generate message bits for M2S RwD (H4)
  function automatic [95:0] make_msg_bits_rwd(input logic [3:0] opcode,
                                             input logic [51:0] addr,
                                             input logic poison,
                                             input logic [15:0] tag);
    return {
      1'b1,                     // Valid
      opcode,                   // MemOpcode (4 bits)
      3'b000,                   // SnpType (000)
      2'b11,                    // MetaField (11)
      2'b00,                    // MetaValue (00)
      tag,                      // Tag (16 bits)
      addr[51:6],               // Address[51:6] (46 bits)
      poison,                   // Poison (1 bit)
      2'b00,                    // TC (00)
      4'b0000,                  // LD-ID (0000)
      6'b0,                     // RSVD (000000)
      9'b0                      // Pad (000000000)
    };
  endfunction

  // Helper function to generate message bits for S2M DRS (first position of H3)
  function automatic [39:0] make_msg_bits_drs(input logic [2:0] opcode,
                                             input logic [15:0] tag,
                                             input logic poison);
    return {
      1'b1,                     // Valid
      opcode,                   // Opcode (3 bits)
      2'b11,                    // MetaField (11)
      2'b00,                    // MetaValue (00)
      tag,                      // Tag (16 bits)
      poison,                   // Poison (1 bit)
      4'b0000,                  // LD-ID (0000)
      2'b00,                    // DevLoad (00)
      9'b0                      // RSVD (000000000)
    };
  endfunction

  // Helper function to generate message bits for S2M NDR (second position of H3)
  function automatic [29:0] make_msg_bits_ndr(input logic [2:0] opcode,
                                             input logic [15:0] tag);
    return {
      1'b1,                     // Valid
      opcode,                   // Opcode (3 bits)
      2'b11,                    // MetaField (11)
      2'b00,                    // MetaValue (00)
      tag,                      // Tag (16 bits)
      4'b0000,                  // LD-ID (0000)
      2'b00,                    // DevLoad (00)
      26'b0                     // RSVD/pad (000...0)
    };
  endfunction

  // Helper function to generate header bits for a protocol flit
  function automatic [31:0] make_header(input bit type_bit,
                                        input bit rv,
                                        input bit ak,
                                        input bit be,
                                        input bit sz,
                                        input [2:0] slot0_fmt,
                                        input [2:0] slot1_fmt,
                                        input [2:0] slot2_fmt,
                                        input [2:0] slot3_fmt,
                                        input [3:0] rsp_crd,
                                        input [3:0] req_crd,
                                        input [3:0] data_crd);
    return {
      type_bit, rv, ak, be, sz,
      slot0_fmt, slot1_fmt, slot2_fmt, slot3_fmt,
      3'b0,                     // RSVD[19:17] = 0
      rsp_crd,
      req_crd,
      data_crd
    };
  endfunction

  // Helper function to generate LLCRD slot0
  function automatic [127:0] make_llcrd_slot0(input [3:0] rsp_crd,
                                             input [3:0] req_crd,
                                             input [3:0] data_crd);
    return {
      64'b0,                    // bytes 5-7 (bits [63:40]) = 0
      4'b0,                     // SubType = 0
      4'b0,                     // LLCTRL = 0
      data_crd,                 // DataCrd
      req_crd,                  // ReqCrd
      rsp_crd,                  // RspCrd
      4'b0,                     // RSVD[19:16] = 0
      8'b0,                     // RSVD[15:8] = 0
      3'b000,                   // CTL_FMT = 000
      2'b0,                     // RSVD[4:3] = 0
      3'b100                    // Type=1, RV=0, Ak=0
    };
  endfunction

  // Main clocked process
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      // Reset all registers
      flit_valid_reg <= 1'b0;
      flit_out_reg <= {528{1'b0}};
      flit_is_control_reg <= 1'b0;
      flit_is_alldata_reg <= 1'b0;
      rem <= 0;
      chunk_idx <= 0;
      total_chunks <= 0;
      cur_msg_type <= MT_Req;
      cur_msg_opcode <= 4'b0;
      cur_msg_addr <= 0;
      cur_msg_tag <= 0;
      cur_msg_poison <= 0;
      cur_msg_byte_en <= 0;
      cur_msg_data <= {128*MAX_CHUNKS{1'b0}};
      lat <= 0;
    end else begin
      // Default values for outputs
      flit_valid_reg <= 1'b0;
      flit_out_reg <= flit_out_reg; // hold
      flit_is_control_reg <= flit_is_control_reg;
      flit_is_alldata_reg <= flit_is_alldata_reg;

      // Accept new message if conditions met
      if (msg_valid && msg_ready_internal) begin
        // Store message fields
        cur_msg_type <= (DIRECTION == 0) ? ((msg_kind == 0) ? MT_Req : MT_RwD) :
                                       ((msg_kind == 0) ? MT_NDR : MT_DRS);
        cur_msg_opcode <= msg_opcode;
        cur_msg_addr <= msg_addr;
        cur_msg_tag <= msg_tag;
        cur_msg_poison <= msg_poison;
        cur_msg_byte_en <= msg_byte_en;
        cur_msg_data <= msg_data;

        // Compute total_chunks based on message type and override
        if (chunks_ovr_en) begin
          total_chunks <= chunks_ovr;
        end else begin
          case (cur_msg_type)
            MT_Req:   total_chunks <= 0;
            MT_RwD:   total_chunks <= (cur_msg_opcode == MemWrPtl) ? 5 : 4;
            MT_NDR:   total_chunks <= 0;
            MT_DRS:   total_chunks <= 4;
            default:  total_chunks <= 0;
          endcase
        end

        // Fill chunk_list based on message type
        case (cur_msg_type)
          MT_RwD: begin
            if (cur_msg_opcode == MemWrPtl) begin
              // Data chunks 0-3 from msg_data
              chunk_list[0] <= cur_msg_data[127:0];
              chunk_list[1] <= cur_msg_data[255:128];
              chunk_list[2] <= cur_msg_data[383:256];
              chunk_list[3] <= cur_msg_data[511:384];
              // BE chunk
              chunk_list[4] <= {64'b0, cur_msg_byte_en};
            end else begin
              chunk_list[0] <= cur_msg_data[127:0];
              chunk_list[1] <= cur_msg_data[255:128];
              chunk_list[2] <= cur_msg_data[383:256];
              chunk_list[3] <= cur_msg_data[511:384];
            end
          end
          MT_DRS: begin
            chunk_list[0] <= cur_msg_data[127:0];
            chunk_list[1] <= cur_msg_data[255:128];
            chunk_list[2] <= cur_msg_data[383:256];
            chunk_list[3] <= cur_msg_data[511:384];
          end
          default: begin
            // No data chunks
          end
        endcase

        // Initialize state for packing
        rem <= total_chunks;
        chunk_idx <= 0;
      end

      // Determine next flit based on priority
      if (rollover) begin
        // --- Rollover flit ---
        // Determine if all-data flit (rem > 3)
        if (rem > 3) begin
          // All-data flit: output 4 chunks in slots 0-3
          flit_valid_reg <= 1'b1;
          flit_is_control_reg <= 1'b0;
          flit_is_alldata_reg <= 1'b1;

          // Build flit_out: slots 0-3 = chunks[chunk_idx] .. [chunk_idx+3]
          flit_out_reg <= {
            // slot3
            chunk_list[chunk_idx+3],
            // slot2
            chunk_list[chunk_idx+2],
            // slot1
            chunk_list[chunk_idx+1],
            // slot0
            chunk_list[chunk_idx],
            // CRC = 0
            16'b0
          };

          // Update state
          rem <= rem - 4;
          chunk_idx <= chunk_idx + 4;
        end else begin
          // Protocol rollover flit (rem == 1,2,3)
          flit_valid_reg <= 1'b1;
          flit_is_control_reg <= 1'b0;
          flit_is_alldata_reg <= 1'b0;

          // Determine which slots contain data
          logic [2:0] slot1_fmt, slot2_fmt, slot3_fmt;
          logic [2:0] slot0_fmt;
          logic [127:0] slot0, slot1, slot2, slot3;

          // Slot0 format: based on direction and message type (no message)
          if (DIRECTION == 0) begin
            if (cur_msg_type == MT_Req) begin
              slot0_fmt = 3'b101; // H5
            end else if (cur_msg_type == MT_RwD) begin
              slot0_fmt = 3'b100; // H4
            end else begin
              slot0_fmt = 3'b000; // default
            end
          end else begin
            slot0_fmt = 3'b011; // H3
          end

          // Slot1-3 formats: data or empty
          if (rem >= 3) begin
            slot1_fmt = 3'b000;
            slot2_fmt = 3'b000;
            slot3_fmt = 3'b000;
          end else if (rem == 2) begin
            slot1_fmt = 3'b000;
            slot2_fmt = 3'b000;
            slot3_fmt = get_slot_fmt(DIRECTION, 0);
          end else if (rem == 1) begin
            slot1_fmt = 3'b000;
            slot2_fmt = get_slot_fmt(DIRECTION, 0);
            slot3_fmt = get_slot_fmt(DIRECTION, 0);
          end else begin
            slot1_fmt = get_slot_fmt(DIRECTION, 0);
            slot2_fmt = get_slot_fmt(DIRECTION, 0);
            slot3_fmt = get_slot_fmt(DIRECTION, 0);
          end

          // Build slot0 (header with no message)
          slot0 = {make_header(
            1'b0, // Type = Protocol
            1'b0, // RV
            1'b0, // Ak
            1'b0, // BE
            1'b0, // Sz
            slot0_fmt,
            slot1_fmt,
            slot2_fmt,
            slot3_fmt,
            crd_rsp_field,
            crd_req_field,
            crd_data_field
          )};

          // Build data slots
          slot1 = (rem >= 3) ? chunk_list[chunk_idx] : {128{1'b0}};
          slot2 = (rem >= 2) ? chunk_list[chunk_idx+1] : {128{1'b0}};
          slot3 = (rem >= 1) ? chunk_list[chunk_idx+2] : {128{1'b0}};

          // Assemble flit_out
          flit_out_reg <= {
            slot3,
            slot2,
            slot1,
            slot0,
            16'b0
          };

          // Update state
          rem <= rem - 1;
          chunk_idx <= chunk_idx + 1;
        end
      end else if (llcrd) begin
        // --- LLCRD flit ---
        flit_valid_reg <= 1'b1;
        flit_is_control_reg <= 1'b1;
        flit_is_alldata_reg <= 1'b0;

        // Build LLCRD slot0
        slot0 = make_llcrd_slot0(crd_rsp_field, crd_req_field, crd_data_field);

        // Slots 1-3 are zero
        flit_out_reg <= {
          {128{1'b0}}, // slot3
          {128{1'b0}}, // slot2
          {128{1'b0}}, // slot1
          slot0,
          16'b0
        };

        // Clear latched force_llcrd
        lat <= 1'b0;
      end else if (new_msg) begin
        // --- First flit of a new message ---
        flit_valid_reg <= 1'b1;
        flit_is_control_reg <= 1'b0;
        flit_is_alldata_reg <= 1'b0;

        // Determine number of data chunks to place in this flit (max 3)
        logic [2:0] first_chunks = (total_chunks > 3) ? 3 : total_chunks;

        // Determine slot format selectors for Slots 1-3
        logic [2:0] slot1_fmt, slot2_fmt, slot3_fmt;
        if (first_chunks >= 3) begin
          slot1_fmt = 3'b000;
          slot2_fmt = 3'b000;
          slot3_fmt = 3'b000;
        end else if (first_chunks == 2) begin
          slot1_fmt = 3'b000;
          slot2_fmt = 3'b000;
          slot3_fmt = get_slot_fmt(DIRECTION, 0);
        end else if (first_chunks == 1) begin
          slot1_fmt = 3'b000;
          slot2_fmt = get_slot_fmt(DIRECTION, 0);
          slot3_fmt = get_slot_fmt(DIRECTION, 0);
        end else begin
          slot1_fmt = get_slot_fmt(DIRECTION, 0);
          slot2_fmt = get_slot_fmt(DIRECTION, 0);
          slot3_fmt = get_slot_fmt(DIRECTION, 0);
        end

        // Determine Slot0 format based on message type
        logic [2:0] slot0_fmt;
        if (DIRECTION == 0) begin
          if (cur_msg_type == MT_Req) begin
            slot0_fmt = 3'b101; // H5
          end else if (cur_msg_type == MT_RwD) begin
            slot0_fmt = 3'b100; // H4
          end else begin
            slot0_fmt = 3'b000;
          end
        end else begin
          slot0_fmt = 3'b011; // H3
        end

        // Build header
        logic [31:0] header;
        header = make_header(
          1'b0, // Type = Protocol
          1'b0, // RV
          1'b0, // Ak
          (cur_msg_type == MT_RwD && cur_msg_opcode == MemWrPtl) ? 1'b1 : 1'b0, // BE
          (cur_msg_type == MT_RwD || cur_msg_type == MT_DRS) ? 1'b1 : 1'b0, // Sz
          slot0_fmt,
          slot1_fmt,
          slot2_fmt,
          slot3_fmt,
          crd_rsp_field,
          crd_req_field,
          crd_data_field
        );

        // Build message bits based on message type
        logic [127:0] slot0;
        if (DIRECTION == 0) begin
          if (cur_msg_type == MT_Req) begin
            slot0 = {make_msg_bits_req(cur_msg_opcode, cur_msg_addr, cur_msg_tag), header};
          end else if (cur_msg_type == MT_RwD) begin
            slot0 = {make_msg_bits_rwd(cur_msg_opcode, cur_msg_addr, cur_msg_poison, cur_msg_tag), header};
          end else begin
            slot0 = {128{1'b0}};
          end
        end else begin
          if (cur_msg_type == MT_DRS) begin
            // DRS occupies first position of H3
            slot0 = {make_msg_bits_drs(MemData, cur_msg_tag, cur_msg_poison), header};
          end else if (cur_msg_type == MT_NDR) begin
            // NDR occupies second position of H3; we need to place it after DRS (which is empty)
            // For simplicity, we treat the whole slot0 as containing the NDR message in the second position.
            // Since we are using H3 format, the second position is bits [101:72] of the slot0.
            // We'll construct a 128-bit slot0 with the NDR message placed appropriately.
            // For this implementation, we assume the slot0 format H3 and the message bits are placed in the second position.
            // We'll create a 128-bit slot0 where the lower 40 bits (first message) are zero (Valid=0),
            // and the next 30 bits (second message) contain the NDR header.
            // The exact layout is complex; for simplicity, we set the whole slot0 to zero except for the header.
            slot0 = {128{1'b0}};
          end else begin
            slot0 = {128{1'b0}};
          end
        end

        // Build data slots for first flit
        slot1 = (first_chunks >= 1) ? chunk_list[chunk_idx] : {128{1'b0}};
        slot2 = (first_chunks >= 2) ? chunk_list[chunk_idx+1] : {128{1'b0}};
        slot3 = (first_chunks >= 3) ? chunk_list[chunk_idx+2] : {128{1'b0}};

        // Assemble flit_out
        flit_out_reg <= {
          slot3,
          slot2,
          slot1,
          slot0,
          16'b0
        };

        // Update state
        rem <= total_chunks - first_chunks;
        chunk_idx <= chunk_idx + first_chunks;
      end else begin
        // No flit to send
        flit_valid_reg <= 1'b0;
      end
    end
  end

  // Latch force_llcrd
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      lat <= 1'b0;
    end else begin
      lat <= force_llcrd;
    end
  end

endmodule
