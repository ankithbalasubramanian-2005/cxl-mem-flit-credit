module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  // Internal registers for sender and pending counters
  reg [6:0] snd[0:1];
  reg [7:0] pend[0:1];

  // Helper function to decode credit count from 4-bit field
  function automatic [7:0] decode_credits(input logic [3:0] field);
    if (field[3] == 0) begin
      return 8'b0; // CXL.cache, discard
    end else begin
      case (field[2:0])
        3'b000: return 8'd0;
        3'b001: return 8'd1;
        3'b010: return 8'd2;
        3'b011: return 8'd4;
        3'b100: return 8'd8;
        3'b101: return 8'd16;
        3'b110: return 8'd32;
        3'b111: return 8'd64;
        default: return 8'd0;
      endcase
    end
  endfunction

  // Helper function to encode credits into 4-bit field (greedy)
  function automatic [3:0] encode_credits(input [7:0] count);
    if (count >= 64) return 4'b1111; // 64 credits (max)
    else if (count >= 32) return 4'b1110;
    else if (count >= 16) return 4'b1101;
    else if (count >= 8)  return 4'b1100;
    else if (count >= 4)  return 4'b1011;
    else if (count >= 2)  return 4'b1010;
    else if (count >= 1)  return 4'b1001;
    else                  return 4'b1000; // 0 credits (still CXL.mem)
  endfunction

  // Determine which channel each field corresponds to based on DIRECTION
  // For DIRECTION 0 (host side):
  //   sender ch0 = M2S Req  <- rx_reqcrd
  //   sender ch1 = M2S RwD  <- rx_datacrd
  //   pending ch0 = S2M NDR <- crd_rsp_field
  //   pending ch1 = S2M DRS <- crd_data_field
  // For DIRECTION 1 (device side):
  //   sender ch0 = S2M NDR  <- rx_rspcrd
  //   sender ch1 = S2M DRS  <- rx_datacrd
  //   pending ch0 = M2S Req  <- crd_req_field
  //   pending ch1 = M2S RwD  <- crd_data_field

  // Internal wires for channel mapping
  wire [3:0] rx_field_for_snd0, rx_field_for_snd1;
  wire [3:0] rx_field_for_pend0, rx_field_for_pend1;
  wire [3:0] tx_field_for_pend0, tx_field_for_pend1;

  if (DIRECTION == 0) begin
    assign rx_field_for_snd0 = rx_reqcrd;
    assign rx_field_for_snd1 = rx_datacrd;
    assign rx_field_for_pend0 = rx_rspcrd;
    assign rx_field_for_pend1 = rx_datacrd;
    assign tx_field_for_pend0 = crd_rsp_field;
    assign tx_field_for_pend1 = crd_data_field;
    assign crd_req_field = 4'b0000; // reserved
    assign crd_data_field = encode_credits(pend[1]);
    assign crd_rsp_field = encode_credits(pend[0]);
  end else begin
    assign rx_field_for_snd0 = rx_rspcrd;
    assign rx_field_for_snd1 = rx_datacrd;
    assign rx_field_for_pend0 = rx_reqcrd;
    assign rx_field_for_pend1 = rx_datacrd;
    assign tx_field_for_pend0 = crd_req_field;
    assign tx_field_for_pend1 = crd_data_field;
    assign crd_req_field = encode_credits(pend[0]);
    assign crd_data_field = encode_credits(pend[1]);
    assign crd_rsp_field = 4'b0000; // reserved
  end

  // Main clocked process
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] <= 0;
      snd[1] <= 0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      // Update sender counters based on tx_send pulses
      if (tx_send[0]) begin
        if (snd[0] > 0) begin
          snd[0] <= snd[0] - 1;
        end else begin
          snd[0] <= 0;
        end
      end

      if (tx_send[1]) begin
        if (snd[1] > 0) begin
          snd[1] <= snd[1] - 1;
        end else begin
          snd[1] <= 0;
        end
      end

      // Update sender counters based on received credit fields
      if (rx_crd_valid) begin
        // Channel 0
        if (rx_field_for_snd0[3]) begin
          snd[0] <= snd[0] + decode_credits(rx_field_for_snd0);
          if (snd[0] > CREDIT_MAX) snd[0] <= CREDIT_MAX;
        end
        // Channel 1
        if (rx_field_for_snd1[3]) begin
          snd[1] <= snd[1] + decode_credits(rx_field_for_snd1);
          if (snd[1] > CREDIT_MAX) snd[1] <= CREDIT_MAX;
        end
      end

      // Update pending counters based on buf_free pulses
      if (buf_free[0]) begin
        pend[0] <= pend[0] + 1;
        if (pend[0] > PEND_MAX) pend[0] <= PEND_MAX;
      end
      if (buf_free[1]) begin
        pend[1] <= pend[1] + 1;
        if (pend[1] > PEND_MAX) pend[1] <= PEND_MAX;
      end

      // Update pending counters based on crd_taken (credits returned)
      if (crd_taken) begin
        // Channel 0
        if (tx_field_for_pend0 != 4'b0000) begin
          pend[0] <= pend[0] - decode_credits(tx_field_for_pend0);
          if (pend[0] < 0) pend[0] <= 0;
        end
        // Channel 1
        if (tx_field_for_pend1 != 4'b0000) begin
          pend[1] <= pend[1] - decode_credits(tx_field_for_pend1);
          if (pend[1] < 0) pend[1] <= 0;
        end
      end
    end
  end

  // Output assignments
  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];
  assign can_send = {snd[1], snd[0]}; // bit0 = ch0, bit1 = ch1
  assign crd_pending = (pend[0] > 0) || (pend[1] > 0);
  assign pend_0 = pend[0];
  assign pend_1 = pend[1];

endmodule
