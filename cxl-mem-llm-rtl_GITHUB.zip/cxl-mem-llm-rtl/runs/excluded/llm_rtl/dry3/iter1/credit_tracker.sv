module credit_tracker #(
  parameter int DIRECTION  = 0,     // 0 = host (M2S Tx), 1 = device (S2M Tx)
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [0:1];
  logic [7:0] pend [0:1];

  // Table 48: code -> credits
  function automatic logic [6:0] crd_val(input logic [2:0] c);
    crd_val = (c == 3'd0) ? 7'd0 : (7'd1 << (c - 3'd1));
  endfunction

  // greedy largest-first code for a pending count (simplification #12)
  function automatic logic [2:0] greedy(input logic [7:0] p);
    if      (p >= 8'd64) greedy = 3'd7;
    else if (p >= 8'd32) greedy = 3'd6;
    else if (p >= 8'd16) greedy = 3'd5;
    else if (p >= 8'd8)  greedy = 3'd4;
    else if (p >= 8'd4)  greedy = 3'd3;
    else if (p >= 8'd2)  greedy = 3'd2;
    else if (p >= 8'd1)  greedy = 3'd1;
    else                 greedy = 3'd0;
  endfunction

  // Table 49 mapping (v2 §8.12)
  logic [3:0] rx_f [0:1];
  logic [2:0] code [0:1];
  always_comb begin
    if (DIRECTION == 0) begin rx_f[0] = rx_reqcrd; rx_f[1] = rx_datacrd; end
    else                begin rx_f[0] = rx_rspcrd; rx_f[1] = rx_datacrd; end
    code[0] = greedy(pend[0]);
    code[1] = greedy(pend[1]);
    if (DIRECTION == 0) begin
      crd_req_field  = 4'b0000;               // reserved on M2S flits
      crd_rsp_field  = {1'b1, code[0]};       // S2M NDR credits
      crd_data_field = {1'b1, code[1]};       // S2M DRS credits
    end else begin
      crd_req_field  = {1'b1, code[0]};       // M2S Req credits
      crd_data_field = {1'b1, code[1]};       // M2S RwD credits
      crd_rsp_field  = 4'b0000;               // reserved on S2M flits
    end
    tx_credits_0 = snd[0];
    tx_credits_1 = snd[1];
    can_send     = {snd[1] != 0, snd[0] != 0};
    pend_0       = pend[0];
    pend_1       = pend[1];
    crd_pending  = (pend[0] != 0) || (pend[1] != 0);
  end

  // next-state math, wide enough to saturate without wrapping
  logic [7:0] sn [0:1];
  logic [8:0] pn [0:1];
  always_comb
    for (int i = 0; i < 2; i++) begin
      sn[i] = {1'b0, snd[i]}
            - ((tx_send[i] && snd[i] != 0) ? 8'd1 : 8'd0)
            + ((rx_crd_valid && rx_f[i][3]) ? {1'b0, crd_val(rx_f[i][2:0])} : 8'd0);
      pn[i] = {1'b0, pend[i]}
            - (crd_taken ? {2'b0, crd_val(code[i])} : 9'd0)
            + {8'b0, buf_free[i]};
    end

  always_ff @(posedge clk)
    for (int i = 0; i < 2; i++)
      if (!rst_n) begin
        snd[i]  <= '0;
        pend[i] <= RX_DEPTH[7:0];
      end else begin
        snd[i]  <= (sn[i] > CREDIT_MAX) ? CREDIT_MAX[6:0] : sn[i][6:0];
        pend[i] <= (pn[i] > PEND_MAX)   ? PEND_MAX[7:0]   : pn[i][7:0];
      end

endmodule
