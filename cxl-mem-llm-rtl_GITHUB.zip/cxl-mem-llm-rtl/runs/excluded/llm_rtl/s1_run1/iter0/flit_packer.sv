module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_MEMRD     = 4'b0001;
  localparam logic [3:0] OP_M2S_MEMRDDATA = 4'b0010;
  localparam logic [3:0] OP_M2S_MEMWR     = 4'b0001;
  localparam logic [3:0] OP_M2S_MEMWRPTL  = 4'b0010;
  localparam logic [2:0] OP_S2M_CMP       = 3'b000;
  localparam logic [2:0] OP_S2M_MEMDATA   = 3'b000;

  logic [3:0] rem;
  logic       lat;

  logic slot_free;
  logic llcrd_eff;
  logic msg_ready_int;

  logic [527:0] flit_next;
  logic         flit_valid_next;
  logic         flit_is_control_next;
  logic         flit_is_alldata_next;
  logic [3:0]   rem_next;
  logic         lat_next;
  logic         crd_taken_next;

  logic [127:0] header_slot0;
  logic [127:0] slot1, slot2, slot3;
  logic [2:0]   sel0, sel1, sel2, sel3;
  logic [15:0]  crc16;

  logic [127:0] chunks [0:MAX_CHUNKS-1];
  logic [3:0]   n_chunks;
  logic         sz_bit, be_bit;
  logic [2:0]   slot0_fmt;
  logic [127:0] slot0_msg;

  logic [127:0] llcrd_slot0;

  assign slot_free    = !flit_valid || flit_ready;
  assign llcrd_eff    = lat || force_llcrd;
  assign msg_ready    = rst_n && slot_free && (rem == 0) && !llcrd_eff;
  assign crd_taken    = crd_taken_next;

  always_comb begin
    integer i;
    for (i = 0; i < MAX_CHUNKS; i++) begin
      chunks[i] = msg_data[128*i +: 128];
    end
  end

  always_comb begin
    n_chunks = 0;
    sz_bit   = 1'b0;
    be_bit   = 1'b0;
    slot0_fmt = SLOT_H5;
    slot0_msg = '0;

    if (DIRECTION == 0) begin
      if (msg_kind == 1'b0) begin
        slot0_fmt = SLOT_H5;
        slot0_msg[32] = 1'b1;
        slot0_msg[36:33] = msg_opcode;
        slot0_msg[39:37] = 3'b000;
        slot0_msg[41:40] = 2'b11;
        slot0_msg[43:42] = 2'b00;
        slot0_msg[59:44] = msg_tag;
        slot0_msg[106:60] = msg_addr[51:5];
        slot0_msg[108:107] = 2'b00;
        slot0_msg[112:109] = 4'b0000;
        slot0_msg[118:113] = 6'b000000;
      end else begin
        slot0_fmt = SLOT_H4;
        slot0_msg[32] = 1'b1;
        slot0_msg[36:33] = msg_opcode;
        slot0_msg[39:37] = 3'b000;
        slot0_msg[41:40] = 2'b11;
        slot0_msg[43:42] = 2'b00;
        slot0_msg[59:44] = msg_tag;
        slot0_msg[105:60] = msg_addr[51:6];
        slot0_msg[106] = msg_poison;
        slot0_msg[108:107] = 2'b00;
        slot0_msg[112:109] = 4'b0000;
        slot0_msg[118:113] = 6'b000000;
        sz_bit = 1'b1;
        if (msg_opcode == OP_M2S_MEMWRPTL) begin
          be_bit = 1'b1;
        end
      end
    end else begin
      if (msg_kind == 1'b0) begin
        slot0_fmt = SLOT_H3;
        slot0_msg[72] = 1'b1;
        slot0_msg[75:73] = msg_opcode[2:0];
        slot0_msg[77:76] = 2'b11;
        slot0_msg[79:78] = 2'b00;
        slot0_msg[95:80] = msg_tag;
        slot0_msg[99:96] = 4'b0000;
        slot0_msg[101:100] = 2'b00;
      end else begin
        slot0_fmt = SLOT_H3;
        slot0_msg[32] = 1'b1;
        slot0_msg[35:33] = msg_opcode[2:0];
        slot0_msg[37:36] = 2'b11;
        slot0_msg[39:38] = 2'b00;
        slot0_msg[55:40] = msg_tag;
        slot0_msg[56] = msg_poison;
        slot0_msg[60:57] = 4'b0000;
        slot0_msg[62:61] = 2'b00;
        slot0_msg[71:63] = 9'b0;
        sz_bit = 1'b1;
      end
    end

    if (chunks_ovr_en) begin
      n_chunks = chunks_ovr;
    end else begin
      if (DIRECTION == 0) begin
        if (msg_kind == 1'b0) begin
          n_chunks = 0;
        end else begin
          if (msg_opcode == OP_M2S_MEMWRPTL) begin
            n_chunks = 5;
          end else begin
            n_chunks = 4;
          end
        end
      end else begin
        if (msg_kind == 1'b0) begin
          n_chunks = 0;
        end else begin
          n_chunks = 4;
        end
      end
    end
  end

  always_comb begin
    header_slot0 = '0;
    header_slot0[0] = 1'b0;
    header_slot0[1] = 1'b0;
    header_slot0[2] = 1'b0;
    header_slot0[3] = be_bit;
    header_slot0[4] = sz_bit;
    header_slot0[7:5] = slot0_fmt;
    if (DIRECTION == 0) begin
      header_slot0[10:8] = SLOT_G4;
      header_slot0[13:11] = SLOT_G4;
      header_slot0[16:14] = SLOT_G4;
    end else begin
      header_slot0[10:8] = SLOT_G5;
      header_slot0[13:11] = SLOT_G5;
      header_slot0[16:14] = SLOT_G5;
    end
    header_slot0[19:17] = 3'b000;
    header_slot0[23:20] = crd_rsp_field;
    header_slot0[27:24] = crd_req_field;
    header_slot0[31:28] = crd_data_field;
    header_slot0[127:32] = slot0_msg;

    slot1 = '0;
    slot2 = '0;
    slot3 = '0;
    sel1 = SLOT_G0;
    sel2 = SLOT_G0;
    sel3 = SLOT_G0;

    if (DIRECTION == 0) begin
      sel1 = SLOT_G4;
      sel2 = SLOT_G4;
      sel3 = SLOT_G4;
    end else begin
      sel1 = SLOT_G5;
      sel2 = SLOT_G5;
      sel3 = SLOT_G5;
    end

    crc16 = 16'h0000;

    flit_next = '0;
    flit_valid_next = 1'b0;
    flit_is_control_next = 1'b0;
    flit_is_alldata_next = 1'b0;
    rem_next = rem;
    lat_next = lat;
    crd_taken_next = 1'b0;

    if (slot_free) begin
      if (rem > 0) begin
        if (rem > 4'd3) begin
          flit_next[127:0]   = chunks[n_chunks - rem];
          flit_next[255:128] = chunks[n_chunks - rem + 1];
          flit_next[383:256] = chunks[n_chunks - rem + 2];
          flit_next[511:384] = chunks[n_chunks - rem + 3];
          flit_next[527:512] = crc16;
          flit_valid_next = 1'b1;
          flit_is_alldata_next = 1'b1;
          rem_next = rem - 4;
          lat_next = llcrd_eff;
        end else begin
          header_slot0[7:5] = slot0_fmt;
          header_slot0[10:8] = SLOT_G0;
          header_slot0[13:11] = SLOT_G0;
          header_slot0[16:14] = SLOT_G0;
          flit_next[127:0] = header_slot0;
          if (rem >= 1) flit_next[255:128] = chunks[n_chunks - rem];
          if (rem >= 2) flit_next[383:256] = chunks[n_chunks - rem + 1];
          if (rem >= 3) flit_next[511:384] = chunks[n_chunks - rem + 2];
          flit_next[527:512] = crc16;
          flit_valid_next = 1'b1;
          rem_next = 0;
          lat_next = llcrd_eff;
          crd_taken_next = 1'b1;
        end
      end else if (llcrd_eff) begin
        flit_next[127:0] = llcrd_slot0;
        flit_next[527:128] = '0;
        flit_next[527:512] = crc16;
        flit_valid_next = 1'b1;
        flit_is_control_next = 1'b1;
        lat_next = 1'b0;
        crd_taken_next = 1'b1;
      end else if (msg_valid) begin
        flit_next[127:0] = header_slot0;
        if (n_chunks >= 1) flit_next[255:128] = chunks[0];
        if (n_chunks >= 2) flit_next[383:256] = chunks[1];
        if (n_chunks >= 3) flit_next[511:384] = chunks[2];
        flit_next[527:512] = crc16;
        flit_valid_next = 1'b1;
        if (n_chunks > 3) rem_next = n_chunks - 3;
        else rem_next = 0;
        lat_next = llcrd_eff;
        crd_taken_next = 1'b1;
      end else begin
        flit_valid_next = 1'b0;
        lat_next = llcrd_eff;
      end
    end else begin
      lat_next = llcrd_eff;
    end

    llcrd_slot0 = '0;
    llcrd_slot0[0] = 1'b1;
    llcrd_slot0[1] = 1'b0;
    llcrd_slot0[2] = 1'b0;
    llcrd_slot0[4:3] = 2'b00;
    llcrd_slot0[7:5] = 3'b000;
    llcrd_slot0[15:8] = 8'h00;
    llcrd_slot0[19:16] = 4'h0;
    llcrd_slot0[23:20] = crd_rsp_field;
    llcrd_slot0[27:24] = crd_req_field;
    llcrd_slot0[31:28] = crd_data_field;
    llcrd_slot0[35:32] = 4'b0000;
    llcrd_slot0[39:36] = 4'b0000;
    llcrd_slot0[63:40] = 24'h000000;
    llcrd_slot0[127:64] = 64'h0;
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid     <= 1'b0;
      flit_out       <= '0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem            <= 4'd0;
      lat            <= 1'b0;
    end else begin
      flit_valid     <= flit_valid_next;
      flit_out       <= flit_next;
      flit_is_control <= flit_is_control_next;
      flit_is_alldata <= flit_is_alldata_next;
      rem            <= rem_next;
      lat            <= lat_next;
    end
  end

endmodule
