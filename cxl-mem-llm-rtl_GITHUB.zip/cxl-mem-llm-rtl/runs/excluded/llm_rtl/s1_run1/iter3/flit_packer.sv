module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_REQ_MemRd      = 4'b0001;
  localparam logic [3:0] OP_M2S_REQ_MemRdData  = 4'b0010;
  localparam logic [3:0] OP_M2S_RWD_MemWr      = 4'b0001;
  localparam logic [3:0] OP_M2S_RWD_MemWrPtl   = 4'b0010;
  localparam logic [2:0] OP_S2M_NDR_Cmp        = 3'b000;
  localparam logic [2:0] OP_S2M_DRS_MemData    = 3'b000;

  logic [3:0] rem;
  logic       lat;

  logic slot_free;
  logic llcrd_eff;
  logic msg_ready_int;

  logic [527:0] flit_next;
  logic         flit_valid_next;
  logic         flit_is_control_next;
  logic         flit_is_alldata_next;
  logic [3:0]   rem_next;
  logic         lat_next;
  logic         crd_taken_next;

  logic [127:0] chunk_list [0:MAX_CHUNKS-1];
  logic [3:0]   num_chunks;
  logic         hdr_sz;
  logic         hdr_be;
  logic [127:0] slot0_msg;
  logic [2:0]   slot0_fmt;
  logic [2:0]   slot1_fmt;
  logic [2:0]   slot2_fmt;
  logic [2:0]   slot3_fmt;
  logic [127:0] slot1_data;
  logic [127:0] slot2_data;
  logic [127:0] slot3_data;

  assign slot_free    = !flit_valid || flit_ready;
  assign llcrd_eff    = lat || force_llcrd;
  assign msg_ready    = rst_n && slot_free && (rem == 0) && !llcrd_eff;
  assign crd_taken    = crd_taken_next;

  function automatic logic [3:0] enc_credit(input logic [7:0] n);
    logic [3:0] e;
    if (n == 0) e = 4'b0000;
    else if (n <= 1) e = 4'b0001;
    else if (n <= 2) e = 4'b0010;
    else if (n <= 4) e = 4'b0011;
    else if (n <= 8) e = 4'b0100;
    else if (n <= 16) e = 4'b0101;
    else if (n <= 32) e = 4'b0110;
    else e = 4'b0111;
    return {1'b1, e[2:0]};
  endfunction

  function automatic logic [127:0] build_header(
    input logic        type_bit,
    input logic        sz,
    input logic        be,
    input logic [2:0]  s0, s1, s2, s3,
    input logic [3:0]  reqcrd, datacrd, rspcrd,
    input logic [127:0] slot0_msg
  );
    logic [127:0] h;
    h = 128'h0;
    h[0] = type_bit;
    h[1] = 1'b0;
    h[2] = 1'b0;
    h[3] = be;
    h[4] = sz;
    h[7:5] = s0;
    h[10:8] = s1;
    h[13:11] = s2;
    h[16:14] = s3;
    h[19:17] = 3'b000;
    h[23:20] = rspcrd;
    h[27:24] = reqcrd;
    h[31:28] = datacrd;
    h[127:32] = slot0_msg;
    return h;
  endfunction

  function automatic logic [527:0] build_llcrd(
    input logic [3:0] reqcrd, datacrd, rspcrd
  );
    logic [527:0] f;
    f = 528'h0;
    f[0] = 1'b1;
    f[1] = 1'b0;
    f[2] = 1'b0;
    f[4:3] = 2'b00;
    f[7:5] = 3'b000;
    f[15:8] = 8'h00;
    f[19:16] = 4'h0;
    f[23:20] = rspcrd;
    f[27:24] = reqcrd;
    f[31:28] = datacrd;
    f[35:32] = 4'b0000;
    f[39:36] = 4'b0000;
    f[63:40] = 24'h0;
    f[127:64] = 64'h0;
    f[527:512] = 16'h0000;
    return f;
  endfunction

  always_comb begin
    for (int i = 0; i < MAX_CHUNKS; i++) chunk_list[i] = 128'h0;
    num_chunks = 0;
    hdr_sz = 1'b0;
    hdr_be = 1'b0;
    slot0_msg = 128'h0;
    slot0_fmt = SLOT_H0;
    slot1_fmt = SLOT_G0;
    slot2_fmt = SLOT_G0;
    slot3_fmt = SLOT_G0;
    slot1_data = 128'h0;
    slot2_data = 128'h0;
    slot3_data = 128'h0;

    if (DIRECTION == 0) begin
      if (msg_kind == 1'b0) begin
        slot0_fmt = SLOT_H5;
        slot0_msg[32] = 1'b1;
        slot0_msg[36:33] = msg_opcode;
        slot0_msg[39:37] = 3'b000;
        slot0_msg[41:40] = 2'b11;
        slot0_msg[43:42] = 2'b00;
        slot0_msg[59:44] = msg_tag;
        slot0_msg[106:60] = msg_addr[51:5];
        slot0_msg[108:107] = 2'b00;
        slot0_msg[112:109] = 4'b0000;
      end else begin
        slot0_fmt = SLOT_H4;
        slot0_msg[32] = 1'b1;
        slot0_msg[36:33] = msg_opcode;
        slot0_msg[39:37] = 3'b000;
        slot0_msg[41:40] = 2'b11;
        slot0_msg[43:42] = 2'b00;
        slot0_msg[59:44] = msg_tag;
        slot0_msg[105:60] = msg_addr[51:6];
        slot0_msg[106] = msg_poison;
        slot0_msg[108:107] = 2'b00;
        slot0_msg[112:109] = 4'b0000;
        hdr_sz = 1'b1;
        if (msg_opcode == OP_M2S_RWD_MemWrPtl) begin
          hdr_be = 1'b1;
          chunk_list[0] = msg_data[127:0];
          chunk_list[1] = msg_data[255:128];
          chunk_list[2] = msg_data[383:256];
          chunk_list[3] = msg_data[511:384];
          chunk_list[4] = {64'h0, msg_byte_en};
          num_chunks = 5;
        end else begin
          chunk_list[0] = msg_data[127:0];
          chunk_list[1] = msg_data[255:128];
          chunk_list[2] = msg_data[383:256];
          chunk_list[3] = msg_data[511:384];
          num_chunks = 4;
        end
      end
    end else begin
      if (msg_kind == 1'b0) begin
        slot0_fmt = SLOT_H3;
        slot0_msg[72] = 1'b1;
        slot0_msg[75:73] = msg_opcode[2:0];
        slot0_msg[77:76] = 2'b11;
        slot0_msg[79:78] = 2'b00;
        slot0_msg[95:80] = msg_tag;
        slot0_msg[99:96] = 4'b0000;
        slot0_msg[101:100] = 2'b00;
      end else begin
        slot0_fmt = SLOT_H3;
        slot0_msg[32] = 1'b1;
        slot0_msg[35:33] = msg_opcode[2:0];
        slot0_msg[37:36] = 2'b11;
        slot0_msg[39:38] = 2'b00;
        slot0_msg[55:40] = msg_tag;
        slot0_msg[56] = msg_poison;
        slot0_msg[60:57] = 4'b0000;
        slot0_msg[62:61] = 2'b00;
        hdr_sz = 1'b1;
        chunk_list[0] = msg_data[127:0];
        chunk_list[1] = msg_data[255:128];
        chunk_list[2] = msg_data[383:256];
        chunk_list[3] = msg_data[511:384];
        num_chunks = 4;
      end
    end

    if (chunks_ovr_en) begin
      num_chunks = chunks_ovr;
    end
  end

  always_comb begin
    flit_next = 528'h0;
    flit_valid_next = 1'b0;
    flit_is_control_next = 1'b0;
    flit_is_alldata_next = 1'b0;
    rem_next = rem;
    lat_next = lat;
    crd_taken_next = 1'b0;

    if (slot_free) begin
      if (rem > 0) begin
        if (rem > 4'd3) begin
          flit_next[127:0] = chunk_list[0];
          flit_next[255:128] = chunk_list[1];
          flit_next[383:256] = chunk_list[2];
          flit_next[511:384] = chunk_list[3];
          flit_next[527:512] = 16'h0000;
          flit_valid_next = 1'b1;
          flit_is_alldata_next = 1'b1;
          rem_next = rem - 4'd4;
          lat_next = llcrd_eff;
        end else begin
          logic [127:0] hdr;
          hdr = build_header(1'b0, 1'b0, 1'b0,
                             (DIRECTION==0)?SLOT_H5:SLOT_H3,
                             (rem>=1)?SLOT_G0:((DIRECTION==0)?SLOT_G4:SLOT_G5),
                             (rem>=2)?SLOT_G0:((DIRECTION==0)?SLOT_G4:SLOT_G5),
                             (rem>=3)?SLOT_G0:((DIRECTION==0)?SLOT_G4:SLOT_G5),
                             crd_req_field, crd_data_field, crd_rsp_field,
                             128'h0);
          flit_next[127:0] = hdr;
          if (rem >= 1) flit_next[255:128] = chunk_list[0];
          if (rem >= 2) flit_next[383:256] = chunk_list[1];
          if (rem >= 3) flit_next[511:384] = chunk_list[2];
          flit_next[527:512] = 16'h0000;
          flit_valid_next = 1'b1;
          rem_next = 4'd0;
          crd_taken_next = 1'b1;
          lat_next = llcrd_eff;
        end
      end else if (llcrd_eff) begin
        flit_next = build_llcrd(crd_req_field, crd_data_field, crd_rsp_field);
        flit_valid_next = 1'b1;
        flit_is_control_next = 1'b1;
        lat_next = 1'b0;
        crd_taken_next = 1'b1;
      end else if (msg_valid) begin
        logic [127:0] hdr;
        hdr = build_header(1'b0, hdr_sz, hdr_be,
                           slot0_fmt,
                           (num_chunks>=1)?SLOT_G0:((DIRECTION==0)?SLOT_G4:SLOT_G5),
                           (num_chunks>=2)?SLOT_G0:((DIRECTION==0)?SLOT_G4:SLOT_G5),
                           (num_chunks>=3)?SLOT_G0:((DIRECTION==0)?SLOT_G4:SLOT_G5),
                           crd_req_field, crd_data_field, crd_rsp_field,
                           slot0_msg);
        flit_next[127:0] = hdr;
        if (num_chunks >= 1) flit_next[255:128] = chunk_list[0];
        if (num_chunks >= 2) flit_next[383:256] = chunk_list[1];
        if (num_chunks >= 3) flit_next[511:384] = chunk_list[2];
        flit_next[527:512] = 16'h0000;
        flit_valid_next = 1'b1;
        if (num_chunks > 3) rem_next = num_chunks - 3;
        else rem_next = 4'd0;
        crd_taken_next = 1'b1;
        lat_next = llcrd_eff;
      end else begin
        flit_valid_next = 1'b0;
        lat_next = llcrd_eff;
      end
    end else begin
      lat_next = llcrd_eff;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid <= 1'b0;
      flit_out <= 528'h0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem <= 4'd0;
      lat <= 1'b0;
    end else begin
      flit_valid <= flit_valid_next;
      flit_out <= flit_next;
      flit_is_control <= flit_is_control_next;
      flit_is_alldata <= flit_is_alldata_next;
      rem <= rem_next;
      lat <= lat_next;
    end
  end

endmodule
