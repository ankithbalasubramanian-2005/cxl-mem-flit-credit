module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [1:0];
  logic [7:0] pend [1:0];

  function automatic logic [6:0] dec_credit(input logic [3:0] f);
    logic [6:0] v;
    if (f[3] != 1'b1) v = 7'd0;
    else begin
      case (f[2:0])
        3'b000: v = 7'd0;
        3'b001: v = 7'd1;
        3'b010: v = 7'd2;
        3'b011: v = 7'd4;
        3'b100: v = 7'd8;
        3'b101: v = 7'd16;
        3'b110: v = 7'd32;
        3'b111: v = 7'd64;
      endcase
    end
    return v;
  endfunction

  function automatic logic [3:0] enc_credit(input logic [7:0] n);
    logic [3:0] e;
    if (n == 0) e = 4'b0000;
    else if (n <= 1) e = 4'b0001;
    else if (n <= 2) e = 4'b0010;
    else if (n <= 4) e = 4'b0011;
    else if (n <= 8) e = 4'b0100;
    else if (n <= 16) e = 4'b0101;
    else if (n <= 32) e = 4'b0110;
    else e = 4'b0111;
    return {1'b1, e[2:0]};
  endfunction

  function automatic logic [3:0] field_val(input logic [3:0] f);
    logic [3:0] v;
    if (f[3] != 1'b1) v = 4'd0;
    else begin
      case (f[2:0])
        3'b000: v = 4'd0;
        3'b001: v = 4'd1;
        3'b010: v = 4'd2;
        3'b011: v = 4'd4;
        3'b100: v = 4'd8;
        3'b101: v = 4'd16;
        3'b110: v = 4'd32;
        3'b111: v = 4'd64;
      endcase
    end
    return v;
  endfunction

  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];
  assign can_send = {snd[1] != 0, snd[0] != 0};
  assign pend_0 = pend[0];
  assign pend_1 = pend[1];
  assign crd_pending = (pend[0] != 0) || (pend[1] != 0);

  always_comb begin
    if (DIRECTION == 0) begin
      crd_req_field = 4'b0000;
      crd_data_field = enc_credit(pend[1]);
      crd_rsp_field = enc_credit(pend[0]);
    end else begin
      crd_req_field = enc_credit(pend[0]);
      crd_data_field = enc_credit(pend[1]);
      crd_rsp_field = 4'b0000;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] <= 7'd0;
      snd[1] <= 7'd0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      logic [6:0] add0, add1;
      logic [7:0] take0, take1;
      add0 = 7'd0;
      add1 = 7'd0;
      if (rx_crd_valid) begin
        if (DIRECTION == 0) begin
          add0 = dec_credit(rx_reqcrd);
          add1 = dec_credit(rx_datacrd);
        end else begin
          add0 = dec_credit(rx_rspcrd);
          add1 = dec_credit(rx_datacrd);
        end
      end
      snd[0] <= (snd[0] - (tx_send[0] && snd[0] != 0) + add0 > CREDIT_MAX) ? CREDIT_MAX :
                snd[0] - (tx_send[0] && snd[0] != 0) + add0;
      snd[1] <= (snd[1] - (tx_send[1] && snd[1] != 0) + add1 > CREDIT_MAX) ? CREDIT_MAX :
                snd[1] - (tx_send[1] && snd[1] != 0) + add1;

      take0 = 8'd0;
      take1 = 8'd0;
      if (crd_taken) begin
        if (DIRECTION == 0) begin
          take0 = field_val(crd_rsp_field);
          take1 = field_val(crd_data_field);
        end else begin
          take0 = field_val(crd_req_field);
          take1 = field_val(crd_data_field);
        end
      end
      pend[0] <= (pend[0] - take0 + buf_free[0] > PEND_MAX) ? PEND_MAX :
                 pend[0] - take0 + buf_free[0];
      pend[1] <= (pend[1] - take1 + buf_free[1] > PEND_MAX) ? PEND_MAX :
                 pend[1] - take1 + buf_free[1];
    end
  end

endmodule
