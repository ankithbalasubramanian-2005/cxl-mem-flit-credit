module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam int SLOT_BITS = 128;
  localparam int FLIT_BITS = 528;

  logic [3:0] rem;
  logic       lat;

  logic slot_free;
  logic llcrd_eff;
  logic msg_ready_int;

  logic [FLIT_BITS-1:0] nxt_flit;
  logic                 nxt_valid;
  logic                 nxt_is_ctrl;
  logic                 nxt_is_alldata;
  logic                 nxt_crd_taken;
  logic [3:0]           nxt_rem;
  logic                 nxt_lat;

  logic [127:0] slot0, slot1, slot2, slot3;
  logic [15:0]  crc16;

  logic [127:0] hdr_slot0;
  logic [127:0] empty_slot0;
  logic [127:0] empty_slot_generic;

  logic [127:0] chunks [0:MAX_CHUNKS-1];
  logic [3:0]   n_chunks;
  logic         sz_bit, be_bit;

  logic [3:0] slot0_sel, slot1_sel, slot2_sel, slot3_sel;

  logic [31:0] hdr_base;

  assign slot_free   = !flit_valid || flit_ready;
  assign llcrd_eff   = lat || force_llcrd;
  assign msg_ready   = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  always_comb begin
    for (int i = 0; i < MAX_CHUNKS; i++) chunks[i] = msg_data[128*i +: 128];
    if (chunks_ovr_en) begin
      n_chunks = chunks_ovr;
    end else begin
      unique case (DIRECTION)
        0: begin // M2S
          if (msg_kind == 1'b0) n_chunks = 4'd0; // Req
          else begin
            if (msg_opcode == 4'h2) n_chunks = 4'd5; // MemWrPtl
            else                    n_chunks = 4'd4; // MemWr
          end
        end
        1: begin // S2M
          if (msg_kind == 1'b0) n_chunks = 4'd0; // NDR
          else                  n_chunks = 4'd4; // DRS
        end
      endcase
    end
    sz_bit = (DIRECTION == 0) ? (msg_kind == 1'b1) : (msg_kind == 1'b1);
    be_bit = (DIRECTION == 0) && (msg_kind == 1'b1) && (msg_opcode == 4'h2);
  end

  always_comb begin
    hdr_base = 32'h0;
    hdr_base[0]   = 1'b0; // Type = Protocol
    hdr_base[1]   = 1'b0; // RV
    hdr_base[2]   = 1'b0; // Ak
    hdr_base[3]   = be_bit;
    hdr_base[4]   = sz_bit;
    hdr_base[7:5] = slot0_sel;
    hdr_base[10:8]= slot1_sel;
    hdr_base[13:11]= slot2_sel;
    hdr_base[16:14]= slot3_sel;
    hdr_base[19:17]= 3'b0;
    hdr_base[23:20]= crd_rsp_field;
    hdr_base[27:24]= crd_req_field;
    hdr_base[31:28]= crd_data_field;
  end

  always_comb begin
    if (DIRECTION == 0) begin // M2S
      slot0_sel = (msg_kind == 1'b0) ? 3'd5 : 3'd4; // H5 Req / H4 RwD
      empty_slot0 = {96'h0, hdr_base};
      empty_slot_generic = {96'h0, hdr_base};
      slot1_sel = 3'd4; slot2_sel = 3'd4; slot3_sel = 3'd4; // G4
    end else begin // S2M
      slot0_sel = 3'd3; // H3
      empty_slot0 = {96'h0, hdr_base};
      empty_slot_generic = {96'h0, hdr_base};
      slot1_sel = 3'd5; slot2_sel = 3'd5; slot3_sel = 3'd5; // G5
    end
  end

  always_comb begin
    logic [127:0] msg_slot0;
    if (DIRECTION == 0) begin // M2S
      if (msg_kind == 1'b0) begin // Req H5
        msg_slot0 = 128'h0;
        msg_slot0[32]   = 1'b1; // Valid
        msg_slot0[36:33] = msg_opcode;
        msg_slot0[39:37] = 3'b000; // SnpType
        msg_slot0[41:40] = 2'b11;  // MetaField
        msg_slot0[43:42] = 2'b00;  // MetaValue
        msg_slot0[59:44] = msg_tag;
        msg_slot0[106:60] = msg_addr[51:5];
        msg_slot0[108:107] = 2'b00; // TC
        msg_slot0[112:109] = 4'b0000; // LD-ID
        msg_slot0[118:113] = 6'b0;
      end else begin // RwD H4
        msg_slot0 = 128'h0;
        msg_slot0[32]   = 1'b1;
        msg_slot0[36:33] = msg_opcode;
        msg_slot0[39:37] = 3'b000;
        msg_slot0[41:40] = 2'b11;
        msg_slot0[43:42] = 2'b00;
        msg_slot0[59:44] = msg_tag;
        msg_slot0[105:60] = msg_addr[51:6];
        msg_slot0[106]    = msg_poison;
        msg_slot0[108:107] = 2'b00;
        msg_slot0[112:109] = 4'b0000;
        msg_slot0[118:113] = 6'b0;
      end
    end else begin // S2M H3
      msg_slot0 = 128'h0;
      if (msg_kind == 1'b1) begin // DRS first position
        msg_slot0[32]   = 1'b1;
        msg_slot0[35:33] = msg_opcode[2:0];
        msg_slot0[37:36] = 2'b11;
        msg_slot0[39:38] = 2'b00;
        msg_slot0[55:40] = msg_tag;
        msg_slot0[56]    = msg_poison;
        msg_slot0[60:57] = 4'b0000;
        msg_slot0[62:61] = 2'b00;
        msg_slot0[71:63] = 9'b0;
      end else begin // NDR second position
        msg_slot0[72]   = 1'b1;
        msg_slot0[75:73] = msg_opcode[2:0];
        msg_slot0[77:76] = 2'b11;
        msg_slot0[79:78] = 2'b00;
        msg_slot0[95:80] = msg_tag;
        msg_slot0[99:96] = 4'b0000;
        msg_slot0[101:100] = 2'b00;
      end
    end
    hdr_slot0 = {msg_slot0[127:32], hdr_base};
  end

  always_comb begin
    logic [127:0] be_chunk;
    be_chunk = 128'h0;
    be_chunk[63:0]   = msg_byte_en[31:0];
    be_chunk[127:64] = msg_byte_en[63:32];
  end

  always_comb begin
    nxt_flit     = flit_out;
    nxt_valid    = 1'b0;
    nxt_is_ctrl  = 1'b0;
    nxt_is_alldata = 1'b0;
    nxt_crd_taken = 1'b0;
    nxt_rem      = rem;
    nxt_lat      = lat;

    if (slot_free) begin
      if (rem > 0) begin
        if (rem > 4'd3) begin
          slot0 = chunks[n_chunks - rem];
          slot1 = chunks[n_chunks - rem + 1];
          slot2 = chunks[n_chunks - rem + 2];
          slot3 = chunks[n_chunks - rem + 3];
          nxt_rem = rem - 4;
          nxt_is_alldata = 1'b1;
        end else begin
          slot0 = empty_slot0;
          slot1 = (rem >= 1) ? chunks[n_chunks - rem] : empty_slot_generic;
          slot2 = (rem >= 2) ? chunks[n_chunks - rem + 1] : empty_slot_generic;
          slot3 = (rem >= 3) ? chunks[n_chunks - rem + 2] : empty_slot_generic;
          nxt_rem = 0;
          nxt_crd_taken = 1'b1;
        end
        nxt_valid = 1'b1;
        nxt_lat = llcrd_eff;
      end else if (llcrd_eff) begin
        slot0 = 128'h0;
        slot0[0]   = 1'b1; // Type = Control
        slot0[1]   = 1'b0; // RV
        slot0[2]   = 1'b0; // Ak
        slot0[4:3] = 2'b0;
        slot0[7:5] = 3'b000; // CTL_FMT
        slot0[15:8] = 8'h0;
        slot0[19:16] = 4'h0;
        slot0[23:20] = crd_rsp_field;
        slot0[27:24] = crd_req_field;
        slot0[31:28] = crd_data_field;
        slot0[35:32] = 4'h0; // LLCTRL = LLCRD
        slot0[39:36] = 4'h0; // SubType
        slot0[63:40] = 24'h0;
        slot0[127:64] = 64'h0;
        slot1 = 128'h0;
        slot2 = 128'h0;
        slot3 = 128'h0;
        nxt_valid = 1'b1;
        nxt_is_ctrl = 1'b1;
        nxt_crd_taken = 1'b1;
        nxt_lat = 1'b0;
      end else if (msg_valid) begin
        slot0 = hdr_slot0;
        if (n_chunks >= 3) begin
          slot1 = chunks[0];
          slot2 = chunks[1];
          slot3 = chunks[2];
          nxt_rem = n_chunks - 3;
        end else if (n_chunks == 2) begin
          slot1 = chunks[0];
          slot2 = chunks[1];
          slot3 = empty_slot_generic;
          nxt_rem = 0;
        end else if (n_chunks == 1) begin
          slot1 = chunks[0];
          slot2 = empty_slot_generic;
          slot3 = empty_slot_generic;
          nxt_rem = 0;
        end else begin
          slot1 = empty_slot_generic;
          slot2 = empty_slot_generic;
          slot3 = empty_slot_generic;
          nxt_rem = 0;
        end
        nxt_valid = 1'b1;
        nxt_crd_taken = 1'b1;
        nxt_lat = llcrd_eff;
      end else begin
        nxt_valid = 1'b0;
        nxt_lat = llcrd_eff;
      end
      crc16 = 16'h0000;
      nxt_flit = {crc16, slot3, slot2, slot1, slot0};
    end else begin
      nxt_lat = llcrd_eff;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid      <= 1'b0;
      flit_out        <= '0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem             <= 4'd0;
      lat             <= 1'b0;
      crd_taken       <= 1'b0;
    end else begin
      flit_valid      <= nxt_valid;
      flit_out        <= nxt_flit;
      flit_is_control <= nxt_is_ctrl;
      flit_is_alldata <= nxt_is_alldata;
      rem             <= nxt_rem;
      lat             <= nxt_lat;
      crd_taken       <= nxt_crd_taken;
    end
  end

endmodule
