module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [0:1];
  logic [7:0] pend [0:1];

  logic [6:0] nxt_snd [0:1];
  logic [7:0] nxt_pend [0:1];

  logic [6:0] add_snd [0:1];
  logic [7:0] dec_pend [0:1];

  function automatic logic [6:0] dec_crd(input logic [3:0] f);
    if (f[3] == 1'b0) return 7'd0;
    unique case (f[2:0])
      3'd0: return 7'd0;
      3'd1: return 7'd1;
      3'd2: return 7'd2;
      3'd3: return 7'd4;
      3'd4: return 7'd8;
      3'd5: return 7'd16;
      3'd6: return 7'd32;
      3'd7: return 7'd64;
    endcase
  endfunction

  function automatic logic [3:0] enc_crd(input logic [7:0] v);
    logic [2:0] e;
    if (v == 0) e = 3'd0;
    else if (v >= 64) e = 3'd7;
    else if (v >= 32) e = 3'd6;
    else if (v >= 16) e = 3'd5;
    else if (v >= 8)  e = 3'd4;
    else if (v >= 4)  e = 3'd3;
    else if (v >= 2)  e = 3'd2;
    else              e = 3'd1;
    return {1'b1, e};
  endfunction

  always_comb begin
    can_send[0] = (snd[0] != 0);
    can_send[1] = (snd[1] != 0);
    tx_credits_0 = snd[0];
    tx_credits_1 = snd[1];
    pend_0 = pend[0];
    pend_1 = pend[1];
    crd_pending = (pend[0] != 0) || (pend[1] != 0);

    if (DIRECTION == 0) begin
      crd_req_field  = 4'h0;
      crd_data_field = enc_crd(pend[1]);
      crd_rsp_field  = enc_crd(pend[0]);
    end else begin
      crd_req_field  = enc_crd(pend[0]);
      crd_data_field = enc_crd(pend[1]);
      crd_rsp_field  = 4'h0;
    end
  end

  always_comb begin
    for (int i = 0; i < 2; i++) begin
      add_snd[i] = 7'd0;
      dec_pend[i] = 8'd0;
      nxt_snd[i] = snd[i];
      nxt_pend[i] = pend[i];
    end

    if (rx_crd_valid) begin
      if (DIRECTION == 0) begin
        add_snd[0] = dec_crd(rx_reqcrd);
        add_snd[1] = dec_crd(rx_datacrd);
      end else begin
        add_snd[0] = dec_crd(rx_rspcrd);
        add_snd[1] = dec_crd(rx_datacrd);
      end
    end

    for (int i = 0; i < 2; i++) begin
      logic [6:0] tmp;
      tmp = snd[i] + add_snd[i];
      if (tx_send[i] && snd[i] != 0) tmp = tmp - 1;
      if (tmp > CREDIT_MAX) tmp = CREDIT_MAX;
      nxt_snd[i] = tmp;
    end

    if (crd_taken) begin
      if (DIRECTION == 0) begin
        dec_pend[0] = dec_crd(crd_rsp_field);
        dec_pend[1] = dec_crd(crd_data_field);
      end else begin
        dec_pend[0] = dec_crd(crd_req_field);
        dec_pend[1] = dec_crd(crd_data_field);
      end
    end

    for (int i = 0; i < 2; i++) begin
      logic [7:0] tmp;
      tmp = pend[i] + buf_free[i];
      if (tmp >= dec_pend[i]) tmp = tmp - dec_pend[i];
      else tmp = 0;
      if (tmp > PEND_MAX) tmp = PEND_MAX;
      nxt_pend[i] = tmp;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0]  <= 7'd0;
      snd[1]  <= 7'd0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      snd[0]  <= nxt_snd[0];
      snd[1]  <= nxt_snd[1];
      pend[0] <= nxt_pend[0];
      pend[1] <= nxt_pend[1];
    end
  end

endmodule
