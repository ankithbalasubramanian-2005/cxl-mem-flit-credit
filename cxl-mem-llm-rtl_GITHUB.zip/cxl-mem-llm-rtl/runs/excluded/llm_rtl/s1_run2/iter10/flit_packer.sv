module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G3 = 3'b011;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_REQ_MEMRD     = 4'b0001;
  localparam logic [3:0] OP_M2S_REQ_MEMRDDATA = 4'b0010;
  localparam logic [3:0] OP_M2S_RWD_MEMWR     = 4'b0001;
  localparam logic [3:0] OP_M2S_RWD_MEMWRP    = 4'b0010;
  localparam logic [2:0] OP_S2M_NDR_CMP       = 3'b000;
  localparam logic [2:0] OP_S2M_DRS_MEMDATA   = 3'b000;

  logic [3:0] rem;
  logic       lat;
  logic       flit_valid_r;
  logic [527:0] flit_out_r;
  logic       flit_is_control_r;
  logic       flit_is_alldata_r;

  logic [127:0] chunk_buf [0:MAX_CHUNKS-1];
  logic [3:0]   total_chunks;
  logic [127:0] msg_slot0_content_r;
  logic         msg_be_bit_r, msg_sz_bit_r;
  logic [2:0]   msg_sel0_r;

  assign flit_valid      = flit_valid_r;
  assign flit_out        = flit_out_r;
  assign flit_is_control = flit_is_control_r;
  assign flit_is_alldata = flit_is_alldata_r;

  logic slot_free;
  logic llcrd_eff;
  assign slot_free = !flit_valid_r || flit_ready;
  assign llcrd_eff = lat || force_llcrd;
  assign msg_ready = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  logic [127:0] chunks_comb [0:MAX_CHUNKS-1];
  logic [3:0]   n_chunks_comb;
  logic [127:0] msg_slot0_content_comb;
  logic         msg_be_bit_comb, msg_sz_bit_comb;
  logic [2:0]   msg_sel0_comb;

  always_comb begin
    for (int i = 0; i < MAX_CHUNKS; i++) chunks_comb[i] = '0;
    n_chunks_comb = 0;
    msg_slot0_content_comb = '0;
    msg_be_bit_comb = 1'b0;
    msg_sz_bit_comb = 1'b0;
    msg_sel0_comb = SLOT_H5;

    if (chunks_ovr_en) begin
      for (int i = 0; i < MAX_CHUNKS; i++) chunks_comb[i] = msg_data[128*i +: 128];
      n_chunks_comb = chunks_ovr;
      if (DIRECTION == 0) begin
        if (msg_kind == 1) begin // RwD
          msg_sel0_comb = SLOT_H4;
          msg_sz_bit_comb = 1'b1;
          if (msg_opcode == OP_M2S_RWD_MEMWRP) msg_be_bit_comb = 1'b1;
          msg_slot0_content_comb[0]     = 1'b1;
          msg_slot0_content_comb[4:1]   = msg_opcode;
          msg_slot0_content_comb[7:5]   = 3'b000;
          msg_slot0_content_comb[9:8]   = 2'b11;
          msg_slot0_content_comb[11:10] = 2'b00;
          msg_slot0_content_comb[27:12] = msg_tag;
          msg_slot0_content_comb[73:28] = msg_addr[51:6];
          msg_slot0_content_comb[74]    = msg_poison;
          msg_slot0_content_comb[76:75] = 2'b00;
          msg_slot0_content_comb[80:77] = 4'b0000;
          msg_slot0_content_comb[86:81] = 6'b0;
        end else begin // Req
          msg_sel0_comb = SLOT_H5;
          msg_slot0_content_comb[0]     = 1'b1;
          msg_slot0_content_comb[4:1]   = msg_opcode;
          msg_slot0_content_comb[7:5]   = 3'b000;
          msg_slot0_content_comb[9:8]   = 2'b11;
          msg_slot0_content_comb[11:10] = 2'b00;
          msg_slot0_content_comb[27:12] = msg_tag;
          msg_slot0_content_comb[74:28] = msg_addr[51:5];
          msg_slot0_content_comb[76:75] = 2'b00;
          msg_slot0_content_comb[80:77] = 4'b0000;
          msg_slot0_content_comb[86:81] = 6'b0;
        end
      end else begin // S2M
        msg_sel0_comb = SLOT_H3;
        if (msg_kind == 1) begin // DRS
          msg_sz_bit_comb = 1'b1;
          msg_slot0_content_comb[0]       = 1'b1;
          msg_slot0_content_comb[3:1]     = msg_opcode[2:0];
          msg_slot0_content_comb[5:4]     = 2'b11;
          msg_slot0_content_comb[7:6]     = 2'b00;
          msg_slot0_content_comb[23:8]    = msg_tag;
          msg_slot0_content_comb[24]      = msg_poison;
          msg_slot0_content_comb[28:25]   = 4'b0000;
          msg_slot0_content_comb[30:29]   = 2'b00;
          msg_slot0_content_comb[39:31]   = 9'b0;
        end else begin // NDR
          msg_slot0_content_comb[40]      = 1'b1;
          msg_slot0_content_comb[43:41]   = msg_opcode[2:0];
          msg_slot0_content_comb[45:44]   = 2'b11;
          msg_slot0_content_comb[47:46]   = 2'b00;
          msg_slot0_content_comb[63:48]   = msg_tag;
          msg_slot0_content_comb[67:64]   = 4'b0000;
          msg_slot0_content_comb[69:68]   = 2'b00;
        end
      end
    end else begin
      if (DIRECTION == 0) begin // M2S
        if (msg_kind == 0) begin // Req (H5)
          n_chunks_comb = 0;
          msg_sel0_comb = SLOT_H5;
          msg_slot0_content_comb[0]     = 1'b1;
          msg_slot0_content_comb[4:1]   = msg_opcode;
          msg_slot0_content_comb[7:5]   = 3'b000;
          msg_slot0_content_comb[9:8]   = 2'b11;
          msg_slot0_content_comb[11:10] = 2'b00;
          msg_slot0_content_comb[27:12] = msg_tag;
          msg_slot0_content_comb[74:28] = msg_addr[51:5];
          msg_slot0_content_comb[76:75] = 2'b00;
          msg_slot0_content_comb[80:77] = 4'b0000;
          msg_slot0_content_comb[86:81] = 6'b0;
        end else begin // RwD (H4)
          msg_sel0_comb = SLOT_H4;
          msg_sz_bit_comb = 1'b1;
          if (msg_opcode == OP_M2S_RWD_MEMWR) begin
            n_chunks_comb = 4;
            for (int i = 0; i < 4; i++) chunks_comb[i] = msg_data[128*i +: 128];
          end else begin // MemWrPtl
            n_chunks_comb = 5;
            for (int i = 0; i < 4; i++) chunks_comb[i] = msg_data[128*i +: 128];
            chunks_comb[4] = {64'b0, msg_byte_en};
            msg_be_bit_comb = 1'b1;
          end
          msg_slot0_content_comb[0]     = 1'b1;
          msg_slot0_content_comb[4:1]   = msg_opcode;
          msg_slot0_content_comb[7:5]   = 3'b000;
          msg_slot0_content_comb[9:8]   = 2'b11;
          msg_slot0_content_comb[11:10] = 2'b00;
          msg_slot0_content_comb[27:12] = msg_tag;
          msg_slot0_content_comb[73:28] = msg_addr[51:6];
          msg_slot0_content_comb[74]    = msg_poison;
          msg_slot0_content_comb[76:75] = 2'b00;
          msg_slot0_content_comb[80:77] = 4'b0000;
          msg_slot0_content_comb[86:81] = 6'b0;
        end
      end else begin // S2M
        if (msg_kind == 0) begin // NDR (H3 second position)
          n_chunks_comb = 0;
          msg_sel0_comb = SLOT_H3;
          msg_slot0_content_comb[40]      = 1'b1;
          msg_slot0_content_comb[43:41]   = msg_opcode[2:0];
          msg_slot0_content_comb[45:44]   = 2'b11;
          msg_slot0_content_comb[47:46]   = 2'b00;
          msg_slot0_content_comb[63:48]   = msg_tag;
          msg_slot0_content_comb[67:64]   = 4'b0000;
          msg_slot0_content_comb[69:68]   = 2'b00;
        end else begin // DRS (H3 first position)
          n_chunks_comb = 4;
          for (int i = 0; i < 4; i++) chunks_comb[i] = msg_data[128*i +: 128];
          msg_sel0_comb = SLOT_H3;
          msg_sz_bit_comb = 1'b1;
          msg_slot0_content_comb[0]       = 1'b1;
          msg_slot0_content_comb[3:1]     = msg_opcode[2:0];
          msg_slot0_content_comb[5:4]     = 2'b11;
          msg_slot0_content_comb[7:6]     = 2'b00;
          msg_slot0_content_comb[23:8]    = msg_tag;
          msg_slot0_content_comb[24]      = msg_poison;
          msg_slot0_content_comb[28:25]   = 4'b0000;
          msg_slot0_content_comb[30:29]   = 2'b00;
          msg_slot0_content_comb[39:31]   = 9'b0;
        end
      end
    end
  end

  logic [127:0] next_slot0, next_slot1, next_slot2, next_slot3;
  logic [15:0]  next_crc;
  logic         next_flit_valid, next_flit_is_control, next_flit_is_alldata;
  logic [3:0]   next_rem;
  logic         next_lat;
  logic         crd_taken_comb;
  logic [31:0]  hdr_bits;
  logic [527:0] next_flit_out;

  always_comb begin
    next_flit_valid = 1'b0;
    next_flit_out = '0;
    next_flit_is_control = 1'b0;
    next_flit_is_alldata = 1'b0;
    next_rem = rem;
    next_lat = lat;
    crd_taken_comb = 1'b0;
    next_slot0 = '0; next_slot1 = '0; next_slot2 = '0; next_slot3 = '0;
    next_crc = 16'h0000;
    hdr_bits = '0;

    if (slot_free) begin
      if (rem > 0) begin
        if (rem > 3) begin
          next_flit_valid = 1'b1;
          next_flit_is_alldata = 1'b1;
          next_flit_is_control = 1'b0;
          next_rem = rem - 4;
          next_lat = llcrd_eff;
          crd_taken_comb = 1'b0;
          next_slot0 = chunk_buf[total_chunks - rem];
          next_slot1 = chunk_buf[total_chunks - rem + 1];
          next_slot2 = chunk_buf[total_chunks - rem + 2];
          next_slot3 = chunk_buf[total_chunks - rem + 3];
        end else begin
          next_flit_valid = 1'b1;
          next_flit_is_alldata = 1'b0;
          next_flit_is_control = 1'b0;
          next_rem = 0;
          next_lat = llcrd_eff;
          crd_taken_comb = 1'b1;
          hdr_bits[0] = 1'b0;
          hdr_bits[1] = 1'b0;
          hdr_bits[2] = 1'b0;
          hdr_bits[3] = 1'b0;
          hdr_bits[4] = 1'b0;
          hdr_bits[7:5] = (DIRECTION == 0) ? SLOT_H5 : SLOT_H3;
          hdr_bits[10:8] = (rem > 0) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[13:11] = (rem > 1) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[16:14] = (rem > 2) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[19:17] = 3'b0;
          hdr_bits[23:20] = crd_rsp_field;
          hdr_bits[27:24] = crd_req_field;
          hdr_bits[31:28] = crd_data_field;
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = '0;
          if (rem > 0) next_slot1 = chunk_buf[total_chunks - rem];
          if (rem > 1) next_slot2 = chunk_buf[total_chunks - rem + 1];
          if (rem > 2) next_slot3 = chunk_buf[total_chunks - rem + 2];
        end
      end else if (llcrd_eff) begin
        next_flit_valid = 1'b1;
        next_flit_is_alldata = 1'b0;
        next_flit_is_control = 1'b1;
        next_rem = 0;
        next_lat = 1'b0;
        crd_taken_comb = 1'b1;
        hdr_bits[0] = 1'b1;
        hdr_bits[1] = 1'b0;
        hdr_bits[2] = 1'b0;
        hdr_bits[4:3] = 2'b0;
        hdr_bits[7:5] = 3'b000;
        hdr_bits[15:8] = 8'h00;
        hdr_bits[19:16] = 4'h0;
        hdr_bits[23:20] = crd_rsp_field;
        hdr_bits[27:24] = crd_req_field;
        hdr_bits[31:28] = crd_data_field;
        next_slot0[31:0] = hdr_bits;
        next_slot0[35:32] = 4'b0000;
        next_slot0[39:36] = 4'b0000;
        next_slot0[63:40] = 24'h0;
        next_slot0[127:64] = 64'h0;
        next_slot1 = '0; next_slot2 = '0; next_slot3 = '0;
      end else if (msg_valid) begin
        next_flit_valid = 1'b1;
        next_flit_is_alldata = 1'b0;
        next_flit_is_control = 1'b0;
        next_lat = llcrd_eff;
        crd_taken_comb = 1'b1;
        hdr_bits[0] = 1'b0;
        hdr_bits[1] = 1'b0;
        hdr_bits[2] = 1'b0;
        hdr_bits[3] = msg_be_bit_comb;
        hdr_bits[4] = msg_sz_bit_comb;
        hdr_bits[7:5] = msg_sel0_comb;
        if (n_chunks_comb > 3) begin
          next_rem = n_chunks_comb - 3;
          hdr_bits[10:8] = SLOT_G0;
          hdr_bits[13:11] = SLOT_G0;
          hdr_bits[16:14] = SLOT_G0;
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = msg_slot0_content_comb;
          next_slot1 = chunks_comb[0];
          next_slot2 = chunks_comb[1];
          next_slot3 = chunks_comb[2];
        end else if (n_chunks_comb > 0) begin
          next_rem = 0;
          hdr_bits[10:8] = (n_chunks_comb > 0) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[13:11] = (n_chunks_comb > 1) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[16:14] = (n_chunks_comb > 2) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = msg_slot0_content_comb;
          if (n_chunks_comb > 0) next_slot1 = chunks_comb[0];
          if (n_chunks_comb > 1) next_slot2 = chunks_comb[1];
          if (n_chunks_comb > 2) next_slot3 = chunks_comb[2];
        end else begin
          next_rem = 0;
          hdr_bits[10:8] = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          hdr_bits[13:11] = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          hdr_bits[16:14] = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = msg_slot0_content_comb;
        end
        hdr_bits[19:17] = 3'b0;
        hdr_bits[23:20] = crd_rsp_field;
        hdr_bits[27:24] = crd_req_field;
        hdr_bits[31:28] = crd_data_field;
        next_slot0[31:0] = hdr_bits;
      end else begin
        next_flit_valid = 1'b0;
        next_rem = 0;
        next_lat = llcrd_eff;
        crd_taken_comb = 1'b0;
      end

      if (next_flit_valid) begin
        next_flit_out = {next_crc, next_slot3, next_slot2, next_slot1, next_slot0};
      end
    end else begin
      next_flit_valid = flit_valid_r;
      next_flit_out = flit_out_r;
      next_flit_is_control = flit_is_control_r;
      next_flit_is_alldata = flit_is_alldata_r;
      next_rem = rem;
      next_lat = llcrd_eff;
      crd_taken_comb = 1'b0;
    end
  end

  assign crd_taken = rst_n ? crd_taken_comb : 1'b0;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid_r      <= 1'b0;
      flit_out_r        <= '0;
      flit_is_control_r <= 1'b0;
      flit_is_alldata_r <= 1'b0;
      rem               <= 4'd0;
      lat               <= 1'b0;
      total_chunks      <= 4'd0;
      for (int i = 0; i < MAX_CHUNKS; i++) chunk_buf[i] <= '0;
      msg_slot0_content_r <= '0;
      msg_be_bit_r      <= 1'b0;
      msg_sz_bit_r      <= 1'b0;
      msg_sel0_r        <= SLOT_H5;
    end else begin
      flit_valid_r      <= next_flit_valid;
      flit_out_r        <= next_flit_out;
      flit_is_control_r <= next_flit_is_control;
      flit_is_alldata_r <= next_flit_is_alldata;
      rem               <= next_rem;
      lat               <= next_lat;
      if (msg_valid && msg_ready) begin
        total_chunks <= n_chunks_comb;
        for (int i = 0; i < MAX_CHUNKS; i++) chunk_buf[i] <= chunks_comb[i];
        msg_slot0_content_r <= msg_slot0_content_comb;
        msg_be_bit_r      <= msg_be_bit_comb;
        msg_sz_bit_r      <= msg_sz_bit_comb;
        msg_sel0_r        <= msg_sel0_comb;
      end
    end
  end

endmodule
