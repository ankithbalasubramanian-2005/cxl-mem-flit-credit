module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G3 = 3'b011;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_REQ_MEMRD     = 4'b0001;
  localparam logic [3:0] OP_M2S_REQ_MEMRDDATA = 4'b0010;
  localparam logic [3:0] OP_M2S_RWD_MEMWR     = 4'b0001;
  localparam logic [3:0] OP_M2S_RWD_MEMWRP    = 4'b0010;
  localparam logic [2:0] OP_S2M_NDR_CMP       = 3'b000;
  localparam logic [2:0] OP_S2M_DRS_MEMDATA   = 3'b000;

  logic [3:0] rem;
  logic       lat;
  logic       flit_valid_r;
  logic [527:0] flit_out_r;
  logic       flit_is_control_r;
  logic       flit_is_alldata_r;

  assign flit_valid      = flit_valid_r;
  assign flit_out        = flit_out_r;
  assign flit_is_control = flit_is_control_r;
  assign flit_is_alldata = flit_is_alldata_r;

  logic slot_free;
  logic llcrd_eff;
  assign slot_free = !flit_valid_r || flit_ready;
  assign llcrd_eff = lat || force_llcrd;
  assign msg_ready = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  logic [127:0] chunks [0:MAX_CHUNKS-1];
  logic [3:0]   n_chunks;
  logic [127:0] msg_slot0_content;
  logic         msg_be_bit, msg_sz_bit;
  logic [2:0]   msg_sel0;

  always_comb begin
    for (int i = 0; i < MAX_CHUNKS; i++) chunks[i] = '0;
    n_chunks = 0;
    msg_slot0_content = '0;
    msg_be_bit = 1'b0;
    msg_sz_bit = 1'b0;
    msg_sel0 = SLOT_H5;

    if (chunks_ovr_en) begin
      for (int i = 0; i < MAX_CHUNKS; i++) chunks[i] = msg_data[128*i +: 128];
      n_chunks = chunks_ovr;
      if (DIRECTION == 0) begin
        if (msg_kind == 1) begin // RwD
          msg_sel0 = SLOT_H4;
          msg_sz_bit = 1'b1;
          if (msg_opcode == OP_M2S_RWD_MEMWRP) msg_be_bit = 1'b1;
        end else begin // Req
          msg_sel0 = SLOT_H5;
        end
      end else begin // S2M
        msg_sel0 = SLOT_H3;
        if (msg_kind == 1) msg_sz_bit = 1'b1; // DRS
      end
    end else begin
      if (DIRECTION == 0) begin // M2S
        if (msg_kind == 0) begin // Req (H5)
          n_chunks = 0;
          msg_sel0 = SLOT_H5;
          // Figure 54 layout (bits 32-118 of slot0)
          msg_slot0_content[0]     = 1'b1;                    // Valid at bit 32
          msg_slot0_content[4:1]   = msg_opcode;              // MemOpcode [35:32]
          msg_slot0_content[7:5]   = 3'b000;                  // SnpType [38:36]
          msg_slot0_content[9:8]   = 2'b11;                   // MetaField [40:39]
          msg_slot0_content[11:10] = 2'b00;                   // MetaValue [42:41]
          msg_slot0_content[27:12] = msg_tag;                 // Tag [58:43]
          msg_slot0_content[74:28] = msg_addr[51:5];          // Address[51:5] [105:59]
          msg_slot0_content[76:75] = 2'b00;                   // TC [107:106]
          msg_slot0_content[80:77] = 4'b0000;                 // LD-ID [111:108]
          msg_slot0_content[86:81] = 6'b0;                    // RSVD [117:112]
        end else begin // RwD (H4)
          msg_sel0 = SLOT_H4;
          msg_sz_bit = 1'b1;
          if (msg_opcode == OP_M2S_RWD_MEMWR) begin
            n_chunks = 4;
            for (int i = 0; i < 4; i++) chunks[i] = msg_data[128*i +: 128];
          end else begin // MemWrPtl
            n_chunks = 5;
            for (int i = 0; i < 4; i++) chunks[i] = msg_data[128*i +: 128];
            chunks[4] = {64'b0, msg_byte_en}; // BE chunk (Figure 57)
            msg_be_bit = 1'b1;
          end
          // Figure 53 layout (bits 32-118 of slot0)
          msg_slot0_content[0]     = 1'b1;                    // Valid at bit 32
          msg_slot0_content[4:1]   = msg_opcode;              // MemOpcode [35:32]
          msg_slot0_content[7:5]   = 3'b000;                  // SnpType [38:36]
          msg_slot0_content[9:8]   = 2'b11;                   // MetaField [40:39]
          msg_slot0_content[11:10] = 2'b00;                   // MetaValue [42:41]
          msg_slot0_content[27:12] = msg_tag;                 // Tag [58:43]
          msg_slot0_content[73:28] = msg_addr[51:6];          // Address[51:6] [104:59]
          msg_slot0_content[74]    = msg_poison;              // Poison [105]
          msg_slot0_content[76:75] = 2'b00;                   // TC [107:106]
          msg_slot0_content[80:77] = 4'b0000;                 // LD-ID [111:108]
          msg_slot0_content[86:81] = 6'b0;                    // RSVD [117:112]
        end
      end else begin // S2M
        if (msg_kind == 0) begin // NDR (H3 second position)
          n_chunks = 0;
          msg_sel0 = SLOT_H3;
          // Figure 66 second message (bits 72-101 of slot0 = content bits 40-69)
          msg_slot0_content[40]      = 1'b1;                  // Valid at bit 72
          msg_slot0_content[43:41]   = msg_opcode[2:0];       // Opcode [74:72]
          msg_slot0_content[45:44]   = 2'b11;                 // MetaField [76:75]
          msg_slot0_content[47:46]   = 2'b00;                 // MetaValue [78:77]
          msg_slot0_content[63:48]   = msg_tag;               // Tag [94:79]
          msg_slot0_content[67:64]   = 4'b0000;               // LD-ID [98:95]
          msg_slot0_content[69:68]   = 2'b00;                 // DevLoad [100:99]
        end else begin // DRS (H3 first position)
          n_chunks = 4;
          for (int i = 0; i < 4; i++) chunks[i] = msg_data[128*i +: 128];
          msg_sel0 = SLOT_H3;
          msg_sz_bit = 1'b1;
          // Figure 66 first message (bits 32-71 of slot0 = content bits 0-39)
          msg_slot0_content[0]       = 1'b1;                  // Valid at bit 32
          msg_slot0_content[3:1]     = msg_opcode[2:0];       // Opcode [34:32]
          msg_slot0_content[5:4]     = 2'b11;                 // MetaField [36:35]
          msg_slot0_content[7:6]     = 2'b00;                 // MetaValue [38:37]
          msg_slot0_content[23:8]    = msg_tag;               // Tag [54:39]
          msg_slot0_content[24]      = msg_poison;            // Poison [55]
          msg_slot0_content[28:25]   = 4'b0000;               // LD-ID [59:56]
          msg_slot0_content[30:29]   = 2'b00;                 // DevLoad [61:60]
          msg_slot0_content[39:31]   = 9'b0;                  // RSVD [71:62]
        end
      end
    end
  end

  logic [127:0] next_slot0, next_slot1, next_slot2, next_slot3;
  logic [15:0]  next_crc;
  logic         next_flit_valid, next_flit_is_control, next_flit_is_alldata;
  logic [3:0]   next_rem;
  logic         next_lat;
  logic         crd_taken_comb;
  logic [31:0]  hdr_bits;
  logic [527:0] next_flit_out;

  always_comb begin
    next_flit_valid = 1'b0;
    next_flit_out = '0;
    next_flit_is_control = 1'b0;
    next_flit_is_alldata = 1'b0;
    next_rem = rem;
    next_lat = lat;
    crd_taken_comb = 1'b0;
    next_slot0 = '0; next_slot1 = '0; next_slot2 = '0; next_slot3 = '0;
    next_crc = 16'h0000;
    hdr_bits = '0;

    if (slot_free) begin
      if (rem > 0) begin
        if (rem > 3) begin
          // all-data flit: 4 data chunks, no header
          next_flit_valid = 1'b1;
          next_flit_is_alldata = 1'b1;
          next_flit_is_control = 1'b0;
          next_rem = rem - 4;
          next_lat = llcrd_eff;
          crd_taken_comb = 1'b0;
          next_slot0 = chunks[n_chunks - rem];
          next_slot1 = chunks[n_chunks - rem + 1];
          next_slot2 = chunks[n_chunks - rem + 2];
          next_slot3 = chunks[n_chunks - rem + 3];
        end else begin
          // protocol rollover flit: header with no message, rollover chunks in slots 1..
          next_flit_valid = 1'b1;
          next_flit_is_alldata = 1'b0;
          next_flit_is_control = 1'b0;
          next_rem = 0;
          next_lat = llcrd_eff;
          crd_taken_comb = 1'b1;
          // Header: Type=0, RV=0, Ak=0, BE=0, Sz=0
          hdr_bits[0] = 1'b0;  // Type
          hdr_bits[1] = 1'b0;  // RV
          hdr_bits[2] = 1'b0;  // Ak
          hdr_bits[3] = 1'b0;  // BE
          hdr_bits[4] = 1'b0;  // Sz
          hdr_bits[7:5] = (DIRECTION == 0) ? SLOT_H5 : SLOT_H3; // Slot0 format (empty)
          hdr_bits[10:8] = (rem > 0) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[13:11] = (rem > 1) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[16:14] = (rem > 2) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[19:17] = 3'b0;
          hdr_bits[23:20] = crd_rsp_field;
          hdr_bits[27:24] = crd_req_field;
          hdr_bits[31:28] = crd_data_field;
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = '0; // no message
          if (rem > 0) next_slot1 = chunks[n_chunks - rem];
          if (rem > 1) next_slot2 = chunks[n_chunks - rem + 1];
          if (rem > 2) next_slot3 = chunks[n_chunks - rem + 2];
        end
      end else if (llcrd_eff) begin
        // LLCRD control flit
        next_flit_valid = 1'b1;
        next_flit_is_alldata = 1'b0;
        next_flit_is_control = 1'b1;
        next_rem = 0;
        next_lat = 1'b0;
        crd_taken_comb = 1'b1;
        // Slot0 per Figure 78
        hdr_bits[0] = 1'b1;   // Type = 1 (Control)
        hdr_bits[1] = 1'b0;   // RV
        hdr_bits[2] = 1'b0;   // Ak
        hdr_bits[4:3] = 2'b0; // RSVD (BE, Sz positions)
        hdr_bits[7:5] = 3'b000; // CTL_FMT
        hdr_bits[15:8] = 8'h00;
        hdr_bits[19:16] = 4'h0;
        hdr_bits[23:20] = crd_rsp_field;
        hdr_bits[27:24] = crd_req_field;
        hdr_bits[31:28] = crd_data_field;
        next_slot0[31:0] = hdr_bits;
        next_slot0[35:32] = 4'b0000; // LLCTRL = LLCRD
        next_slot0[39:36] = 4'b0000; // SubType
        next_slot0[63:40] = 24'h0;
        next_slot0[127:64] = 64'h0;
        next_slot1 = '0; next_slot2 = '0; next_slot3 = '0;
      end else if (msg_valid) begin
        // First flit of message
        next_flit_valid = 1'b1;
        next_flit_is_alldata = 1'b0;
        next_flit_is_control = 1'b0;
        next_lat = llcrd_eff;
        crd_taken_comb = 1'b1;
        // Header
        hdr_bits[0] = 1'b0;  // Type = Protocol
        hdr_bits[1] = 1'b0;  // RV
        hdr_bits[2] = 1'b0;  // Ak
        hdr_bits[3] = msg_be_bit;
        hdr_bits[4] = msg_sz_bit;
        hdr_bits[7:5] = msg_sel0;
        if (n_chunks > 3) begin
          next_rem = n_chunks - 3;
          hdr_bits[10:8] = SLOT_G0;
          hdr_bits[13:11] = SLOT_G0;
          hdr_bits[16:14] = SLOT_G0;
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = msg_slot0_content;
          next_slot1 = chunks[0];
          next_slot2 = chunks[1];
          next_slot3 = chunks[2];
        end else if (n_chunks > 0) begin
          next_rem = 0;
          hdr_bits[10:8] = (n_chunks > 0) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[13:11] = (n_chunks > 1) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          hdr_bits[16:14] = (n_chunks > 2) ? SLOT_G0 : ((DIRECTION == 0) ? SLOT_G4 : SLOT_G5);
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = msg_slot0_content;
          if (n_chunks > 0) next_slot1 = chunks[0];
          if (n_chunks > 1) next_slot2 = chunks[1];
          if (n_chunks > 2) next_slot3 = chunks[2];
        end else begin
          next_rem = 0;
          hdr_bits[10:8] = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          hdr_bits[13:11] = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          hdr_bits[16:14] = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          next_slot0[31:0] = hdr_bits;
          next_slot0[127:32] = msg_slot0_content;
        end
        hdr_bits[19:17] = 3'b0;
        hdr_bits[23:20] = crd_rsp_field;
        hdr_bits[27:24] = crd_req_field;
        hdr_bits[31:28] = crd_data_field;
        next_slot0[31:0] = hdr_bits;
      end else begin
        next_flit_valid = 1'b0;
        next_rem = 0;
        next_lat = llcrd_eff;
        crd_taken_comb = 1'b0;
      end

      if (next_flit_valid) begin
        next_flit_out = {next_crc, next_slot3, next_slot2, next_slot1, next_slot0};
      end
    end else begin
      // Hold current flit
      next_flit_valid = flit_valid_r;
      next_flit_out = flit_out_r;
      next_flit_is_control = flit_is_control_r;
      next_flit_is_alldata = flit_is_alldata_r;
      next_rem = rem;
      next_lat = llcrd_eff;
      crd_taken_comb = 1'b0;
    end
  end

  assign crd_taken = crd_taken_comb;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid_r      <= 1'b0;
      flit_out_r        <= '0;
      flit_is_control_r <= 1'b0;
      flit_is_alldata_r <= 1'b0;
      rem               <= 4'd0;
      lat               <= 1'b0;
    end else begin
      flit_valid_r      <= next_flit_valid;
      flit_out_r        <= next_flit_out;
      flit_is_control_r <= next_flit_is_control;
      flit_is_alldata_r <= next_flit_is_alldata;
      rem               <= next_rem;
      lat               <= next_lat;
    end
  end

endmodule
