module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'b000;
  localparam logic [2:0] SLOT_H3 = 3'b011;
  localparam logic [2:0] SLOT_H4 = 3'b100;
  localparam logic [2:0] SLOT_H5 = 3'b101;
  localparam logic [2:0] SLOT_G0 = 3'b000;
  localparam logic [2:0] SLOT_G3 = 3'b011;
  localparam logic [2:0] SLOT_G4 = 3'b100;
  localparam logic [2:0] SLOT_G5 = 3'b101;

  localparam logic [3:0] OP_M2S_REQ_MEMRD    = 4'b0001;
  localparam logic [3:0] OP_M2S_REQ_MEMRDDATA= 4'b0010;
  localparam logic [3:0] OP_M2S_RWD_MEMWR    = 4'b0001;
  localparam logic [3:0] OP_M2S_RWD_MEMWRP   = 4'b0010;
  localparam logic [2:0] OP_S2M_NDR_CMP      = 3'b000;
  localparam logic [2:0] OP_S2M_DRS_MEMDATA  = 3'b000;

  logic [3:0] rem;
  logic       lat;

  logic [127:0] chunks [0:MAX_CHUNKS-1];
  logic [3:0]   n_chunks;

  logic [127:0] slot0, slot1, slot2, slot3;
  logic [15:0]  crc16;
  logic [2:0]   sel0, sel1, sel2, sel3;
  logic         type_bit, be_bit, sz_bit;
  logic         is_control, is_alldata;

  logic slot_free;
  logic llcrd_eff;
  logic msg_ready_int;

  assign slot_free   = !flit_valid || flit_ready;
  assign llcrd_eff   = lat || force_llcrd;
  assign msg_ready   = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  always_comb begin
    for (int i = 0; i < MAX_CHUNKS; i++) chunks[i] = msg_data[128*i +: 128];
    if (chunks_ovr_en) begin
      n_chunks = chunks_ovr;
    end else begin
      if (DIRECTION == 0) begin
        if (msg_kind == 0) n_chunks = 0;
        else if (msg_opcode == OP_M2S_RWD_MEMWR) n_chunks = 4;
        else n_chunks = 5;
      end else begin
        if (msg_kind == 0) n_chunks = 0;
        else n_chunks = 4;
      end
    end
  end

  always_comb begin
    slot0 = '0; slot1 = '0; slot2 = '0; slot3 = '0;
    sel0 = SLOT_H5; sel1 = SLOT_G4; sel2 = SLOT_G4; sel3 = SLOT_G4;
    type_bit = 1'b0; be_bit = 1'b0; sz_bit = 1'b0;
    is_control = 1'b0; is_alldata = 1'b0;
    crc16 = 16'h0000;

    if (DIRECTION == 0) begin
      if (msg_kind == 0) begin
        slot0[32] = 1'b1;
        slot0[36:33] = msg_opcode;
        slot0[39:37] = 3'b000;
        slot0[41:40] = 2'b11;
        slot0[43:42] = 2'b00;
        slot0[59:44] = msg_tag;
        slot0[106:60] = msg_addr[51:5];
        slot0[108:107] = 2'b00;
        slot0[112:109] = 4'b0000;
        sel0 = SLOT_H5;
      end else begin
        slot0[32] = 1'b1;
        slot0[36:33] = msg_opcode;
        slot0[39:37] = 3'b000;
        slot0[41:40] = 2'b11;
        slot0[43:42] = 2'b00;
        slot0[59:44] = msg_tag;
        slot0[105:60] = msg_addr[51:6];
        slot0[106] = msg_poison;
        slot0[108:107] = 2'b00;
        slot0[112:109] = 4'b0000;
        sel0 = SLOT_H4;
        sz_bit = 1'b1;
        if (msg_opcode == OP_M2S_RWD_MEMWRP) be_bit = 1'b1;
      end
    end else begin
      if (msg_kind == 0) begin
        slot0[72] = 1'b1;
        slot0[75:73] = msg_opcode[2:0];
        slot0[77:76] = 2'b11;
        slot0[79:78] = 2'b00;
        slot0[95:80] = msg_tag;
        slot0[99:96] = 4'b0000;
        slot0[101:100] = 2'b00;
        sel0 = SLOT_H3;
      end else begin
        slot0[32] = 1'b1;
        slot0[35:33] = msg_opcode[2:0];
        slot0[37:36] = 2'b11;
        slot0[39:38] = 2'b00;
        slot0[55:40] = msg_tag;
        slot0[56] = msg_poison;
        slot0[60:57] = 4'b0000;
        slot0[62:61] = 2'b00;
        sel0 = SLOT_H3;
        sz_bit = 1'b1;
      end
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid      <= 1'b0;
      flit_out        <= '0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem             <= 4'd0;
      lat             <= 1'b0;
    end else begin
      if (slot_free) begin
        if (rem > 0) begin
          if (rem > 3) begin
            slot0 = chunks[n_chunks - rem];
            slot1 = chunks[n_chunks - rem + 1];
            slot2 = chunks[n_chunks - rem + 2];
            slot3 = chunks[n_chunks - rem + 3];
            sel0 = SLOT_G0; sel1 = SLOT_G0; sel2 = SLOT_G0; sel3 = SLOT_G0;
            type_bit = 1'b0; be_bit = 1'b0; sz_bit = 1'b0;
            is_alldata = 1'b1; is_control = 1'b0;
            rem <= rem - 4;
            crd_taken <= 1'b0;
            lat <= llcrd_eff;
          end else begin
            for (int i = 0; i < rem; i++) begin
              case (i)
                0: slot1 = chunks[n_chunks - rem];
                1: slot2 = chunks[n_chunks - rem + 1];
                2: slot3 = chunks[n_chunks - rem + 2];
              endcase
            end
            sel1 = (rem > 0) ? SLOT_G0 : SLOT_G4;
            sel2 = (rem > 1) ? SLOT_G0 : SLOT_G4;
            sel3 = (rem > 2) ? SLOT_G0 : SLOT_G4;
            is_alldata = 1'b0; is_control = 1'b0;
            rem <= 4'd0;
            crd_taken <= 1'b1;
            lat <= llcrd_eff;
          end
        end else if (llcrd_eff) begin
          slot0[0] = 1'b1;
          slot0[1] = 1'b0;
          slot0[2] = 1'b0;
          slot0[4:3] = 2'b00;
          slot0[7:5] = 3'b000;
          slot0[15:8] = 8'h00;
          slot0[19:16] = 4'h0;
          slot0[23:20] = crd_rsp_field;
          slot0[27:24] = crd_req_field;
          slot0[31:28] = crd_data_field;
          slot0[35:32] = 4'b0000;
          slot0[39:36] = 4'b0000;
          slot0[63:40] = 24'h0;
          slot0[127:64] = 64'h0;
          slot1 = '0; slot2 = '0; slot3 = '0;
          sel0 = SLOT_H0; sel1 = SLOT_H0; sel2 = SLOT_H0; sel3 = SLOT_H0;
          type_bit = 1'b1; be_bit = 1'b0; sz_bit = 1'b0;
          is_control = 1'b1; is_alldata = 1'b0;
          crd_taken <= 1'b1;
          lat <= 1'b0;
        end else if (msg_valid) begin
          if (n_chunks > 3) begin
            slot1 = chunks[0];
            slot2 = chunks[1];
            slot3 = chunks[2];
            sel1 = SLOT_G0; sel2 = SLOT_G0; sel3 = SLOT_G0;
            rem <= n_chunks - 3;
            crd_taken <= 1'b1;
            lat <= llcrd_eff;
          end else if (n_chunks > 0) begin
            for (int i = 0; i < n_chunks; i++) begin
              case (i)
                0: slot1 = chunks[0];
                1: slot2 = chunks[0];
                2: slot3 = chunks[0];
              endcase
            end
            sel1 = (n_chunks > 0) ? SLOT_G0 : SLOT_G4;
            sel2 = (n_chunks > 1) ? SLOT_G0 : SLOT_G4;
            sel3 = (n_chunks > 2) ? SLOT_G0 : SLOT_G4;
            rem <= 4'd0;
            crd_taken <= 1'b1;
            lat <= llcrd_eff;
          end else begin
            crd_taken <= 1'b1;
            lat <= llcrd_eff;
          end
          is_control = 1'b0; is_alldata = 1'b0;
        end else begin
          flit_valid <= 1'b0;
          crd_taken <= 1'b0;
          lat <= llcrd_eff;
        end

        if (rem > 0 || llcrd_eff || msg_valid) begin
          flit_valid <= 1'b1;
          flit_out <= {crc16, slot3, slot2, slot1, slot0};
          flit_is_control <= is_control;
          flit_is_alldata <= is_alldata;
        end
      end else begin
        crd_taken <= 1'b0;
        lat <= llcrd_eff;
      end
    end
  end

endmodule
