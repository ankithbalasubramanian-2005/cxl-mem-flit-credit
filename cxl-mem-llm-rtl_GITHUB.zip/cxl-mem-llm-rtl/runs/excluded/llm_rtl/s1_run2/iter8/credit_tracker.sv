module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [1:0];
  logic [7:0] pend [1:0];

  function automatic logic [6:0] dec_credits(input logic [3:0] f);
    logic [2:0] v;
    begin
      if (!f[3]) return 7'd0;
      v = f[2:0];
      case (v)
        3'b000: return 7'd0;
        3'b001: return 7'd1;
        3'b010: return 7'd2;
        3'b011: return 7'd4;
        3'b100: return 7'd8;
        3'b101: return 7'd16;
        3'b110: return 7'd32;
        3'b111: return 7'd64;
        default: return 7'd0;
      endcase
    end
  endfunction

  function automatic logic [3:0] enc_credits(input logic [7:0] v);
    logic [3:0] e;
    begin
      if (v == 0) e = 4'b1000;
      else if (v >= 64) e = 4'b1111;
      else if (v >= 32) e = 4'b1110;
      else if (v >= 16) e = 4'b1101;
      else if (v >= 8)  e = 4'b1100;
      else if (v >= 4)  e = 4'b1011;
      else if (v >= 2)  e = 4'b1010;
      else              e = 4'b1001;
      return e;
    end
  endfunction

  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];
  assign can_send     = {snd[1] != 0, snd[0] != 0};
  assign pend_0       = pend[0];
  assign pend_1       = pend[1];
  assign crd_pending  = (pend[0] != 0) || (pend[1] != 0);

  always_comb begin
    if (DIRECTION == 0) begin
      crd_req_field  = 4'b0000;
      crd_data_field = enc_credits(pend[1]);
      crd_rsp_field  = enc_credits(pend[0]);
    end else begin
      crd_req_field  = enc_credits(pend[0]);
      crd_data_field = enc_credits(pend[1]);
      crd_rsp_field  = 4'b0000;
    end
  end

  always_ff @(posedge clk) begin
    logic [6:0] add0, add1;
    logic [7:0] take0, take1;
    logic [6:0] snd0_next, snd1_next;
    logic [7:0] pend0_next, pend1_next;

    if (!rst_n) begin
      snd[0]  <= 7'd0;
      snd[1]  <= 7'd0;
      pend[0] <= RX_DEPTH[7:0];
      pend[1] <= RX_DEPTH[7:0];
    end else begin
      if (DIRECTION == 0) begin
        add0 = dec_credits(rx_crd_valid ? rx_reqcrd : 4'b0000);
        add1 = dec_credits(rx_crd_valid ? rx_datacrd : 4'b0000);
      end else begin
        add0 = dec_credits(rx_crd_valid ? rx_rspcrd : 4'b0000);
        add1 = dec_credits(rx_crd_valid ? rx_datacrd : 4'b0000);
      end

      snd0_next = snd[0] - (tx_send[0] && snd[0] != 0) + add0;
      snd1_next = snd[1] - (tx_send[1] && snd[1] != 0) + add1;
      snd[0] <= (snd0_next > CREDIT_MAX) ? CREDIT_MAX[6:0] : snd0_next;
      snd[1] <= (snd1_next > CREDIT_MAX) ? CREDIT_MAX[6:0] : snd1_next;

      if (DIRECTION == 0) begin
        take0 = (crd_taken) ? dec_credits(crd_rsp_field) : 8'd0;
        take1 = (crd_taken) ? dec_credits(crd_data_field) : 8'd0;
      end else begin
        take0 = (crd_taken) ? dec_credits(crd_req_field) : 8'd0;
        take1 = (crd_taken) ? dec_credits(crd_data_field) : 8'd0;
      end

      pend0_next = pend[0] + buf_free[0] - take0;
      pend1_next = pend[1] + buf_free[1] - take1;
      pend[0] <= (pend0_next > PEND_MAX) ? PEND_MAX[7:0] : pend0_next;
      pend[1] <= (pend1_next > PEND_MAX) ? PEND_MAX[7:0] : pend1_next;
    end
  end

endmodule
