module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd_reg [1:0];
  logic [7:0] pend_reg [1:0];

  logic [6:0] snd_nxt [1:0];
  logic [7:0] pend_nxt [1:0];

  logic [6:0] add [1:0];
  logic [7:0] take [1:0];

  function automatic logic [6:0] dec_credits(input logic [3:0] f);
    logic [2:0] v;
    begin
      if (!f[3]) return 7'd0;
      v = f[2:0];
      case (v)
        3'b000: return 7'd0;
        3'b001: return 7'd1;
        3'b010: return 7'd2;
        3'b011: return 7'd4;
        3'b100: return 7'd8;
        3'b101: return 7'd16;
        3'b110: return 7'd32;
        3'b111: return 7'd64;
        default: return 7'd0;
      endcase
    end
  endfunction

  function automatic logic [3:0] enc_credits(input logic [7:0] v);
    logic [3:0] e;
    begin
      if (v == 0) e = 4'b1000;
      else if (v >= 64) e = 4'b1111;
      else if (v >= 32) e = 4'b1110;
      else if (v >= 16) e = 4'b1101;
      else if (v >= 8)  e = 4'b1100;
      else if (v >= 4)  e = 4'b1011;
      else if (v >= 2)  e = 4'b1010;
      else              e = 4'b1001;
      return e;
    end
  endfunction

  always_comb begin
    if (DIRECTION == 0) begin
      add[0] = dec_credits(rx_crd_valid ? rx_reqcrd : 4'b0000);
      add[1] = dec_credits(rx_crd_valid ? rx_datacrd : 4'b0000);
    end else begin
      add[0] = dec_credits(rx_crd_valid ? rx_rspcrd : 4'b0000);
      add[1] = dec_credits(rx_crd_valid ? rx_datacrd : 4'b0000);
    end

    for (int i = 0; i < 2; i++) begin
      logic [6:0] dec;
      dec = snd_reg[i] - (tx_send[i] && snd_reg[i] != 7'd0);
      snd_nxt[i] = dec + add[i];
      if (snd_nxt[i] > CREDIT_MAX[6:0]) snd_nxt[i] = CREDIT_MAX[6:0];
    end

    if (DIRECTION == 0) begin
      crd_req_field  = 4'b0000;
      crd_data_field = enc_credits(pend_reg[1]);
      crd_rsp_field  = enc_credits(pend_reg[0]);
    end else begin
      crd_req_field  = enc_credits(pend_reg[0]);
      crd_data_field = enc_credits(pend_reg[1]);
      crd_rsp_field  = 4'b0000;
    end

    if (DIRECTION == 0) begin
      take[0] = crd_taken ? dec_credits(crd_rsp_field) : 8'd0;
      take[1] = crd_taken ? dec_credits(crd_data_field) : 8'd0;
    end else begin
      take[0] = crd_taken ? dec_credits(crd_req_field) : 8'd0;
      take[1] = crd_taken ? dec_credits(crd_data_field) : 8'd0;
    end

    for (int i = 0; i < 2; i++) begin
      pend_nxt[i] = pend_reg[i] + buf_free[i] - take[i];
      if (pend_nxt[i] > PEND_MAX[7:0]) pend_nxt[i] = PEND_MAX[7:0];
    end
  end

  assign tx_credits_0 = snd_nxt[0];
  assign tx_credits_1 = snd_nxt[1];
  assign can_send     = {snd_nxt[1] != 7'd0, snd_nxt[0] != 7'd0};
  assign pend_0       = pend_reg[0];
  assign pend_1       = pend_reg[1];
  assign crd_pending  = (pend_reg[0] != 8'd0) || (pend_reg[1] != 8'd0);

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd_reg[0]  <= 7'd0;
      snd_reg[1]  <= 7'd0;
      pend_reg[0] <= RX_DEPTH[7:0];
      pend_reg[1] <= RX_DEPTH[7:0];
    end else begin
      snd_reg[0]  <= snd_nxt[0];
      snd_reg[1]  <= snd_nxt[1];
      pend_reg[0] <= pend_nxt[0];
      pend_reg[1] <= pend_nxt[1];
    end
  end

endmodule
