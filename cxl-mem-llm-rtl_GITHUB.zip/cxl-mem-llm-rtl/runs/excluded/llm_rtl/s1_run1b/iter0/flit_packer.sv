module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'd0;
  localparam logic [2:0] SLOT_H3 = 3'd3;
  localparam logic [2:0] SLOT_H4 = 3'd4;
  localparam logic [2:0] SLOT_H5 = 3'd5;
  localparam logic [2:0] SLOT_G0 = 3'd0;
  localparam logic [2:0] SLOT_G4 = 3'd4;
  localparam logic [2:0] SLOT_G5 = 3'd5;

  logic [3:0] rem;
  logic       lat;

  logic [127:0] chunk_list [0:MAX_CHUNKS-1];
  logic [3:0]   chunk_cnt;

  logic [127:0] slot0, slot1, slot2, slot3;
  logic [2:0]   sel0, sel1, sel2, sel3;
  logic         sz_bit, be_bit;
  logic [31:0]  hdr;

  logic slot_free;
  logic llcrd_eff;
  logic take_msg;
  logic do_rollover;
  logic do_llcrd;

  logic [127:0] next_slot0, next_slot1, next_slot2, next_slot3;
  logic [2:0]   next_sel0, next_sel1, next_sel2, next_sel3;
  logic         next_sz, next_be;
  logic [3:0]   next_rem;
  logic         next_lat;
  logic         next_flit_valid;
  logic         next_flit_is_control;
  logic         next_flit_is_alldata;
  logic [527:0] next_flit_out;
  logic         next_crd_taken;

  function automatic logic [3:0] enc_credit (input logic [7:0] n);
    logic [2:0] e;
    begin
      if (n == 0)       e = 3'd0;
      else if (n <= 1)  e = 3'd1;
      else if (n <= 2)  e = 3'd2;
      else if (n <= 4)  e = 3'd3;
      else if (n <= 8)  e = 3'd4;
      else if (n <= 16) e = 3'd5;
      else if (n <= 32) e = 3'd6;
      else              e = 3'd7;
      return {1'b1, e};
    end
  endfunction

  function automatic logic [7:0] dec_credit (input logic [3:0] f);
    logic [7:0] v;
    begin
      if (!f[3]) v = 8'd0;
      else case (f[2:0])
        3'd0: v = 8'd0;
        3'd1: v = 8'd1;
        3'd2: v = 8'd2;
        3'd3: v = 8'd4;
        3'd4: v = 8'd8;
        3'd5: v = 8'd16;
        3'd6: v = 8'd32;
        3'd7: v = 8'd64;
        default: v = 8'd0;
      endcase
      return v;
    end
  endfunction

  always_comb begin
    chunk_cnt = 4'd0;
    for (int i = 0; i < MAX_CHUNKS; i++) chunk_list[i] = 128'd0;

    if (chunks_ovr_en) begin
      chunk_cnt = chunks_ovr;
      for (int i = 0; i < MAX_CHUNKS; i++)
        if (i < chunks_ovr) chunk_list[i] = msg_data[128*i +: 128];
    end else begin
      if (DIRECTION == 0) begin
        if (msg_kind == 1'b0) begin
          chunk_cnt = 4'd0;
        end else begin
          if (msg_opcode == 4'h2) begin
            chunk_cnt = 4'd5;
            for (int i = 0; i < 4; i++) chunk_list[i] = msg_data[128*i +: 128];
            chunk_list[4] = {64'd0, msg_byte_en};
          end else begin
            chunk_cnt = 4'd4;
            for (int i = 0; i < 4; i++) chunk_list[i] = msg_data[128*i +: 128];
          end
        end
      end else begin
        if (msg_kind == 1'b0) begin
          chunk_cnt = 4'd0;
        end else begin
          chunk_cnt = 4'd4;
          for (int i = 0; i < 4; i++) chunk_list[i] = msg_data[128*i +: 128];
        end
      end
    end
  end

  always_comb begin
    slot_free     = !flit_valid || flit_ready;
    llcrd_eff     = lat || force_llcrd;
    msg_ready     = rst_n && slot_free && (rem == 4'd0) && !llcrd_eff;
    take_msg      = slot_free && msg_valid && (rem == 4'd0) && !llcrd_eff;
    do_rollover   = slot_free && (rem > 4'd0);
    do_llcrd      = slot_free && (rem == 4'd0) && llcrd_eff;
  end

  always_comb begin
    next_flit_valid      = 1'b0;
    next_flit_is_control = 1'b0;
    next_flit_is_alldata = 1'b0;
    next_flit_out        = 528'd0;
    next_crd_taken       = 1'b0;
    next_rem             = rem;
    next_lat             = lat;
    next_slot0           = 128'd0;
    next_slot1           = 128'd0;
    next_slot2           = 128'd0;
    next_slot3           = 128'd0;
    next_sel0            = 3'd0;
    next_sel1            = 3'd0;
    next_sel2            = 3'd0;
    next_sel3            = 3'd0;
    next_sz              = 1'b0;
    next_be              = 1'b0;

    if (slot_free) begin
      if (do_rollover) begin
        next_flit_valid = 1'b1;
        if (rem > 4'd3) begin
          next_flit_is_alldata = 1'b1;
          next_slot0 = chunk_list[chunk_cnt - rem];
          next_slot1 = chunk_list[chunk_cnt - rem + 1];
          next_slot2 = chunk_list[chunk_cnt - rem + 2];
          next_slot3 = chunk_list[chunk_cnt - rem + 3];
          next_sel0 = SLOT_G0; next_sel1 = SLOT_G0; next_sel2 = SLOT_G0; next_sel3 = SLOT_G0;
          next_rem = rem - 4'd4;
          next_crd_taken = 1'b0;
        end else begin
          next_flit_is_alldata = 1'b0;
          if (DIRECTION == 0) begin
            next_slot0 = 128'd0; next_sel0 = SLOT_H5;
            next_sel1 = SLOT_G4; next_sel2 = SLOT_G4; next_sel3 = SLOT_G4;
          end else begin
            next_slot0 = 128'd0; next_sel0 = SLOT_H3;
            next_sel1 = SLOT_G5; next_sel2 = SLOT_G5; next_sel3 = SLOT_G5;
          end
          next_sz = 1'b0; next_be = 1'b0;
          case (rem)
            4'd3: begin next_slot1 = chunk_list[chunk_cnt - 3]; next_slot2 = chunk_list[chunk_cnt - 2]; next_slot3 = chunk_list[chunk_cnt - 1]; next_sel1 = SLOT_G0; next_sel2 = SLOT_G0; next_sel3 = SLOT_G0; end
            4'd2: begin next_slot1 = chunk_list[chunk_cnt - 2]; next_slot2 = chunk_list[chunk_cnt - 1]; next_sel1 = SLOT_G0; next_sel2 = SLOT_G0; end
            4'd1: begin next_slot1 = chunk_list[chunk_cnt - 1]; next_sel1 = SLOT_G0; end
            default: ;
          endcase
          next_rem = 4'd0;
          next_crd_taken = 1'b1;
        end
        next_lat = llcrd_eff;
      end else if (do_llcrd) begin
        next_flit_valid      = 1'b1;
        next_flit_is_control = 1'b1;
        next_flit_is_alldata = 1'b0;
        next_slot0 = { 64'd0, 4'd0, 4'd0, 24'd0, 4'd0, crd_rsp_field, crd_req_field, crd_data_field, 1'b1, 1'b0, 1'b0, 2'b00, 3'd0 };
        next_sel0 = 3'd0; next_sel1 = 3'd0; next_sel2 = 3'd0; next_sel3 = 3'd0;
        next_slot1 = 128'd0; next_slot2 = 128'd0; next_slot3 = 128'd0;
        next_sz = 1'b0; next_be = 1'b0;
        next_rem = 4'd0;
        next_lat = 1'b0;
        next_crd_taken = 1'b1;
      end else if (take_msg) begin
        next_flit_valid      = 1'b1;
        next_flit_is_control = 1'b0;
        next_flit_is_alldata = 1'b0;
        next_rem = chunk_cnt;
        next_lat = llcrd_eff;
        next_crd_taken = 1'b1;

        if (DIRECTION == 0) begin
          if (msg_kind == 1'b0) begin
            next_sel0 = SLOT_H5;
            next_slot0 = { 9'd0, 4'd0, 2'd0, 2'd3, 16'd0, 47'd0, 2'd0, 4'd0, 6'd0, 1'b1, msg_opcode, 3'd0, 2'd3, 2'd0, msg_tag, msg_addr[51:5] };
            next_sel1 = SLOT_G4; next_sel2 = SLOT_G4; next_sel3 = SLOT_G4;
            next_sz = 1'b0; next_be = 1'b0;
          end else begin
            next_sel0 = SLOT_H4;
            next_slot0 = { 9'd0, 4'd0, 2'd0, 2'd3, 16'd0, 46'd0, 1'b0, 2'd0, 4'd0, 6'd0, 1'b1, msg_opcode, 3'd0, 2'd3, 2'd0, msg_tag, msg_addr[51:6] };
            next_sel1 = SLOT_G4; next_sel2 = SLOT_G4; next_sel3 = SLOT_G4;
            next_sz = 1'b1;
            next_be = (msg_opcode == 4'h2);
          end
        end else begin
          if (msg_kind == 1'b0) begin
            next_sel0 = SLOT_H3;
            next_slot0 = { 26'd0, 1'b0, msg_opcode[2:0], 2'd3, 2'd0, 16'd0, 4'd0, 2'd0, 9'd0, 1'b1, 3'd0, 2'd3, 2'd0, 16'd0, 4'd0, 2'd0, 9'd0 };
            next_sel1 = SLOT_G5; next_sel2 = SLOT_G5; next_sel3 = SLOT_G5;
            next_sz = 1'b0; next_be = 1'b0;
          end else begin
            next_sel0 = SLOT_H3;
            next_slot0 = { 26'd0, 1'b1, 3'd0, 2'd3, 2'd0, msg_tag, msg_poison, 4'd0, 2'd0, 9'd0, 1'b0, 3'd0, 2'd3, 2'd0, 16'd0, 4'd0, 2'd0, 9'd0 };
            next_sel1 = SLOT_G5; next_sel2 = SLOT_G5; next_sel3 = SLOT_G5;
            next_sz = 1'b1; next_be = 1'b0;
          end
        end
        if (chunk_cnt > 4'd3) begin
          next_slot1 = chunk_list[0];
          next_slot2 = chunk_list[1];
          next_slot3 = chunk_list[2];
          next_sel1 = SLOT_G0; next_sel2 = SLOT_G0; next_sel3 = SLOT_G0;
        end else if (chunk_cnt > 4'd2) begin
          next_slot1 = chunk_list[0];
          next_slot2 = chunk_list[1];
          next_sel1 = SLOT_G0; next_sel2 = SLOT_G0;
        end else if (chunk_cnt > 4'd1) begin
          next_slot1 = chunk_list[0];
          next_sel1 = SLOT_G0;
        end else if (chunk_cnt > 4'd0) begin
          next_slot1 = chunk_list[0];
          next_sel1 = SLOT_G0;
        end
      end else begin
        next_flit_valid = 1'b0;
        next_lat = llcrd_eff;
      end
    end else begin
      next_lat = llcrd_eff;
    end

    if (next_flit_valid) begin
      if (next_flit_is_control) begin
        hdr = next_slot0[31:0];
      end else if (next_flit_is_alldata) begin
        hdr = 32'd0;
      end else begin
        hdr = { crd_data_field, crd_req_field, crd_rsp_field, 3'd0, next_sel3, next_sel2, next_sel1, next_sel0, 3'd0, next_sz, next_be, 1'b0, 1'b0, 1'b0 };
      end
      next_flit_out = { 16'd0, next_slot3, next_slot2, next_slot1, {96'd0, hdr} };
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid      <= 1'b0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      flit_out        <= 528'd0;
      crd_taken       <= 1'b0;
      rem             <= 4'd0;
      lat             <= 1'b0;
    end else begin
      flit_valid      <= next_flit_valid;
      flit_is_control <= next_flit_is_control;
      flit_is_alldata <= next_flit_is_alldata;
      flit_out        <= next_flit_out;
      crd_taken       <= next_crd_taken;
      rem             <= next_rem;
      lat             <= next_lat;
    end
  end

endmodule
