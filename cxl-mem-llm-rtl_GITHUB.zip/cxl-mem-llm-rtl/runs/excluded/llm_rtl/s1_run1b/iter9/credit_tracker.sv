module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [0:1];
  logic [7:0] pend [0:1];

  logic [7:0] add_snd [0:1];
  logic [7:0] nxt_snd [0:1];
  logic [7:0] nxt_pend [0:1];
  logic [7:0] crd_val_sent [0:1];

  function automatic logic [3:0] enc_credit_greedy (input logic [7:0] n);
    logic [2:0] e;
    begin
      if (n == 0)       e = 3'd0;
      else if (n >= 64) e = 3'd7;
      else if (n >= 32) e = 3'd6;
      else if (n >= 16) e = 3'd5;
      else if (n >= 8)  e = 3'd4;
      else if (n >= 4)  e = 3'd3;
      else if (n >= 2)  e = 3'd2;
      else              e = 3'd1;
      return {1'b1, e};
    end
  endfunction

  function automatic logic [7:0] dec_credit (input logic [3:0] f);
    logic [7:0] v;
    begin
      if (!f[3]) v = 8'd0;
      else case (f[2:0])
        3'd0: v = 8'd0;
        3'd1: v = 8'd1;
        3'd2: v = 8'd2;
        3'd3: v = 8'd4;
        3'd4: v = 8'd8;
        3'd5: v = 8'd16;
        3'd6: v = 8'd32;
        3'd7: v = 8'd64;
        default: v = 8'd0;
      endcase
      return v;
    end
  endfunction

  always_comb begin
    add_snd[0] = 8'd0;
    add_snd[1] = 8'd0;
    if (rx_crd_valid) begin
      if (DIRECTION == 0) begin
        if (rx_reqcrd[3])  add_snd[0] = dec_credit(rx_reqcrd);
        if (rx_datacrd[3]) add_snd[1] = dec_credit(rx_datacrd);
      end else begin
        if (rx_rspcrd[3])  add_snd[0] = dec_credit(rx_rspcrd);
        if (rx_datacrd[3]) add_snd[1] = dec_credit(rx_datacrd);
      end
    end

    for (int i = 0; i < 2; i++) begin
      logic [7:0] v;
      v = snd[i];
      if (tx_send[i] && v != 0) v = v - 1;
      v = v + add_snd[i];
      if (v > CREDIT_MAX) v = CREDIT_MAX;
      nxt_snd[i] = v;
    end

    if (DIRECTION == 0) begin
      crd_req_field  = 4'd0;
      crd_data_field = enc_credit_greedy(pend[1]);
      crd_rsp_field  = enc_credit_greedy(pend[0]);
    end else begin
      crd_req_field  = enc_credit_greedy(pend[0]);
      crd_data_field = enc_credit_greedy(pend[1]);
      crd_rsp_field  = 4'd0;
    end

    for (int i = 0; i < 2; i++) begin
      logic [3:0] fld;
      if (DIRECTION == 0) begin
        fld = (i == 0) ? crd_rsp_field : crd_data_field;
      end else begin
        fld = (i == 0) ? crd_req_field : crd_data_field;
      end
      crd_val_sent[i] = dec_credit(fld);
    end

    for (int i = 0; i < 2; i++) begin
      logic [7:0] v;
      v = pend[i];
      v = v + buf_free[i];
      if (crd_taken) begin
        if (v >= crd_val_sent[i]) v = v - crd_val_sent[i];
        else v = 8'd0;
      end
      if (v > PEND_MAX) v = PEND_MAX;
      nxt_pend[i] = v;
    end

    crd_pending = (pend[0] != 0) || (pend[1] != 0);
    can_send    = { snd[1] != 0, snd[0] != 0 };
    tx_credits_0 = snd[0];
    tx_credits_1 = snd[1];
    pend_0       = pend[0];
    pend_1       = pend[1];
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0]  <= 7'd0;
      snd[1]  <= 7'd0;
      pend[0] <= RX_DEPTH[7:0];
      pend[1] <= RX_DEPTH[7:0];
    end else begin
      snd[0]  <= nxt_snd[0];
      snd[1]  <= nxt_snd[1];
      pend[0] <= nxt_pend[0];
      pend[1] <= nxt_pend[1];
    end
  end

endmodule
