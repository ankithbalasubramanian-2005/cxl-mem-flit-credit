module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  // State registers
  logic [6:0] snd[0:1];   // sender credits per channel
  logic [7:0] pend[0:1];   // pending-return counters

  // Helper functions for credit encoding/decoding
  function automatic [3:0] encode_credits(int count);
    if (count == 0) return 4'b0000;
    else if (count == 1) return 4'b0001;
    else if (count == 2) return 4'b0010;
    else if (count == 4) return 4'b0011;
    else if (count == 8) return 4'b0100;
    else if (count == 16) return 4'b0101;
    else if (count == 32) return 4'b0110;
    else if (count == 64) return 4'b0111;
    else return 4'b0000; // saturate at 64
  endfunction

  function automatic int decode_credits(logic [3:0] field);
    case (field[2:0])
      3'b000: return 0;
      3'b001: return 1;
      3'b010: return 2;
      3'b011: return 4;
      3'b100: return 8;
      3'b101: return 16;
      3'b110: return 32;
      3'b111: return 64;
      default: return 0;
    endcase
  endfunction

  // Determine channel mapping based on DIRECTION
  logic [1:0] tx_map;   // tx_send maps to sender channels
  logic [1:0] pend_map; // pending-return counters map to receive channels

  always_comb begin
    if (DIRECTION == 0) begin
      // Host side (M2S Tx)
      tx_map = tx_send;          // ch0 = Req, ch1 = RwD
      pend_map[0] = buf_free[0]; // S2M NDR
      pend_map[1] = buf_free[1]; // S2M DRS
    end else begin
      // Device side (S2M Tx)
      tx_map = tx_send;          // ch0 = NDR, ch1 = DRS
      pend_map[0] = buf_free[0]; // M2S Req
      pend_map[1] = buf_free[1]; // M2S RwD
    end
  end

  // Sequential logic for counters
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] = 7'b0;
      snd[1] = 7'b0;
      pend[0] = RX_DEPTH;
      pend[1] = RX_DEPTH;
    end else begin
      // Update sender credits based on tx_send and received credits
      for (int i = 0; i < 2; i++) begin
        int add = 0;
        if (rx_crd_valid) begin
          if (DIRECTION == 0) begin
            if (i == 0 && rx_reqcrd[3]) add = decode_credits(rx_reqcrd);
            else if (i == 1 && rx_datacrd[3]) add = decode_credits(rx_datacrd);
          end else begin
            if (i == 0 && rx_rspcrd[3]) add = decode_credits(rx_rspcrd);
            else if (i == 1 && rx_datacrd[3]) add = decode_credits(rx_datacrd);
          end
        end
        // Decrement on tx_send
        if (tx_send[i] && snd[i] > 0) begin
          snd[i] = snd[i] - 1;
        end
        // Increment by add
        if (add > 0) begin
          snd[i] = snd[i] + add;
          if (snd[i] > CREDIT_MAX) snd[i] = CREDIT_MAX;
        end
      end

      // Update pending-return counters based on crd_taken and buf_free
      for (int i = 0; i < 2; i++) begin
        int taken = 0;
        if (crd_taken) begin
          if (DIRECTION == 0) begin
            if (i == 0) taken = decode_credits(crd_rsp_field);
            else if (i == 1) taken = decode_credits(crd_data_field);
          end else begin
            if (i == 0) taken = decode_credits(crd_req_field);
            else if (i == 1) taken = decode_credits(crd_data_field);
          end
        end
        if (taken > 0) begin
          pend[i] = pend[i] - taken;
          if (pend[i] < 0) pend[i] = 0;
        end
        if (pend_map[i] > 0) begin
          pend[i] = pend[i] + 1;
          if (pend[i] > PEND_MAX) pend[i] = PEND_MAX;
        end
      end
    end
  end

  // Combinational outputs for sender credits and can_send
  assign can_send[0] = (snd[0] > 0);
  assign can_send[1] = (snd[1] > 0);
  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];

  // Combinational outputs for pending-return counters and fields
  assign pend_0 = pend[0];
  assign pend_1 = pend[1];
  assign crd_pending = (pend[0] > 0) || (pend[1] > 0);

  // Determine which fields to output based on pending counters (greedy largest-first)
  always_comb begin
    // Default fields
    crd_req_field = 4'b0000;
    crd_data_field = 4'b0000;
    crd_rsp_field = 4'b0000;

    // Greedy decomposition: try to return as many credits as possible in each field
    int remaining[0:1];
    remaining[0] = pend[0];
    remaining[1] = pend[1];

    // For each field, encode the largest representable value <= remaining
    if (DIRECTION == 0) begin
      // ReqCrd corresponds to pending[0] (S2M NDR)
      if (remaining[0] >= 64) begin
        crd_rsp_field = encode_credits(64);
        remaining[0] -= 64;
      end else if (remaining[0] >= 32) begin
        crd_rsp_field = encode_credits(32);
        remaining[0] -= 32;
      end else if (remaining[0] >= 16) begin
        crd_rsp_field = encode_credits(16);
        remaining[0] -= 16;
      end else if (remaining[0] >= 8) begin
        crd_rsp_field = encode_credits(8);
        remaining[0] -= 8;
      end else if (remaining[0] >= 4) begin
        crd_rsp_field = encode_credits(4);
        remaining[0] -= 4;
      end else if (remaining[0] >= 2) begin
        crd_rsp_field = encode_credits(2);
        remaining[0] -= 2;
      end else if (remaining[0] >= 1) begin
        crd_rsp_field = encode_credits(1);
        remaining[0] -= 1;
      end

      // DataCrd corresponds to pending[1] (S2M DRS)
      if (remaining[1] >= 64) begin
        crd_data_field = encode_credits(64);
        remaining[1] -= 64;
      end else if (remaining[1] >= 32) begin
        crd_data_field = encode_credits(32);
        remaining[1] -= 32;
      end else if (remaining[1] >= 16) begin
        crd_data_field = encode_credits(16);
        remaining[1] -= 16;
      end else if (remaining[1] >= 8) begin
        crd_data_field = encode_credits(8);
        remaining[1] -= 8;
      end else if (remaining[1] >= 4) begin
        crd_data_field = encode_credits(4);
        remaining[1] -= 4;
      end else if (remaining[1] >= 2) begin
        crd_data_field = encode_credits(2);
        remaining[1] -= 2;
      end else if (remaining[1] >= 1) begin
        crd_data_field = encode_credits(1);
        remaining[1] -= 1;
      end

      // ReqCrd field is reserved (0) for M2S flits
      crd_req_field = 4'b0000;
    end else begin
      // Device side (S2M Tx)
      // ReqCrd corresponds to pending[0] (M2S Req)
      if (remaining[0] >= 64) begin
        crd_req_field = encode_credits(64);
        remaining[0] -= 64;
      end else if (remaining[0] >= 32) begin
        crd_req_field = encode_credits(32);
        remaining[0] -= 32;
      end else if (remaining[0] >= 16) begin
        crd_req_field = encode_credits(16);
        remaining[0] -= 16;
      end else if (remaining[0] >= 8) begin
        crd_req_field = encode_credits(8);
        remaining[0] -= 8;
      end else if (remaining[0] >= 4) begin
        crd_req_field = encode_credits(4);
        remaining[0] -= 4;
      end else if (remaining[0] >= 2) begin
        crd_req_field = encode_credits(2);
        remaining[0] -= 2;
      end else if (remaining[0] >= 1) begin
        crd_req_field = encode_credits(1);
        remaining[0] -= 1;
      end

      // DataCrd corresponds to pending[1] (M2S RwD)
      if (remaining[1] >= 64) begin
        crd_data_field = encode_credits(64);
        remaining[1] -= 64;
      end else if (remaining[1] >= 32) begin
        crd_data_field = encode_credits(32);
        remaining[1] -= 32;
      end else if (remaining[1] >= 16) begin
        crd_data_field = encode_credits(16);
        remaining[1] -= 16;
      end else if (remaining[1] >= 8) begin
        crd_data_field = encode_credits(8);
        remaining[1] -= 8;
      end else if (remaining[1] >= 4) begin
        crd_data_field = encode_credits(4);
        remaining[1] -= 4;
      end else if (remaining[1] >= 2) begin
        crd_data_field = encode_credits(2);
        remaining[1] -= 2;
      end else if (remaining[1] >= 1) begin
        crd_data_field = encode_credits(1);
        remaining[1] -= 1;
      end

      // RspCrd field is reserved (0) for S2M flits
      crd_rsp_field = 4'b0000;
    end
  end

endmodule
