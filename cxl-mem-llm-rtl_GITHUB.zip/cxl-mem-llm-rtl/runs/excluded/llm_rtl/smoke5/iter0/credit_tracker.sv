module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);
  // State registers
  logic [6:0] snd[0:1];
  logic [7:0] pend[0:1];

  // Helper: decode credit field to count
  function automatic logic [6:0] decode_credit_field(logic [3:0] field);
    logic [2:0] count_bits = field[2:0];
    logic count = 0;
    case (count_bits)
      3'b000: count = 1'b0;
      3'b001: count = 1'b1;
      3'b010: count = 2'b10;
      3'b011: count = 2'b100;
      3'b100: count = 2'b1000;
      3'b101: count = 2'b10000;
      3'b110: count = 2'b100000;
      3'b111: count = 2'b1000000;
    endcase
    return count;
  endfunction

  // Helper: encode count to credit field (CXL.mem select bit = 1)
  function automatic logic [3:0] encode_credit_field(logic [6:0] count);
    logic [2:0] enc;
    if (count == 0) enc = 3'b000;
    else if (count == 1) enc = 3'b001;
    else if (count == 2) enc = 3'b010;
    else if (count == 4) enc = 3'b011;
    else if (count == 8) enc = 3'b100;
    else if (count == 16) enc = 3'b101;
    else if (count == 32) enc = 3'b110;
    else enc = 3'b111; // 64
    return {1'b1, enc};
  endfunction

  // Determine channel mapping based on direction
  logic [1:0] tx_ch_map; // 0 -> Req/NDR, 1 -> RwD/DRS
  logic [1:0] rx_ch_map; // 0 -> NDR/Req, 1 -> DRS/RwD

  always_comb begin
    if (DIRECTION == 0) begin // Host side (M2S)
      tx_ch_map = {tx_send[1], tx_send[0]}; // ch0 = Req, ch1 = RwD
      rx_ch_map = {buf_free[1], buf_free[0]}; // ch0 = NDR, ch1 = DRS
    end else begin // Device side (S2M)
      tx_ch_map = {tx_send[0], tx_send[1]}; // ch0 = NDR, ch1 = DRS
      rx_ch_map = {buf_free[0], buf_free[1]}; // ch0 = Req, ch1 = RwD
    end
  end

  // Combinational credit fields
  logic [3:0] req_field, data_field, rsp_field;
  always_comb begin
    // Default fields
    req_field = 4'b0000;
    data_field = 4'b0000;
    rsp_field = 4'b0000;

    // Determine which pending counters to drain
    // Greedy largest-first: try to drain 64, then 32, etc.
    logic [6:0] drain0 = 7'b0;
    logic [6:0] drain1 = 7'b0;
    if (pend[0] >= 64) drain0 = 7'b1000000;
    else if (pend[0] >= 32) drain0 = 7'b0100000;
    else if (pend[0] >= 16) drain0 = 7'b0010000;
    else if (pend[0] >= 8) drain0 = 7'b0001000;
    else if (pend[0] >= 4) drain0 = 7'b0000100;
    else if (pend[0] >= 2) drain0 = 7'b0000010;
    else if (pend[0] >= 1) drain0 = 7'b0000001;
    if (pend[1] >= 64) drain1 = 7'b1000000;
    else if (pend[1] >= 32) drain1 = 7'b0100000;
    else if (pend[1] >= 16) drain1 = 7'b0010000;
    else if (pend[1] >= 8) drain1 = 7'b0001000;
    else if (pend[1] >= 4) drain1 = 7'b0000100;
    else if (pend[1] >= 2) drain1 = 7'b0000010;
    else if (pend[1] >= 1) drain1 = 7'b0000001;

    // Map to credit fields based on direction
    if (DIRECTION == 0) begin // Host side
      req_field = encode_credit_field(drain0); // ReqCrd
      data_field = encode_credit_field(drain1); // DataCrd
      rsp_field = 4'b0000; // RspCrd reserved
    end else begin // Device side
      req_field = encode_credit_field(drain1); // ReqCrd
      data_field = encode_credit_field(drain0); // DataCrd
      rsp_field = 4'b0000; // RspCrd reserved
    end
  end

  assign crd_req_field = req_field;
  assign crd_data_field = data_field;
  assign crd_rsp_field = rsp_field;
  assign crd_pending = (pend[0] > 0) || (pend[1] > 0);

  // State update
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] <= 7'b0;
      snd[1] <= 7'b0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      // Update sender credits based on tx_send
      if (tx_send[0]) begin
        if (snd[0] > 0) snd[0] <= snd[0] - 1;
        else snd[0] <= 7'b0;
      end
      if (tx_send[1]) begin
        if (snd[1] > 0) snd[1] <= snd[1] - 1;
        else snd[1] <= 7'b0;
      end

      // Update pending credits based on received credits and crd_taken
      if (rx_crd_valid) begin
        // Decode received credits and add to pending counters
        logic [6:0] add0 = 7'b0;
        logic [6:0] add1 = 7'b0;
        if (DIRECTION == 0) begin
          add0 = decode_credit_field(rx_reqcrd); // ReqCrd -> pending ch0 (NDR)
          add1 = decode_credit_field(rx_datacrd); // DataCrd -> pending ch1 (DRS)
        end else begin
          add0 = decode_credit_field(rx_rspcrd); // RspCrd -> pending ch0 (Req)
          add1 = decode_credit_field(rx_datacrd); // DataCrd -> pending ch1 (RwD)
        end
        if (add0 > 0) pend[0] <= pend[0] + add0;
        if (add1 > 0) pend[1] <= pend[1] + add1;
      end

      // Drain pending credits when crd_taken is asserted
      if (crd_taken) begin
        // Determine which fields were sent and subtract
        logic [6:0] sent0 = 7'b0;
        logic [6:0] sent1 = 7'b0;
        if (DIRECTION == 0) begin
          sent0 = decode_credit_field(req_field); // ReqCrd sent -> pending ch0
          sent1 = decode_credit_field(data_field); // DataCrd sent -> pending ch1
        end else begin
          sent0 = decode_credit_field(data_field); // DataCrd sent -> pending ch0
          sent1 = decode_credit_field(req_field); // ReqCrd sent -> pending ch1
        end
        if (sent0 > 0) pend[0] <= pend[0] - sent0;
        if (sent1 > 0) pend[1] <= pend[1] - sent1;
      end

      // Update pending credits based on buf_free
      if (buf_free[0]) begin
        if (pend[0] < PEND_MAX) pend[0] <= pend[0] + 1;
        else pend[0] <= PEND_MAX;
      end
      if (buf_free[1]) begin
        if (pend[1] < PEND_MAX) pend[1] <= pend[1] + 1;
        else pend[1] <= PEND_MAX;
      end
    end
  end

  // Outputs
  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];
  assign can_send = {snd[1] != 0, snd[0] != 0};
  assign pend_0 = pend[0];
  assign pend_1 = pend[1];

endmodule
