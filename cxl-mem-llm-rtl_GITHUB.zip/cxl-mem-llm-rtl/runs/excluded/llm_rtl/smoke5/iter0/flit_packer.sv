module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);
  // State registers
  logic [2:0]   rem;                // remaining chunks to send
  logic         llcrd_latch;         // latched force_llcrd
  logic [527:0] flit_reg;            // registered flit output
  logic         flit_valid_reg;      // registered flit_valid
  logic         flit_is_control_reg;
  logic         flit_is_alldata_reg;
  logic [3:0]   crd_taken_reg;       // registered crd_taken

  // Combinational signals
  logic         slot_free;
  logic         llcrd_eff;
  logic         msg_ready_comb;
  logic [527:0] flit_comb;
  logic         flit_is_control_comb;
  logic         flit_is_alldata_comb;
  logic [3:0]   crd_taken_comb;

  // Helper functions
  function automatic logic [127:0] get_slot0_data(int dir, int kind, int opcode, logic [51:0] addr,
                                                    logic [15:0] tag, logic poison, logic [63:0] byte_en);
    logic [127:0] data = {128{1'b0}};
    if (dir == 0) begin // M2S
      if (kind == 0) begin // Req (H5)
        data[32] = 1'b1; // Valid
        data[36:33] = opcode; // MemOpcode
        data[39:37] = 3'b0; // SnpType
        data[41:40] = 2'b11; // MetaField
        data[43:42] = 2'b00; // MetaValue
        data[59:44] = tag;
        data[106:60] = addr[51:5];
        data[108:107] = 2'b0; // TC
        data[112:109] = 4'b0; // LD-ID
        // RSVD [118:113] = 0 (already zero)
      end else begin // RwD (H4)
        data[32] = 1'b1; // Valid
        data[36:33] = opcode; // MemOpcode
        data[39:37] = 3'b0; // SnpType
        data[41:40] = 2'b11; // MetaField
        data[43:42] = 2'b00; // MetaValue
        data[59:44] = tag;
        data[105:60] = addr[51:6];
        data[106] = poison;
        data[108:107] = 2'b0; // TC
        data[112:109] = 4'b0; // LD-ID
        // RSVD [118:113] = 0
      end
    end else begin // S2M
      if (kind == 0) begin // NDR (second message in H3)
        data[72] = 1'b1; // Valid
        data[75:73] = opcode[2:0]; // Opcode
        data[77:76] = 2'b11; // MetaField
        data[79:78] = 2'b00; // MetaValue
        data[95:80] = tag;
        data[99:96] = 4'b0; // LD-ID
        data[101:100] = 2'b0; // DevLoad
        // RSVD [127:102] = 0
      end else begin // DRS (first message in H3)
        data[32] = 1'b1; // Valid
        data[35:33] = opcode[2:0]; // Opcode
        data[37:36] = 2'b11; // MetaField
        data[39:38] = 2'b00; // MetaValue
        data[55:40] = tag;
        data[56] = poison;
        data[60:57] = 4'b0; // LD-ID
        data[62:61] = 2'b0; // DevLoad
        // RSVD [71:63] = 0
      end
    end
    return data;
  endfunction

  function automatic logic [127:0] get_be_chunk(logic [63:0] byte_en);
    logic [127:0] be = {64{1'b0}};
    be[31:0] = byte_en;
    be[63:32] = byte_en;
    // bytes 8–15 RSVD = 0
    return be;
  endfunction

  function automatic logic [127:0] get_data_chunk(logic [127:0] chunk);
    return chunk;
  endfunction

  // Determine chunk list based on message type and overrides
  logic [127:0] chunk_list[0:7];
  logic [2:0]   chunk_count;
  always_comb begin
    if (chunks_ovr_en) begin
      chunk_count = chunks_ovr;
      for (int i = 0; i < 8; i++) begin
        chunk_list[i] = (i < chunk_count) ? msg_data[128*i +: 128] : {128{1'b0}};
      end
    end else begin
      if (DIRECTION == 0) begin // M2S
        if (msg_kind == 0) begin // Req: no data chunks
          chunk_count = 3'b0;
          chunk_list[0] = chunk_list[1] = chunk_list[2] = chunk_list[3] = chunk_list[4] = chunk_list[5] = chunk_list[6] = chunk_list[7] = {128{1'b0}};
        end else begin // RwD
          if (msg_opcode == 4'b0010) begin // MemWrPtl
            chunk_count = 3'b5;
            chunk_list[0] = msg_data[127:0];
            chunk_list[1] = msg_data[255:128];
            chunk_list[2] = msg_data[383:256];
            chunk_list[3] = msg_data[511:384];
            chunk_list[4] = get_be_chunk(msg_byte_en);
            chunk_list[5] = chunk_list[6] = chunk_list[7] = {128{1'b0}};
          end else begin // MemWr
            chunk_count = 3'b4;
            chunk_list[0] = msg_data[127:0];
            chunk_list[1] = msg_data[255:128];
            chunk_list[2] = msg_data[383:256];
            chunk_list[3] = msg_data[511:384];
            chunk_list[4] = chunk_list[5] = chunk_list[6] = chunk_list[7] = {128{1'b0}};
          end
        end
      end else begin // S2M
        if (msg_kind == 0) begin // NDR: no data chunks
          chunk_count = 3'b0;
          chunk_list[0] = chunk_list[1] = chunk_list[2] = chunk_list[3] = chunk_list[4] = chunk_list[5] = chunk_list[6] = chunk_list[7] = {128{1'b0}};
        end else begin // DRS
          chunk_count = 3'b4;
          chunk_list[0] = msg_data[127:0];
          chunk_list[1] = msg_data[255:128];
          chunk_list[2] = msg_data[383:256];
          chunk_list[3] = msg_data[511:384];
          chunk_list[4] = chunk_list[5] = chunk_list[6] = chunk_list[7] = {128{1'b0}};
        end
      end
    end
  end

  // Slot format selectors
  logic [2:0] slot0_fmt, slot1_fmt, slot2_fmt, slot3_fmt;
  always_comb begin
    // Slot0 format depends on direction and message kind
    if (DIRECTION == 0) begin // M2S
      if (msg_kind == 0) slot0_fmt = 3'b101; // H5 (Req)
      else slot0_fmt = 3'b100; // H4 (RwD)
    end else begin // S2M
      slot0_fmt = 3'b011; // H3 (DRS/NDR)
    end
    // Slots 1-3: G0 for data chunks, otherwise empty slot format (G4/G5 for M2S, G5 for S2M)
    if (DIRECTION == 0) begin
      slot1_fmt = slot2_fmt = slot3_fmt = 3'b000; // G0
    end else begin
      slot1_fmt = slot2_fmt = slot3_fmt = 3'b000; // G0
    end
  end

  // Header construction
  logic [31:0] header;
  logic [127:0] slot0_msg;
  always_comb begin
    // Default header fields
    header = {1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 3'b0, 3'b0, 3'b0, 3'b0, 3'b0, 4'b0, 4'b0, 4'b0};
    // Fill header fields based on credit fields
    header[31:28] = crd_req_field;
    header[27:24] = crd_data_field;
    header[23:20] = crd_rsp_field;
    // Type = 0 (protocol), RV = 0, Ak = 0 (tied), BE = 0 (no BE chunk), Sz = 1 for data messages, else 0
    if (DIRECTION == 0) begin // M2S
      if (msg_kind == 1 && msg_opcode == 4'b0010) begin // MemWrPtl
        header[4] = 1'b1; // BE = 1
        header[0] = 1'b0; // Type = 0
        header[2] = 1'b0; // Ak = 0
        header[3] = 1'b0; // Sz = 0 (no data message in this flit)
      end else if (msg_kind == 1) begin // MemWr
        header[0] = 1'b0; // Type = 0
        header[2] = 1'b0; // Ak = 0
        header[3] = 1'b0; // Sz = 0
      end else begin // Req
        header[0] = 1'b0; // Type = 0
        header[2] = 1'b0; // Ak = 0
        header[3] = 1'b0; // Sz = 0
      end
    end else begin // S2M
      if (msg_kind == 1) begin // DRS
        header[4] = 1'b1; // Sz = 1
        header[0] = 1'b0; // Type = 0
        header[2] = 1'b0; // Ak = 0
        header[3] = 1'b0; // BE = 0
      end else begin // NDR
        header[4] = 1'b1; // Sz = 1
        header[0] = 1'b0; // Type = 0
        header[2] = 1'b0; // Ak = 0
        header[3] = 1'b0; // BE = 0
      end
    end
    // Slot format fields
    header[7:5] = slot0_fmt;
    header[10:8] = slot1_fmt;
    header[13:11] = slot2_fmt;
    header[16:14] = slot3_fmt;
    // RSVD [19:17] = 0 (already zero)
  end

  // Slot0 message selection
  always_comb begin
    slot0_msg = {128{1'b0}};
    if (DIRECTION == 0) begin // M2S
      if (msg_kind == 0) begin // Req
        slot0_msg = get_slot0_data(DIRECTION, msg_kind, msg_opcode, msg_addr, msg_tag, 1'b0, msg_byte_en);
      end else begin // RwD
        slot0_msg = get_slot0_data(DIRECTION, msg_kind, msg_opcode, msg_addr, msg_tag, msg_poison, msg_byte_en);
      end
    end else begin // S2M
      if (msg_kind == 0) begin // NDR
        slot0_msg = get_slot0_data(DIRECTION, msg_kind, msg_opcode, msg_addr, msg_tag, 1'b0, msg_byte_en);
      end else begin // DRS
        slot0_msg = get_slot0_data(DIRECTION, msg_kind, msg_opcode, msg_addr, msg_tag, msg_poison, msg_byte_en);
      end
    end
  end

  // Determine flit type and content
  always_comb begin
    // Default outputs
    flit_comb = {528{1'b0}};
    flit_is_control_comb = 1'b0;
    flit_is_alldata_comb = 1'b0;
    crd_taken_comb = 4'b0000;
    msg_ready_comb = 1'b0;

    // Check if we have a rollover in progress
    if (rem > 0) begin
      // Rollover flit
      if (rem > 3) begin
        // All-data flit
        flit_is_alldata_comb = 1'b1;
        // Fill slots 0-3 with next 4 chunks
        flit_comb[127:0] = get_data_chunk(chunk_list[0]);
        flit_comb[255:128] = get_data_chunk(chunk_list[1]);
        flit_comb[383:256] = get_data_chunk(chunk_list[2]);
        flit_comb[511:384] = get_data_chunk(chunk_list[3]);
        // CRC = 0 (already zero)
        // No header, no credits
        // Update rem
        rem = rem - 4;
        // crd_taken = 0 for all-data flit
        crd_taken_comb = 4'b0000;
        // msg_ready = 0 (cannot start new message during rollover)
        msg_ready_comb = 1'b0;
      end else begin
        // Protocol flit with rem chunks in slots 1..rem
        flit_is_control_comb = 1'b0;
        flit_is_alldata_comb = 1'b0;
        // Fill header
        flit_comb[31:0] = header;
        // Fill slot0 message (may be empty)
        flit_comb[159:128] = slot0_msg; // Slot0 bytes 4-7 (bits 128-159)
        // Fill slots 1..rem with chunks
        for (int i = 1; i <= rem; i++) begin
          flit_comb[128*i +: 128] = get_data_chunk(chunk_list[i-1]);
        end
        // Fill remaining slots (if any) with empty G0
        for (int i = rem+1; i <= 3; i++) begin
          flit_comb[128*i +: 128] = {128{1'b0}};
        end
        // CRC = 0
        // crd_taken = 1 for protocol flit
        crd_taken_comb = 4'b1111; // All credits are present (value doesn't matter)
        // msg_ready = 0 (cannot start new message during rollover)
        msg_ready_comb = 1'b0;
        // Update rem
        rem = 0;
      end
    end else begin
      // No rollover
      if (llcrd_eff) begin
        // LLCRD flit
        flit_is_control_comb = 1'b1;
        flit_is_alldata_comb = 1'b0;
        // LLCRD layout per spec
        flit_comb[0] = 1'b1; // Type = 1
        // RV = 0, Ak = 0, RSVD[4:3] = 0, CTL_FMT = 3'b000
        flit_comb[7:5] = 3'b000;
        // RSVD[15:8] = 0, RSVD[19:16] = 0
        flit_comb[31:20] = {4{crd_req_field}, 4{crd_data_field}, 4{crd_rsp_field}}; // Credits
        flit_comb[35:32] = 4'b0000; // LLCTRL = 0000
        flit_comb[39:36] = 4'b0000; // SubType = 0000
        // bytes 5-7 = 0 (already zero)
        // Payload[63:0] = 0 (already zero)
        // Slots 1-3 = 0 (already zero)
        // CRC = 0
        // crd_taken = 1 for LLCRD
        crd_taken_comb = 4'b1111;
        // msg_ready = 0 (LLCRD takes priority)
        msg_ready_comb = 1'b0;
        // Clear latch
        llcrd_latch = 1'b0;
      end else if (msg_valid && slot_free) begin
        // New message flit
        flit_is_control_comb = 1'b0;
        flit_is_alldata_comb = 1'b0;
        // Fill header
        flit_comb[31:0] = header;
        // Fill slot0 message
        flit_comb[159:128] = slot0_msg;
        // Fill slots 1-3 with first chunks of message (if any)
        // For M2S Req/RwD and S2M NDR/DRS, there are no data chunks in this flit
        // For MemWrPtl, there are 4 data chunks in this flit
        if (DIRECTION == 0 && msg_kind == 1 && msg_opcode == 4'b0010) begin // MemWrPtl
          flit_comb[128:0] = get_data_chunk(chunk_list[0]);
          flit_comb[255:128] = get_data_chunk(chunk_list[1]);
          flit_comb[383:256] = get_data_chunk(chunk_list[2]);
          flit_comb[511:384] = get_data_chunk(chunk_list[3]);
        end else begin
          // No data chunks in this flit
          flit_comb[128:0] = {128{1'b0}};
          flit_comb[255:128] = {128{1'b0}};
          flit_comb[383:256] = {128{1'b0}};
          flit_comb[511:384] = {128{1'b0}};
        end
        // CRC = 0
        // crd_taken = 1 for protocol flit
        crd_taken_comb = 4'b1111;
        // msg_ready = 1 (message accepted)
        msg_ready_comb = 1'b1;
        // Update rem based on total chunks
        rem = chunk_count;
        // If rem > 3, next flit will be all-data
        if (rem > 3) begin
          rem = rem - 4; // First flit consumed 4 chunks
        end else if (rem > 0) begin
          rem = rem - 1; // First flit consumed 1 chunk (slot1)
        end else begin
          rem = 0;
        end
      end else begin
        // No flit to send
        flit_comb = {528{1'b0}};
        flit_is_control_comb = 1'b0;
        flit_is_alldata_comb = 1'b0;
        crd_taken_comb = 4'b0000;
        msg_ready_comb = 1'b0;
      end
    end
  end

  // Register updates
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid_reg <= 1'b0;
      flit_reg <= {528{1'b0}};
      flit_is_control_reg <= 1'b0;
      flit_is_alldata_reg <= 1'b0;
      crd_taken_reg <= 4'b0000;
      rem <= 3'b0;
      llcrd_latch <= 1'b0;
    end else begin
      // Update latch
      llcrd_latch <= force_llcrd;
      // Update flit output
      if (slot_free) begin
        flit_valid_reg <= 1'b1;
        flit_reg <= flit_comb;
        flit_is_control_reg <= flit_is_control_comb;
        flit_is_alldata_reg <= flit_is_alldata_comb;
        crd_taken_reg <= crd_taken_comb;
      end else begin
        flit_valid_reg <= 1'b0;
        // Keep previous flit
      end
    end
  end

  // Outputs
  assign msg_ready = msg_ready_comb;
  assign flit_valid = flit_valid_reg;
  assign flit_out = flit_reg;
  assign flit_is_control = flit_is_control_reg;
  assign flit_is_alldata = flit_is_alldata_reg;
  assign crd_taken = crd_taken_reg;

  // Helper: slot_free condition
  assign slot_free = !flit_valid_reg || flit_ready;
  assign llcrd_eff = llcrd_latch || force_llcrd;

endmodule
