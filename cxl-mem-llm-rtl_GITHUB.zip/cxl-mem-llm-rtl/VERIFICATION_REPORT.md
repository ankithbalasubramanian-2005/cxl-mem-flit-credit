# Verification report — 22 November 2026

Release reruns used the copied sources on Linux, cocotb 2.1.0, Python 3.12.14, pytest 9.2.0, Icarus Verilog 13.0 and YoWASP Yosys 0.71.0.0.post1285. Python 3.12.3 / Icarus 12.0 is the requested target. The archived replay used Python 3.12.12 / Icarus 13.0. The target version pair remains unverified.

From the repository root, define `R() { bash verification/reproduce.sh "$1" "reproduction-output/$1"; }`. The wrapper requires an unused output directory. The release copy of each fresh outcome is under release_checks/.

| Check and command | Expected | Measured in the release rerun | Status |
|---|---|---|---|
| a. `cd judge && make model-tests` | Model unit tests pass | Make reported “No rule to make target 'model-tests'.” Makefile and tests/model are missing. | BLOCKED |
| a. `cd judge && make test RTL=../reference_rtl` | 62 tests pass | Make reported “No rule to make target 'test'.” Original runner is missing. | BLOCKED |
| a. `cd judge && make mutants` | 16/16 killed | Make reported “No rule to make target 'mutants'.” Original mutants and generator are missing. | BLOCKED |
| a. Supplemental reference replay, `R corner` | 62 tests for seed 1234 | Copied Python driver ran the supplied reference with the uploaded tests. 21 packer + 10 tracker tests in each direction passed. All ten seeds passed (620 executions). | PASS, alternate driver |
| b. `R frozen` | 160 passing groups, 2,480 executions | 160 unique tag/module/direction/seed groups passed. Checked per-group JUnit XML, with 620 test cases per tag, zero failures, errors or skips. | PASS |
| c. `R assertions` | 24 passes, 10 assertion failures, two timeouts and six detected mutants | Exact counts. Both timed-out jobs were S3 R2 packers. Each of the six separately injected mutants triggered a monitor. | PASS |
| d. `R corner` | Original S2 R2=191, repaired copy and model=192 | At the sampled cycle, both original direction logs show expected 0xc0 and actual 0xbf on both pending channels. Both repaired direction tests passed the same golden-model check. | PASS |
| e. `R synthesis` | 27 passes, five structural errors, two frontend errors, two runtime failures | Exact counts across 36 original configurations. The four reference and four repair configurations passed. All 44 statuses and available cells, FFs, latches and depth matched archived records. All 16 rows of comparison.csv matched the fresh hardware counts and depths. | PASS |
| f. `R paper` | PDF builds | Both pdflatex passes succeeded using the supplied class and four PDF figures. pdfinfo reported eight pages. | PASS |
| `R figures` | Four regenerated paper figures | The plotting script completed. The wrapper remaps its hard-coded evidence root in a temporary copy. | PASS |
| `PYTHONPATH=improvements/feedback_loop python -m pytest -q improvements/feedback_loop/test_enhanced_loop.py` | Six offline guard tests pass | Six passed. The failure-injection callback was local. | PASS |

The original three make targets were attempted separately. Their console output is in release_checks/judge/. The additional reference replay uses the same reference bytes as reference_rtl/ and has a separate evidence trail. No live model requests were made.

## Traceability and release checks

2,452 copied input paths were compared by SHA-256 with their workspace sources. Of those paths, 1,539 also had independently recorded content hashes in the input evidence package manifest. All 18 selected modules matched their archived source iteration. Each initial strategy prompt matched the first archived prompt for each of its three official runs. SOURCE_COPIES.json records the mapping. The source tag name is documented, but its original commit ID is unavailable.

The final secret checks used Gitleaks 8.24.3 against the release directory and fresh Git history, plus the requested full-tree grep. Gitleaks reported no leaks. Grep matched configuration identifiers, the empty example variable, an environment lookup, authorization header construction, and project documentation. Review the exact scan transcript distributed alongside the repository in the ZIP. The grep's exit code 0 means there were keyword matches. No credential redaction was needed. The ZIP contains only the new history.
