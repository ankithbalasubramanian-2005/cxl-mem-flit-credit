# LLM-Assisted Design and Verification of a CXL.mem Link-Layer Subsystem

ECE416, SASTRA Deemed to be University. Ankith, Jaigan S, and Uday Balaji.

We evaluated nine LLM-generated implementations of a simplified CXL.mem flit packer and credit tracker. Four passed the original simulation judge. Adding assertions reduced the accepted set to three, and synthesis reduced it to two. A directed test exposed an off-by-one credit error in a design that passed ten simulation seeds. The archive preserves that design alongside its corrected copy and the supplied reference RTL so readers can compare behavior, cell count, and logic depth.

The supplied paper is [report.pdf](docs/paper/report.pdf). Its title is *Verification-Guided Evaluation of LLM-Generated CXL.mem Link-Layer RTL*. The design uses [CXL Specification 2.0](https://computeexpresslink.org/wp-content/uploads/2024/02/CXL-2.0-Specification.pdf).

## Repository map

| Directory | Contents |
|---|---|
| docs/ | Project specification, interface contract, TeX manuscript, figures and compiled paper |
| judge/ | Uploaded cocotb tests, Python golden models, harness and source hashes |
| reference_rtl/ | Two supplied reference modules used as the comparison baseline |
| orchestrator/, prompts/ | Original generation loop and prompt builder, restored inputs, archived initial prompts |
| runs/ | Per-iteration prompts, replies and emitted RTL, tagged JSON histories, token counts, model times and summary tables. Shared console logs are in results/. Pilots and superseded experiments are in excluded/. |
| selected_rtl/ | 18 selected modules, iteration IDs and SHA-256 hashes |
| verification/ | Frozen-suite replay driver, monitors, six assertion mutants, archived assertion, replay and corner-test results |
| synthesis/ | Common tool driver, shell checks, original measured logs and scripts under TAG/MODULE/DIRECTION, summary and diagnostic reruns |
| improvements/ | repair_study and baseline each include RTL, checks and synthesis. feedback_loop contains fixtures, gate results and unit tests. |
| figures/ | Paper plotting script and PDF/PNG figures |
| original_project/, synthesis_bundle/ | Compatibility copies for unmodified experiment drivers |
| release_checks/ | Fresh offline verification transcripts, XML and summaries. See VERIFICATION_REPORT.md. |

## Quick start

From the extracted repository root on Linux or WSL, verify the distribution with `sha256sum -c MANIFEST.sha256`. Inspect `docs/paper/report.pdf` and `release_checks/` immediately, without a simulator or an API key. Use a fresh output directory for each rerun.

```sh
python3.12 -m venv venv
. venv/bin/activate
python -m pip install -r requirements.txt
python -m pip install matplotlib==3.10.8 numpy==2.3.5  # figures only
bash verification/reproduce.sh assertions reproduction-output/assertions
```

The requested target is Python 3.12.3 with Icarus Verilog 12.0 on PATH. requirements.txt pins cocotb 2.1.0, pytest 9.2.0 and yowasp-yosys 0.71.0.0.post1285. The fresh rerun used Python 3.12.14 and Icarus 13.0. The earlier evidence replay recorded Python 3.12.12 and Icarus 13.0. The synthesis driver uses Linux ps and the built-in slang frontend. Install a TeX distribution with IEEEtran dependencies and pdfinfo for the paper. jq is used in the inspection commands below.

## Reproduce the paper

Commands below run at the repository root. In the table, **R(action)** means the literal shell function below. It creates new outputs outside the recorded evidence.

```sh
R() { bash verification/reproduce.sh "$1" "reproduction-output/$1"; }
```

| Paper item | Reproduction or inspection command | Exact input or result |
|---|---|---|
| Table I, nine runs, convergence 1/3, 2/3, 1/3, attempts, time and scores | `cat runs/results/official_runs.csv runs/results/summary.md`; `jq '.[] | [.iteration,.scores,.llm_seconds,.stage]' runs/s2_final_run1/s2_final_run1.json` (substitute any official tag) | runs/TAG/TAG.json and runs/results/official_runs.csv. Elapsed minutes are summed llm_seconds / 60. A packer score of 30 for S3 R2 denotes timeout. |
| Fig. 1, prompt, judge and repair flow | `R figures`; `cat orchestrator/run_loop.py` | figures/assets/workflow.pdf and orchestrator/run_loop.py |
| Fig. 2, original acceptance 4 → 3 → 2 of 9 | `R figures`; `cat improvements/acceptance_stages.csv improvements/per_design_acceptance.csv` | figures/assets/outcomes.pdf. The plotting script encodes the reported bar heights. The CSVs give the supporting counts. |
| 18 selected module digests | `python -c 'import json,hashlib,pathlib; p=pathlib.Path("selected_rtl"); s=json.loads((p/"selection.json").read_text()); assert len(s)==18 and all(hashlib.sha256((p/x["rtl"]).read_bytes()).hexdigest()==x["sha256"] for x in s)'` | selected_rtl/selection.json and runs/results/provenance_audit.json |
| Four converged designs, ten seeds, 160 groups, 2,480 tests | `R frozen`; `jq '[length, (map(.tests) | add)]' reproduction-output/frozen/results/summary.json` | release_checks/frozen/results/summary.json, plus per-seed JUnit XML |
| 24 assertion passes, 10 failures, two timeouts and six detected mutants | `R assertions`; `jq 'group_by([.mutant,.status]) | map([.[0].mutant,.[0].status,length])' reproduction-output/assertions/results/summary.json` | verification/assertion_results/summary.csv and mutants/ alongside it |
| Table II, 36 syntheses, 27 passes and nine failures | `R synthesis`; `cat reproduction-output/synthesis/results/inputs/summary.csv` | synthesis/summary.csv. Each configuration has input.sv, synth.ys and yosys.log. Successful ones also have stat.json and ltp.txt. |
| Fig. 3, old=255, drain=64, free=1, original=191, repaired=192 | `R corner`; `R figures`; `cat improvements/repair_study/waveforms/D0/sim.log` | figures/assets/credit_waveform.pdf, improvements/repair_study/waveforms/D0/credit_repair.vcd, release_checks/corner/original/s2_final_run2/D0/sim.log, release_checks/corner/repaired/corner/D0/results.xml |
| Tables III and IV, both directions, cells, FF and depth | `R synthesis` (once for all synthesis tables); `cat improvements/baseline/comparison.csv` | synthesis/summary.csv and improvements/{baseline,repair_study}/synthesis/summary.csv under their respective directories |
| Fig. 4 and the S2 R1 packer reductions of 12.13% / 4.16%, longer paths, tracker tradeoff and repaired-copy cost | `R figures`; `jq '.[] | select(.design=="S2 run 1")' improvements/baseline/comparison.json` | figures/assets/baseline_tradeoff.pdf and improvements/baseline/comparison.csv. Delta = 100 × (candidate − reference)/reference. |
| Baseline and repaired copy, each 620 tests, four assertion groups, two directed checks and four syntheses | `R corner` and `R synthesis` | release_checks/corner/{reference,repaired}/summary.csv and release_checks/synthesis/results/{baseline,repair_study}/summary.csv |
| Optional stronger loop, two accepting offline replays, one blocked by missing compiler, six unit tests | `jq '.status' improvements/feedback_loop/replays/*/summary.json`; `PYTHONPATH=improvements/feedback_loop python -m pytest -q improvements/feedback_loop/test_enhanced_loop.py` | improvements/feedback_loop/replays/*/summary.json and release_checks/feedback.log. Replay invocation is in improvements/feedback_loop/README.md. |
| Table V, comparison with published work | `sed -n '/Qualitative comparison of evaluation emphasis/,/end{table/p' docs/paper/report.tex`; `cat docs/paper/references.bib` | docs/paper/report.tex and bibliography. This qualitative comparison is based on cited papers. |
| Compiled paper and all four figures | `R paper`; `R figures` | reproduction-output/paper/report.pdf and reproduction-output/figures/assets/ |

Original judge commands, missing prerequisites, expected outputs, actual outputs and tool differences are recorded in VERIFICATION_REPORT.md. The complete original mutation suite and frozen-tag commit are unavailable. MISSING.md lists each known gap. No individual VCD or netlist requires compression to meet the 25 MB limit.

## Live generation with your own key

The historical run used the hosted OpenRouter alias nvidia/nemotron-3-ultra-550b-a55b:free, temperature 0.2, a 60,000-token output limit, first-attempt reasoning disabled and low reasoning for repairs. The judge used seed 1234, 180 seconds per block and at most 15 iterations. DIRECTION=0 selects host/M2S and DIRECTION=1 device/S2M.

**Restore the original judge scripts and their support files before attempting live reproduction.** orchestrator/judge.py calls scripts/run_tests.py from the working directory. The original runner is missing. After restoring it, use a disposable working copy, put judge/tb at tb/, and install the original client's dependencies. Use a new tag.

```sh
cp -r judge/tb tb
python -m pip install openai httpx python-dotenv
cp .env.example .env    # enter your own key locally
export LLM_MODEL='nvidia/nemotron-3-ultra-550b-a55b:free'
python -m orchestrator.run_loop --strategy 2 --tag reproduction_s2 --seed 1234 --max-iter 15
```

The hosted alias, availability and model-serving implementation can change. The archived responses give the exact bytes used in the paper. A fresh hosted run may emit different RTL. Keep reference_rtl/ out of all prompts.

## Citation and reuse

Cite Ankith, Jaigan S, and Uday Balaji, *LLM-Assisted Design and Verification of a CXL.mem Link-Layer Subsystem*, ECE416, SASTRA Deemed to be University, 2026. Include the repository URL and release commit you used. See CITATION.cff, LICENSE and THIRD_PARTY.md. CODE_AND_DATA_AVAILABILITY.md contains the paper's availability paragraph with a URL placeholder.
