from pathlib import Path
import json,sys,bisect
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,FancyArrowPatch
import numpy as np
R=Path(__file__).resolve().parent;B=Path('/workspace/work/submission');A=R/'assets'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':8,'axes.titlesize':9,'axes.spines.top':False,'axes.spines.right':False,'legend.fontsize':7})
# Compact methodology diagram.
fig,ax=plt.subplots(figsize=(3.5,3.0));ax.axis('off');ax.set_xlim(0,4);ax.set_ylim(0,5)
labels=['Shared specification + strategy extra','LLM response: two RTL modules','Syntax / interface checks','Frozen simulation judge','Repair feedback / stop on pass']
for i,label in enumerate(labels):
 y=4.25-i*.87;ax.add_patch(FancyBboxPatch((.45,y),3.25,.48,boxstyle='round,pad=.04',facecolor='#f1f4f6',edgecolor='#29495d',linewidth=.8));ax.text(2.075,y+.24,label,ha='center',va='center',fontsize=7)
 if i<4:ax.add_patch(FancyArrowPatch((2.075,y-.03),(2.075,y-.35),arrowstyle='-|>',mutation_scale=8,color='#29495d'))
ax.annotate('',xy=(.42,3.62),xytext=(.42,.99),arrowprops={'arrowstyle':'->','connectionstyle':'bar,fraction=-.12','color':'#9c632d'});ax.text(.05,2.35,'repair',rotation=90,ha='center',va='center',fontsize=7)
fig.tight_layout(pad=.2)
for ext in ['pdf','png']:fig.savefig(A/f'workflow.{ext}',dpi=300)
plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(3.5,3.3));axs[0].bar(['S1','S2','S3'],[1,2,1],color=['#556d85','#16776c','#a37043'],width=.5);axs[0].set_ylim(0,3);axs[0].set_yticks([0,1,2,3]);axs[0].set_ylabel('Converged / 3');axs[0].set_title('(a) Original prompting runs',loc='left')
axs[1].bar(['Judge','+ assertions','+ synthesis'],[4,3,2],color=['#556d85','#16776c','#29495d'],width=.5);axs[1].set_ylim(0,5);axs[1].set_yticks([0,1,2,3,4]);axs[1].set_ylabel('Accepted / 9');axs[1].set_title('(b) Cumulative post-experiment gates',loc='left')
for ax,vals in zip(axs,[[1,2,1],[4,3,2]]):
 for i,n in enumerate(vals):ax.text(i,n+.08,str(n),ha='center',fontsize=8)
 ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
fig.tight_layout(pad=.6)
for ext in ['pdf','png']:fig.savefig(A/f'outcomes.{ext}',dpi=300)
plt.close(fig)
# Read actual recorded VCD signal values for the paper's credit corner-case plot.
sys.path.insert(0,str(B/'improvements/repair_study'));from make_waveforms import parse_vcd
tr=parse_vcd(B/'improvements/repair_study/waveforms/D0/credit_repair.vcd');t=np.arange(2390,2420.1,.1)
def sample(name):
 changes=tr[name];times=[x[0] for x in changes];return np.array([changes[bisect.bisect_right(times,x)-1][1] for x in t],dtype=float)
fig,axs=plt.subplots(2,1,figsize=(3.5,2.75),sharex=True,gridspec_kw={'height_ratios':[1,1.15]})
for n,(name,label) in enumerate([('clk','clk'),('buf_free','free[0]'),('crd_taken','taken')]):
 val=sample(name);val=val%2 if name=='buf_free' else val;axs[0].step(t,val*.7+(2-n),where='post',linewidth=1,color='#29495d');axs[0].text(2389.3,2-n+.35,label,ha='right',va='center',fontsize=7)
axs[0].set_yticks([]);axs[0].set_ylim(-.2,3);axs[0].set_title('Simultaneous credit return and buffer release',loc='left',fontsize=8)
axs[1].step(t,sample('before_pend_0'),where='post',label='Original',color='#a64c3d',linewidth=1.2);axs[1].step(t,sample('after_pend_0'),where='post',label='Repaired',color='#16776c',linewidth=1.2);axs[1].set_ylim(190.5,192.8);axs[1].set_yticks([191,192]);axs[1].set_ylabel('Pending (zoom)');axs[1].set_xlabel('Simulation time (ns)');axs[1].legend(loc='lower left',ncol=2,frameon=False);axs[1].text(2390.5,192.4,'Before edge: 255',fontsize=7);axs[1].text(2407,192.2,'Expected = 192',fontsize=7,color='#16776c')
for ax in axs:ax.axvline(2405,color='#9c632d',linestyle='--',linewidth=.7);ax.set_xlim(2390,2420);ax.grid(axis='x',alpha=.15)
fig.tight_layout(pad=.45)
for ext in ['pdf','png']:fig.savefig(A/f'credit_waveform.{ext}',dpi=300)
plt.close(fig)
# Baseline / strongest original generated candidate / repaired-copy tradeoff.
records=json.loads((B/'improvements/baseline/comparison.json').read_text());labels=['User reference','S2 run 1','S2 run 2 repaired'];colors=['#29495d','#16776c','#a37043'];fig,axs=plt.subplots(2,1,figsize=(3.5,3.4),sharex=True)
for i,(label,color) in enumerate(zip(labels,colors)):
 rows=[x for x in records if x['design']==label and x['module']=='flit_packer'];x=np.array([0,1])+(i-1)*.23
 axs[0].bar(x,[r['cells'] for r in rows],width=.22,label=label,color=color);axs[1].bar(x,[r['logic_depth'] for r in rows],width=.22,color=color)
axs[0].set_ylabel('Generic cells');axs[1].set_ylabel('Logic depth');axs[1].set_xticks([0,1],['D0','D1']);axs[0].legend(frameon=False,fontsize=6.5,loc='upper left',ncol=1);axs[0].set_ylim(0,17500)
for ax in axs:ax.grid(axis='y',alpha=.15);ax.set_axisbelow(True)
fig.tight_layout(pad=.5)
for ext in ['pdf','png']:fig.savefig(A/f'baseline_tradeoff.{ext}',dpi=300)
plt.close(fig)
print('Four original publication-sized figures created from project data.')
