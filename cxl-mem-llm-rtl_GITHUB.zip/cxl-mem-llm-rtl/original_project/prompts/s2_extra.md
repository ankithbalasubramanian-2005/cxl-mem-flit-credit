# IMPLEMENTATION GUIDE (state-machine view of section 8.12)

## flit_packer
Registers: flit_valid, flit_out, flit_is_control, flit_is_alldata (the output
register); rem[3:0] (data chunks still to send); lat (latched force_llcrd); and a
copy of the in-progress message's chunk list, because msg_data is only valid in
the handshake cycle.

Combinational logic, every cycle:
  slot_free = !flit_valid || flit_ready
  llcrd_eff = lat || force_llcrd
  msg_ready = rst_n && slot_free && (rem == 0) && !llcrd_eff
  When rst_n && slot_free, choose the next flit. First match wins:
    A. rem > 0    -> rollover flit.
                     rem > 3: all-data flit with the next 4 chunks, no header,
                              flit_is_alldata=1, rem = rem - 4.
                     rem <= 3: protocol flit with the rem chunks in slots 1..rem,
                              rem = 0.
    B. llcrd_eff  -> LLCRD flit (flit_is_control=1); lat is cleared.
    C. msg_valid  -> first flit of the new message (this is the handshake).
    D. otherwise  -> flit_valid becomes 0.
  crd_taken = rst_n && slot_free && (case A with rem <= 3, or case B, or case C).
  The crd_*_field inputs are copied into the header of the flit chosen in that
  same cycle.

At the rising edge:
  if !rst_n: clear the output register, rem = 0, lat = 0.
  else if slot_free: load the chosen flit.
  else: hold the output register.
  lat <= (slot_free && case B) ? 0 : llcrd_eff.

## credit_tracker
State: snd[0..1] (7 bits), pend[0..1] (8 bits).
Reset: snd = 0, pend = RX_DEPTH.
Outputs are combinational from the counters.
Decode of a 3-bit credit code to a count: 0,1,2,4,8,16,32,64 for codes 0..7.
Greedy encode of pend: pick the largest count <= pend (pend 0 gives code 0).
Outgoing field = {1'b1, code} for fields used in this DIRECTION, 4'b0000 for the
reserved one.
Use intermediate values wider than the counters, then clamp to CREDIT_MAX or
PEND_MAX, so saturation never wraps around.
