# WORKED EXAMPLES (illustration only; the specification above is the authority)

## Example 1: one M2S MemRd, DIRECTION 0
Inputs in the handshake cycle: msg_valid=1, msg_kind=0 (Req), msg_opcode=4'b0001,
msg_addr=A, msg_tag=T, crd_req_field=4'b0000, crd_data_field=4'b1001,
crd_rsp_field=4'b1010. msg_ready=1 and crd_taken=1 in this cycle.
One flit appears in the output register on the next rising edge:
  Slot 0 header [31:0]: Type=0, RV=0, Ak=0, BE=0, Sz=0, Slot0=3'b101,
    Slot1=3'b100, Slot2=3'b100, Slot3=3'b100, RSVD=0,
    RspCrd=4'b1010, ReqCrd=4'b0000, DataCrd=4'b1001.
  Slot 0 message [127:32]: Valid=1 at [32], MemOpcode=4'b0001 at [36:33],
    SnpType=000, MetaField=11, MetaValue=00, Tag=T at [59:44],
    Address[51:5]=A[51:5] at [106:60], TC=0, LD-ID=0, RSVD=0, pad=0.
  Slots 1, 2, 3: all zero. CRC = 16'h0000.
  flit_valid=1, flit_is_control=0, flit_is_alldata=0.

## Example 2: one M2S MemWr (4 data chunks), DIRECTION 0, flit_ready always 1
Cycle t:   msg_valid=1, msg_kind=1 (RwD), msg_opcode=4'b0001. msg_ready=1,
           crd_taken=1.
Cycle t+1: Flit A is in the output register. Slot0 = H4 (3'b100) carrying the
           RwD header, header Sz=1 and BE=0. Slots 1, 2, 3 = G0 (3'b000)
           holding chunks 0, 1, 2. Chunk 3 is still pending (rem=1), so
           msg_ready=0. This cycle the packer builds flit B: crd_taken=1.
Cycle t+2: Flit B is in the output register. It is a protocol flit whose Slot 0
           carries no message (all message bits 0, selector H5 = 3'b101),
           Sz=0, BE=0. Slot 1 = G0 holding chunk 3. Slots 2 and 3 are empty:
           128 zero bits each with selector 3'b100. rem is now 0, msg_ready=1.
