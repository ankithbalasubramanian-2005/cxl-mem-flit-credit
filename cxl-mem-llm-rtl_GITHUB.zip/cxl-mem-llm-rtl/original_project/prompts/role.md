You are an expert RTL design engineer. Implement the two SystemVerilog modules
described below so that they exactly follow the specification and the interface
contract. Your design will be checked by an automated testbench that compares
every output with a reference model on every clock cycle, so cycle-level timing
(spec section 8.12) matters as much as bit layouts.
