# OUTPUT RULES (follow exactly)
- Write synthesizable SystemVerilog that compiles with Icarus Verilog iverilog -g2012.
- Return exactly two modules: flit_packer and credit_tracker.
- Module names, parameter names, port names and port widths must match the
  declarations above exactly. Do not add, remove or rename ports or parameters.
- Do not define any other module (no helper modules, no testbench).
- Use a synchronous, active-low reset (rst_n).
- Put each module in its own systemverilog code block
- Keep any explanation very short and outside the code blocks.
- Begin your reply directly with the first code block. Do not include analysis,
  derivations or working notes anywhere in the reply.
- Icarus Verilog rejects a variable declaration that comes AFTER a statement in
  the same begin-end block. Wrong:   x = 1; logic [3:0] y;
  Right: logic [3:0] y; x = 1;
  Declare every local variable before the first statement of its block, or
  declare it at module level. Do not give local variables initial values in
  their declarations. Never declare a name twice in one scope.
