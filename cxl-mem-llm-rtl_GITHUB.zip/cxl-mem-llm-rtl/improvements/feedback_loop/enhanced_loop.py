#!/usr/bin/env python3
"""Optional post-experiment loop: functional tests + assertions + synthesis.

Defaults to offline fixtures; --live is required to make any model API call.
Original orchestrator, judge, RTL, and official run logs remain unchanged.
"""
import argparse,contextlib,csv,hashlib,json,os,re,shutil,signal,subprocess,sys
import xml.etree.ElementTree as ET
from pathlib import Path

HERE=Path(__file__).resolve().parent
B=HERE.parent.parent
PROJECT=B/'original_project'
MODULES=('flit_packer','credit_tracker')
sys.path.insert(0,str(PROJECT))
from orchestrator.build_prompt import build_initial
from orchestrator.checks import check_all
from orchestrator.extractor import extract_code

@contextlib.contextmanager
def project_cwd():
    old=Path.cwd()
    try:os.chdir(PROJECT);yield
    finally:os.chdir(old)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def execute(cmd,log,timeout):
    log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('w') as f:
        try:p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        except OSError as e:
            f.write(type(e).__name__+': '+str(e));return None
        try:return p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            os.killpg(p.pid,signal.SIGKILL);p.wait();return None

def error_excerpt(log):
    lines=Path(log).read_text(errors='replace').splitlines()
    selected=[x.strip() for x in lines if any(k in x for k in ('FATAL:','A_CREDIT_','FIRST MISMATCH','output pend_','ERROR:','Warning: found logic loop','conflicting drivers','wasm trap:'))]
    return '\n'.join(selected[:6])[:1200] or '\n'.join(lines[-4:])[:600]

def xml_gate(rc,path,expected_tests):
    if not path.exists():return 'INCONCLUSIVE',None,None
    try:nodes=ET.parse(path).getroot().findall('.//testcase')
    except ET.ParseError:return 'INCONCLUSIVE',None,None
    failed=sum(n.find('failure') is not None or n.find('error') is not None for n in nodes)
    if rc is None or len(nodes)!=expected_tests:return 'INCONCLUSIVE',len(nodes),failed
    return ('PASS' if rc==0 and failed==0 else 'FAIL'),len(nodes),failed

def evaluate(rtl,out,seed,yosys,cached):
    """Run enabled gates; only hash-identical fully passing modules are reused."""
    out.mkdir(parents=True,exist_ok=True)
    check_path=out/'syntax_interface.json'
    checker="import json,sys;from pathlib import Path;from orchestrator.checks import check_all;Path(sys.argv[2]).write_text(json.dumps(check_all(Path(sys.argv[1])),indent=2))"
    # Keep the original checker unchanged, but bound its entire process group.
    # The child starts in the source project so relative interface paths work.
    with project_cwd():
        rc=execute([sys.executable,'-c',checker,str(rtl),str(check_path)],out/'syntax_interface.log',60)
    if rc!=0 or not check_path.exists():
        cheap={'ok':False,'stage':'tool','message':'Syntax/interface checker could not complete. '+error_excerpt(out/'syntax_interface.log')}
        return {'accepted':False,'blocked':True,'precheck':cheap,'modules':{}}
    cheap=json.loads(check_path.read_text())
    if not cheap['ok']:
        return {'accepted':False,'blocked':False,'precheck':cheap,'modules':{}}
    inputs=out/'inputs';(inputs/'rtl/candidate').mkdir(parents=True)
    result={};todo=[];selection=[]
    for module in MODULES:
        sha=digest(rtl/f'{module}.sv')
        if module in cached and cached[module]['sha256']==sha and cached[module]['passed']:
            result[module]={**cached[module],'reused':True};continue
        shutil.copy2(rtl/f'{module}.sv',inputs/'rtl/candidate'/f'{module}.sv')
        result[module]={'sha256':sha,'reused':False,'checks':[]};todo.append(module)
        selection.append({'tag':'candidate','module':module,'rtl':f'rtl/candidate/{module}.sv','sha256':sha})
    for module in todo:
        for direction in [0,1]:
            d=out/'functional/candidate'/module/f'D{direction}'
            rc=execute([sys.executable,str(B/'verification/run_frozen_regression.py'),'--rtl-root',str(inputs),'--project',str(PROJECT),'--out',str(out/'functional'),'--one','candidate',module,str(direction),str(seed)],d/'sim.log',180)
            status,tests,failed=xml_gate(rc,d/f'seed{seed}.xml',21 if module=='flit_packer' else 10)
            result[module]['checks'].append({'gate':'functional','direction':direction,'status':status,'tests':tests,'failed_tests':failed,'evidence':str(d/'sim.log'),'diagnostic':'' if status=='PASS' else error_excerpt(d/'sim.log')})
            top='packer_assert_tb' if module=='flit_packer' else 'credit_assert_tb'
            d=out/'assertions'/module/f'D{direction}';d.mkdir(parents=True)
            net=d/'sim.vvp'
            rc=execute(['iverilog','-g2012','-s',top,'-P',f'{top}.DIRECTION={direction}','-o',str(net),str(rtl/f'{module}.sv'),str(B/'verification'/f'{module}_assertions.sv'),str(B/'verification'/f'{top}.sv')],d/'compile.log',30)
            if rc!=0:
                status='INCONCLUSIVE' if rc is None else 'FAIL';diag=error_excerpt(d/'compile.log')
            else:
                rc=execute(['vvp',str(net)],d/'sim.log',20)
                status='INCONCLUSIVE' if rc is None else ('PASS' if rc==0 else ('FAIL' if 'A_' in (d/'sim.log').read_text() else 'INCONCLUSIVE'))
                diag='' if status=='PASS' else error_excerpt(d/'sim.log')
            result[module]['checks'].append({'gate':'assertions','direction':direction,'status':status,'evidence':str(d),'diagnostic':diag})
    if todo:
        (inputs/'selection.json').write_text(json.dumps(selection,indent=2))
        shutil.copy2(B/'synthesis_bundle/run_synthesis.py',inputs/'run_synthesis.py')
        rc=execute([sys.executable,str(inputs/'run_synthesis.py'),'--yosys',yosys,'--out',str(out/'synthesis'),'--timeout','120'],out/'synthesis_driver.log',120*2*len(todo)+60)
        summary=out/'synthesis/summary.json'
        synthesis=json.loads(summary.read_text()) if summary.exists() else []
        for module in todo:
            for direction in [0,1]:
                row=next((x for x in synthesis if x['module']==module and x['direction']==direction),None)
                status='INCONCLUSIVE';diag=error_excerpt(out/'synthesis_driver.log')
                if row:
                    raw=row['status'];status='PASS' if raw=='PASS' else ('FAIL' if raw in ['STRUCTURAL_ERROR','FRONTEND_ERROR','SYNTHESIS_ERROR'] else 'INCONCLUSIVE')
                    diag='' if status=='PASS' else row.get('error',raw)
                result[module]['checks'].append({'gate':'synthesis','direction':direction,'status':status,'raw_status':row['status'] if row else 'NO_RESULT','cells':row.get('cells') if row else None,'depth':row.get('logic_depth') if row else None,'diagnostic':diag,'evidence':str(out/'synthesis')})
    for module,r in result.items():
        r['passed']=len(r['checks'])==6 and all(x['status']=='PASS' for x in r['checks'])
        r['failed_checks']=sum(x['status']=='FAIL' for x in r['checks'])
    blocked=any(x['status']=='INCONCLUSIVE' for r in result.values() for x in r['checks'])
    return {'accepted':all(x['passed'] for x in result.values()),'blocked':blocked,'precheck':cheap,'modules':result}

def feedback(report):
    if not report['precheck']['ok']:
        prefix='Tool result is INCONCLUSIVE; stop instead of requesting an RTL repair.' if report['blocked'] else 'Syntax/interface check failed:'
        return prefix+'\n'+report['precheck']['message']
    parts=[]
    for module,r in report['modules'].items():
        if r['passed']:
            parts.append(f'{module}: PASSES all enabled gates. Frozen; do not return or modify it.')
        else:
            parts.append(f'{module}: NOT ACCEPTED. The following checks did not pass:')
            for x in r['checks']:
                if x['status']!='PASS':parts.append(f"  {x['gate']} D{x['direction']}: {x['status']}\n{x['diagnostic']}")
    if report['blocked']:parts.append('An infrastructure/tool result is inconclusive. Stop; do not label this as an RTL failure or claim convergence.')
    return '\n'.join(parts)

def run(strategy,out,max_iter,seed,yosys,replay=None,live=False,client=None):
    out=out.resolve()
    if out.exists():raise ValueError('Output directory already exists; choose a fresh path.')
    out.mkdir(parents=True)
    with project_cwd():initial=build_initial(strategy)
    best={};cache={};history=[];prompt=initial;last_feedback=None;repeats=0;model_calls=0
    status='ITERATION_LIMIT';mode='live_llm' if live else 'offline_fixture_replay'
    for iteration in range(max_iter):
        d=out/f'iter{iteration}';d.mkdir();(d/'prompt.txt').write_text(prompt)
        if live:
            model_calls+=1
            try:resp=client(prompt,repair=iteration>0)
            except Exception as e:
                status='MODEL_ERROR';(d/'model_error.txt').write_text(type(e).__name__)
                history.append({'iteration':iteration,'mode':mode,'stage':'model_error','exception_type':type(e).__name__})
                (out/'history.json').write_text(json.dumps(history,indent=2));break
            text=resp['text'];model=resp.get('model','unspecified')
        else:
            if not replay or iteration>=len(replay):status='FIXTURES_EXHAUSTED';break
            folder=Path(replay[iteration]).resolve();fence=chr(96)*3
            text='\n'.join(fence+'systemverilog\n'+(folder/f'{m}.sv').read_text()+'\n'+fence for m in MODULES if (folder/f'{m}.sv').exists())
            model='offline fixture; not an LLM-generated repair'
        ex=extract_code(text,d);ignored=[]
        for module in MODULES:
            dest=d/f'{module}.sv'
            if module in cache and cache[module]['passed']:
                if dest.exists() and digest(dest)!=cache[module]['sha256']:ignored.append(module)
                shutil.copy2(best[module]['path'],dest)
            elif not dest.exists() and module in best:shutil.copy2(best[module]['path'],dest)
        missing=[m for m in MODULES if not (d/f'{m}.sv').exists()]
        if missing:
            report={'accepted':False,'blocked':False,'precheck':{'ok':False,'stage':'extraction','message':f'Missing required module(s): {missing}'},'modules':{}}
        else:report=evaluate(d,d/'gates',seed,yosys,cache)
        fb=feedback(report);(d/'feedback.txt').write_text(fb);(d/'gates.json').write_text(json.dumps(report,indent=2))
        entry={'iteration':iteration,'mode':mode,'model':model,'accepted':report['accepted'],'blocked':report['blocked'],'ignored_changes_to_frozen_modules':ignored,'module_states':{}}
        for module,r in report['modules'].items():
            entry['module_states'][module]={'passed':r['passed'],'failed_checks':r['failed_checks'],'reused':r['reused'],'sha256':r['sha256']}
            if not report['blocked'] and (module not in best or r['failed_checks']<best[module]['failed_checks']):
                best[module]={'path':d/f'{module}.sv','failed_checks':r['failed_checks'],'result':r}
            if r['passed']:cache[module]=r
        history.append(entry);(out/'history.json').write_text(json.dumps(history,indent=2))
        print(f'{out.name} iter{iteration}: accepted={report["accepted"]} blocked={report["blocked"]} states={entry["module_states"]}',flush=True)
        if report['blocked']:status='BLOCKED_BY_TOOL';break
        if report['accepted']:
            status='ACCEPTED';final=out/'accepted_rtl';final.mkdir()
            for m in MODULES:shutil.copy2(d/f'{m}.sv',final/f'{m}.sv')
            break
        repeats=repeats+1 if fb==last_feedback else 1;last_feedback=fb
        if repeats>=3:status='REPEATED_FEEDBACK_STOP';break
        shown={m:(best[m]['path'] if m in best and report['precheck']['ok'] else d/f'{m}.sv') for m in MODULES}
        prompt_report={**report,'modules':{m:best[m]['result'] if m in best else r for m,r in report['modules'].items()}}
        repair_feedback=feedback(prompt_report)
        code='\n'.join((p.read_text() if p.exists() else '(missing '+m+')') for m,p in shown.items())
        # Only symptoms and the candidate's own RTL are included, never monitor/model source.
        prompt=initial+'\n\n# CURRENT CANDIDATE RTL\n'+code+'\n\n# VALIDATION FEEDBACK\n'+repair_feedback+'\n\n# REPAIR TASK\nMake the smallest correction to failing module(s). Return only failing modules, complete and with unchanged interfaces, in SystemVerilog code blocks. Passing modules are frozen.\n'
    summary={'status':status,'mode':mode,'iterations':len(history),'strategy':strategy,'seed':seed,'gates':['syntax/interface','functional D0/D1','assertions D0/D1','synthesis D0/D1'],'live_model_calls':model_calls,'loop_source_sha256':digest(Path(__file__)),'note':'Fixture replay checks the orchestration only. It does not demonstrate LLM repair ability or improve the nine-run convergence statistics.'}
    (out/'summary.json').write_text(json.dumps(summary,indent=2))
    return summary

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    mode=ap.add_mutually_exclusive_group(required=True)
    mode.add_argument('--replay',nargs='+',type=Path,help='Candidate directories used as offline responses, in order')
    mode.add_argument('--live',action='store_true',help='Explicit opt-in to model API calls using the original client')
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--strategy',type=int,choices=[1,2,3],default=2)
    ap.add_argument('--max-iter',type=int,default=15)
    ap.add_argument('--seed',type=int,default=1234)
    ap.add_argument('--yosys',default='yowasp-yosys')
    a=ap.parse_args();client=None
    if a.live:
        from orchestrator.llm_client import call_llm
        client=call_llm
    summary=run(a.strategy,a.out,a.max_iter,a.seed,a.yosys,a.replay,a.live,client)
    print(json.dumps(summary,indent=2));raise SystemExit(0 if summary['status']=='ACCEPTED' else 1)
if __name__=='__main__':main()
