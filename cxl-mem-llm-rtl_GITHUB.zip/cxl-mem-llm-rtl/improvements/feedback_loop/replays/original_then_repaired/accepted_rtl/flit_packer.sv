module flit_packer #(
  parameter int DIRECTION  = 0,
  parameter int MAX_CHUNKS = 8
) (
  input  logic                      clk,
  input  logic                      rst_n,
  input  logic                      msg_valid,
  output logic                      msg_ready,
  input  logic                      msg_kind,
  input  logic [3:0]                msg_opcode,
  input  logic [51:0]               msg_addr,
  input  logic [15:0]               msg_tag,
  input  logic                      msg_poison,
  input  logic [63:0]               msg_byte_en,
  input  logic [128*MAX_CHUNKS-1:0] msg_data,
  input  logic                      chunks_ovr_en,
  input  logic [3:0]                chunks_ovr,
  input  logic [3:0]                crd_req_field,
  input  logic [3:0]                crd_data_field,
  input  logic [3:0]                crd_rsp_field,
  output logic                      crd_taken,
  input  logic                      force_llcrd,
  output logic                      flit_valid,
  input  logic                      flit_ready,
  output logic [527:0]              flit_out,
  output logic                      flit_is_control,
  output logic                      flit_is_alldata
);

  localparam logic [2:0] SLOT_H0 = 3'd0;
  localparam logic [2:0] SLOT_H3 = 3'd3;
  localparam logic [2:0] SLOT_H4 = 3'd4;
  localparam logic [2:0] SLOT_H5 = 3'd5;
  localparam logic [2:0] SLOT_G0 = 3'd0;
  localparam logic [2:0] SLOT_G3 = 3'd3;
  localparam logic [2:0] SLOT_G4 = 3'd4;
  localparam logic [2:0] SLOT_G5 = 3'd5;

  localparam logic [3:0] OP_M2S_REQ_MEMRD    = 4'h1;
  localparam logic [3:0] OP_M2S_REQ_MEMRDDATA= 4'h2;
  localparam logic [3:0] OP_M2S_RWD_MEMWR    = 4'h1;
  localparam logic [3:0] OP_M2S_RWD_MEMWRPTL = 4'h2;
  localparam logic [3:0] OP_S2M_NDR_CMP      = 4'h0;
  localparam logic [3:0] OP_S2M_DRS_MEMDATA  = 4'h0;

  logic slot_free;
  logic [3:0] rem;
  logic lat;
  logic llcrd_eff;
  logic [127:0] chunk_reg [0:MAX_CHUNKS-1];

  assign slot_free = !flit_valid || flit_ready;
  assign llcrd_eff = lat || force_llcrd;
  assign msg_ready = rst_n && slot_free && (rem == 0) && !llcrd_eff;

  function automatic logic [2:0] enc_credit(input logic [6:0] cnt);
    logic [2:0] c;
    begin
      if      (cnt >= 64) c = 3'd7;
      else if (cnt >= 32) c = 3'd6;
      else if (cnt >= 16) c = 3'd5;
      else if (cnt >=  8) c = 3'd4;
      else if (cnt >=  4) c = 3'd3;
      else if (cnt >=  2) c = 3'd2;
      else if (cnt >=  1) c = 3'd1;
      else                c = 3'd0;
      return c;
    end
  endfunction

  function automatic logic [6:0] dec_credit(input logic [2:0] code);
    logic [6:0] v;
    begin
      unique case (code)
        3'd0: v = 7'd0;
        3'd1: v = 7'd1;
        3'd2: v = 7'd2;
        3'd3: v = 7'd4;
        3'd4: v = 7'd8;
        3'd5: v = 7'd16;
        3'd6: v = 7'd32;
        3'd7: v = 7'd64;
        default: v = 7'd0;
      endcase
      return v;
    end
  endfunction

  function automatic logic [127:0] build_slot0_m2s_req(
    input logic [3:0] opcode,
    input logic [51:0] addr,
    input logic [15:0] tag
  );
    logic [127:0] s;
    begin
      s = '0;
      s[32]   = 1'b1;
      s[36:33] = opcode;
      s[39:37] = 3'b000;
      s[41:40] = 2'b11;
      s[43:42] = 2'b00;
      s[59:44] = tag;
      s[106:60] = addr[51:5];
      s[108:107] = 2'b00;
      s[112:109] = 4'b0000;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_m2s_rwd(
    input logic [3:0] opcode,
    input logic [51:0] addr,
    input logic [15:0] tag,
    input logic poison
  );
    logic [127:0] s;
    begin
      s = '0;
      s[32]   = 1'b1;
      s[36:33] = opcode;
      s[39:37] = 3'b000;
      s[41:40] = 2'b11;
      s[43:42] = 2'b00;
      s[59:44] = tag;
      s[105:60] = addr[51:6];
      s[106]    = poison;
      s[108:107] = 2'b00;
      s[112:109] = 4'b0000;
      return s;
    end
  endfunction

  function automatic logic [127:0] build_slot0_s2m(
    input logic is_drs,
    input logic [2:0] opcode,
    input logic [15:0] tag,
    input logic poison
  );
    logic [127:0] s;
    begin
      s = '0;
      if (is_drs) begin
        s[32]   = 1'b1;
        s[35:33] = opcode;
        s[37:36] = 2'b11;
        s[39:38] = 2'b00;
        s[55:40] = tag;
        s[56]    = poison;
        s[60:57] = 4'b0000;
        s[62:61] = 2'b00;
      end else begin
        s[72]   = 1'b1;
        s[75:73] = opcode;
        s[77:76] = 2'b11;
        s[79:78] = 2'b00;
        s[95:80] = tag;
        s[99:96] = 4'b0000;
        s[101:100] = 2'b00;
      end
      return s;
    end
  endfunction

  function automatic logic [127:0] build_be_chunk(input logic [63:0] be);
    logic [127:0] s;
    begin
      s = '0;
      s[31:0]   = be[31:0];
      s[63:32]  = be[63:32];
      return s;
    end
  endfunction

  function automatic logic [527:0] build_protocol_flit(
    input logic [2:0] slot0_fmt,
    input logic [2:0] slot1_fmt,
    input logic [2:0] slot2_fmt,
    input logic [2:0] slot3_fmt,
    input logic sz,
    input logic be,
    input logic [3:0] reqcrd,
    input logic [3:0] datacrd,
    input logic [3:0] rspcrd,
    input logic [127:0] slot0,
    input logic [127:0] slot1,
    input logic [127:0] slot2,
    input logic [127:0] slot3
  );
    logic [527:0] f;
    begin
      f = '0;
      f[0]   = 1'b0;
      f[1]   = 1'b0;
      f[2]   = 1'b0;
      f[3]   = be;
      f[4]   = sz;
      f[7:5] = slot0_fmt;
      f[10:8] = slot1_fmt;
      f[13:11] = slot2_fmt;
      f[16:14] = slot3_fmt;
      f[19:17] = 3'b000;
      f[23:20] = rspcrd;
      f[27:24] = reqcrd;
      f[31:28] = datacrd;
      f[127:32] = slot0[127:32];
      f[255:128] = slot1;
      f[383:256] = slot2;
      f[511:384] = slot3;
      f[527:512] = 16'h0000;
      return f;
    end
  endfunction

  function automatic logic [527:0] build_alldata_flit(
    input logic [127:0] c0,
    input logic [127:0] c1,
    input logic [127:0] c2,
    input logic [127:0] c3
  );
    logic [527:0] f;
    begin
      f = '0;
      f[127:0]   = c0;
      f[255:128] = c1;
      f[383:256] = c2;
      f[511:384] = c3;
      f[527:512] = 16'h0000;
      return f;
    end
  endfunction

  function automatic logic [527:0] build_llcrd_flit(
    input logic [3:0] reqcrd,
    input logic [3:0] datacrd,
    input logic [3:0] rspcrd
  );
    logic [527:0] f;
    begin
      f = '0;
      f[0]   = 1'b1;
      f[1]   = 1'b0;
      f[2]   = 1'b0;
      f[4:3] = 2'b00;
      f[7:5] = 3'b000;
      f[15:8] = 8'h00;
      f[19:16] = 4'h0;
      f[23:20] = rspcrd;
      f[27:24] = reqcrd;
      f[31:28] = datacrd;
      f[35:32] = 4'b0000;
      f[39:36] = 4'b0000;
      f[63:40] = 24'h0;
      f[127:64] = 64'h0;
      f[527:128] = 399'h0;
      f[527:512] = 16'h0000;
      return f;
    end
  endfunction

  logic [527:0] next_flit;
  logic next_flit_valid;
  logic next_flit_is_control;
  logic next_flit_is_alldata;
  logic next_crd_taken;
  logic [3:0] next_rem;
  logic next_lat;
  logic [127:0] next_chunk_reg [0:MAX_CHUNKS-1];

  always_comb begin
    logic [127:0] s0, s1, s2, s3;
    logic [2:0] f1, f2, f3;
    logic [2:0] s0fmt;
    logic sz, be;
    logic [3:0] total_chunks;
    logic [3:0] first_flit_chunks;
    logic [127:0] temp_chunks [0:MAX_CHUNKS-1];
    logic [127:0] be_chunk;
    logic is_memwrptl;

    next_flit = '0;
    next_flit_valid = 1'b0;
    next_flit_is_control = 1'b0;
    next_flit_is_alldata = 1'b0;
    next_crd_taken = 1'b0;
    next_rem = rem;
    next_lat = llcrd_eff;
    // Every combinational path must define this temporary, including M2S Req.
    is_memwrptl = 1'b0;
    for (int i = 0; i < MAX_CHUNKS; i++) begin
      next_chunk_reg[i] = chunk_reg[i];
      temp_chunks[i] = chunk_reg[i];
    end

    if (rst_n && slot_free) begin
      if (rem > 0) begin
        if (rem > 3) begin
          next_flit = build_alldata_flit(temp_chunks[0], temp_chunks[1], temp_chunks[2], temp_chunks[3]);
          next_flit_valid = 1'b1;
          next_flit_is_alldata = 1'b1;
          next_rem = rem - 4;
          for (int i = 0; i < MAX_CHUNKS-4; i++) next_chunk_reg[i] = temp_chunks[i+4];
          for (int i = MAX_CHUNKS-4; i < MAX_CHUNKS; i++) next_chunk_reg[i] = '0;
          next_lat = llcrd_eff;
        end else begin
          s0 = '0;
          s1 = '0; s2 = '0; s3 = '0;
          f1 = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          f2 = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          f3 = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
          if (rem >= 1) begin s1 = temp_chunks[0]; f1 = SLOT_G0; end
          if (rem >= 2) begin s2 = temp_chunks[1]; f2 = SLOT_G0; end
          if (rem >= 3) begin s3 = temp_chunks[2]; f3 = SLOT_G0; end
          s0fmt = (DIRECTION == 0) ? SLOT_H5 : SLOT_H3;
          next_flit = build_protocol_flit(s0fmt, f1, f2, f3, 1'b0, 1'b0,
                                          crd_req_field, crd_data_field, crd_rsp_field,
                                          s0, s1, s2, s3);
          next_flit_valid = 1'b1;
          next_crd_taken = 1'b1;
          next_rem = 0;
          for (int i = 0; i < MAX_CHUNKS; i++) next_chunk_reg[i] = '0;
          next_lat = llcrd_eff;
        end
      end else if (llcrd_eff) begin
        next_flit = build_llcrd_flit(crd_req_field, crd_data_field, crd_rsp_field);
        next_flit_valid = 1'b1;
        next_flit_is_control = 1'b1;
        next_crd_taken = 1'b1;
        next_lat = 1'b0;
      end else if (msg_valid) begin
        if (chunks_ovr_en) begin
          total_chunks = chunks_ovr;
          is_memwrptl = 1'b0;
        end else begin
          if (DIRECTION == 0) begin
            if (msg_kind == 1'b0) total_chunks = 0;
            else begin
              if (msg_opcode == OP_M2S_RWD_MEMWRPTL) begin
                total_chunks = 5;
                is_memwrptl = 1'b1;
              end else begin
                total_chunks = 4;
                is_memwrptl = 1'b0;
              end
            end
          end else begin
            if (msg_kind == 1'b0) total_chunks = 0;
            else total_chunks = 4;
            is_memwrptl = 1'b0;
          end
        end

        first_flit_chunks = (total_chunks > 3) ? 3 : total_chunks;
        next_rem = total_chunks - first_flit_chunks;

        for (int i = 0; i < MAX_CHUNKS; i++) next_chunk_reg[i] = '0;
        if (!chunks_ovr_en && is_memwrptl) begin
          next_chunk_reg[0] = msg_data[511:384];
          be_chunk = build_be_chunk(msg_byte_en);
          next_chunk_reg[1] = be_chunk;
        end else begin
          for (int i = 0; i < next_rem; i++) begin
            next_chunk_reg[i] = msg_data[128*(first_flit_chunks+i) +: 128];
          end
        end

        sz = (DIRECTION == 0) ? (msg_kind == 1'b1) : (msg_kind == 1'b1);
        be = (DIRECTION == 0) && (msg_kind == 1'b1) && (msg_opcode == OP_M2S_RWD_MEMWRPTL);

        if (DIRECTION == 0) begin
          if (msg_kind == 1'b0) begin
            s0 = build_slot0_m2s_req(msg_opcode, msg_addr, msg_tag);
            s0fmt = SLOT_H5;
          end else begin
            s0 = build_slot0_m2s_rwd(msg_opcode, msg_addr, msg_tag, msg_poison);
            s0fmt = SLOT_H4;
          end
        end else begin
          if (msg_kind == 1'b0) begin
            s0 = build_slot0_s2m(1'b0, msg_opcode[2:0], msg_tag, 1'b0);
            s0fmt = SLOT_H3;
          end else begin
            s0 = build_slot0_s2m(1'b1, msg_opcode[2:0], msg_tag, msg_poison);
            s0fmt = SLOT_H3;
          end
        end

        f1 = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
        f2 = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
        f3 = (DIRECTION == 0) ? SLOT_G4 : SLOT_G5;
        s1 = '0; s2 = '0; s3 = '0;
        if (first_flit_chunks >= 1) begin s1 = msg_data[127:0];   f1 = SLOT_G0; end
        if (first_flit_chunks >= 2) begin s2 = msg_data[255:128]; f2 = SLOT_G0; end
        if (first_flit_chunks >= 3) begin s3 = msg_data[383:256]; f3 = SLOT_G0; end

        next_flit = build_protocol_flit(s0fmt, f1, f2, f3, sz, be,
                                        crd_req_field, crd_data_field, crd_rsp_field,
                                        s0, s1, s2, s3);
        next_flit_valid = 1'b1;
        next_crd_taken = 1'b1;
        next_lat = llcrd_eff;
      end else begin
        next_flit_valid = 1'b0;
        next_lat = llcrd_eff;
      end
    end else begin
      next_lat = llcrd_eff;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      flit_valid <= 1'b0;
      flit_out <= '0;
      flit_is_control <= 1'b0;
      flit_is_alldata <= 1'b0;
      rem <= 4'd0;
      lat <= 1'b0;
      for (int i = 0; i < MAX_CHUNKS; i++) chunk_reg[i] <= '0;
    end else begin
      lat <= next_lat;
      if (slot_free) begin
        flit_valid <= next_flit_valid;
        flit_out <= next_flit;
        flit_is_control <= next_flit_is_control;
        flit_is_alldata <= next_flit_is_alldata;
        rem <= next_rem;
        for (int i = 0; i < MAX_CHUNKS; i++) chunk_reg[i] <= next_chunk_reg[i];
      end
    end
  end

  assign crd_taken = rst_n && slot_free && next_crd_taken;

endmodule
