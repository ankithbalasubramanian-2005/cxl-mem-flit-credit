module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [0:1];
  logic [7:0] pend [0:1];

  function automatic logic [6:0] dec_credit (input logic [3:0] f);
    logic [6:0] v;
    begin
      if (f[3] == 1'b0) v = 7'd0;
      else begin
        unique case (f[2:0])
          3'd0: v = 7'd0;
          3'd1: v = 7'd1;
          3'd2: v = 7'd2;
          3'd3: v = 7'd4;
          3'd4: v = 7'd8;
          3'd5: v = 7'd16;
          3'd6: v = 7'd32;
          3'd7: v = 7'd64;
          default: v = 7'd0;
        endcase
      end
      return v;
    end
  endfunction

  function automatic logic [3:0] enc_credit (input logic [7:0] cnt);
    logic [2:0] code;
    begin
      if (cnt >= 64) code = 3'd7;
      else if (cnt >= 32) code = 3'd6;
      else if (cnt >= 16) code = 3'd5;
      else if (cnt >= 8)  code = 3'd4;
      else if (cnt >= 4)  code = 3'd3;
      else if (cnt >= 2)  code = 3'd2;
      else if (cnt >= 1)  code = 3'd1;
      else                code = 3'd0;
      return {1'b1, code};
    end
  endfunction

  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];
  assign can_send     = {snd[1] != 0, snd[0] != 0};
  assign pend_0       = pend[0];
  assign pend_1       = pend[1];
  assign crd_pending  = (pend[0] != 0) || (pend[1] != 0);

  always_comb begin
    if (DIRECTION == 0) begin
      crd_req_field  = 4'b0000;
      crd_data_field = enc_credit(pend[1]);
      crd_rsp_field  = enc_credit(pend[0]);
    end else begin
      crd_req_field  = enc_credit(pend[0]);
      crd_data_field = enc_credit(pend[1]);
      crd_rsp_field  = 4'b0000;
    end
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0]  <= 7'd0;
      snd[1]  <= 7'd0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      logic [7:0] add0, add1;
      logic [7:0] sub0, sub1;
      logic [8:0] nxt_pend0, nxt_pend1;
      logic [7:0] nxt_snd0, nxt_snd1;

      add0 = 8'd0; add1 = 8'd0;
      if (rx_crd_valid) begin
        if (DIRECTION == 0) begin
          add0 = dec_credit(rx_reqcrd);
          add1 = dec_credit(rx_datacrd);
        end else begin
          add0 = dec_credit(rx_rspcrd);
          add1 = dec_credit(rx_datacrd);
        end
      end

      nxt_snd0 = snd[0] + add0;
      nxt_snd1 = snd[1] + add1;
      if (tx_send[0] && snd[0] != 0) nxt_snd0 = nxt_snd0 - 1;
      if (tx_send[1] && snd[1] != 0) nxt_snd1 = nxt_snd1 - 1;
      if (nxt_snd0 > CREDIT_MAX) nxt_snd0 = CREDIT_MAX;
      if (nxt_snd1 > CREDIT_MAX) nxt_snd1 = CREDIT_MAX;
      snd[0] <= nxt_snd0[6:0];
      snd[1] <= nxt_snd1[6:0];

      sub0 = 8'd0; sub1 = 8'd0;
      if (crd_taken) begin
        if (DIRECTION == 0) begin
          sub0 = dec_credit(crd_rsp_field);
          sub1 = dec_credit(crd_data_field);
        end else begin
          sub0 = dec_credit(crd_req_field);
          sub1 = dec_credit(crd_data_field);
        end
      end

      nxt_pend0 = pend[0] + buf_free[0];
      nxt_pend1 = pend[1] + buf_free[1];
      if (nxt_pend0 >= sub0) nxt_pend0 = nxt_pend0 - sub0;
      else nxt_pend0 = 8'd0;
      if (nxt_pend1 >= sub1) nxt_pend1 = nxt_pend1 - sub1;
      else nxt_pend1 = 8'd0;
      if (nxt_pend0 > PEND_MAX) nxt_pend0 = PEND_MAX;
      if (nxt_pend1 > PEND_MAX) nxt_pend1 = PEND_MAX;
      pend[0] <= nxt_pend0[7:0];
      pend[1] <= nxt_pend1[7:0];
    end
  end

endmodule
