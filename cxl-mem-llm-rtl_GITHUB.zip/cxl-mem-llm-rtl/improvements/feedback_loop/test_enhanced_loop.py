"""Guard against false acceptance and misleading repairs on infrastructure failure."""
import json
from pathlib import Path
import enhanced_loop as e

def test_no_xml_is_inconclusive(tmp_path):
    assert e.xml_gate(0,tmp_path/'missing.xml',21)[0]=='INCONCLUSIVE'

def test_incomplete_xml_cannot_be_a_pass(tmp_path):
    path=tmp_path/'results.xml';path.write_text('<testsuites><testsuite><testcase name="only_one"/></testsuite></testsuites>')
    status,count,_=e.xml_gate(0,path,21)
    assert status=='INCONCLUSIVE' and count==1

def test_assertion_error_in_xml_is_not_a_pass(tmp_path):
    path=tmp_path/'results.xml';path.write_text('<testsuites><testsuite><testcase><failure message="mismatch"/></testcase></testsuite></testsuites>')
    assert e.xml_gate(0,path,1)==('FAIL',1,1)

def test_compile_infrastructure_failure_does_not_request_code_repair(tmp_path,monkeypatch):
    def failed_process(cmd,log,timeout):
        log.parent.mkdir(parents=True,exist_ok=True);log.write_text('FileNotFoundError: compiler executable missing');return None
    monkeypatch.setattr(e,'execute',failed_process)
    report=e.evaluate(tmp_path,tmp_path/'gates',1234,'missing-yosys',{})
    assert not report['accepted'] and report['blocked']
    assert 'INCONCLUSIVE' in e.feedback(report)
    assert 'stop instead of requesting an RTL repair' in e.feedback(report)

def test_existing_output_is_preserved(tmp_path):
    p=tmp_path/'existing';p.mkdir();sentinel=p/'do_not_delete.txt';sentinel.write_text('preserve')
    try:e.run(2,p,2,1234,'unused',replay=[])
    except ValueError:pass
    else:assert False,'expected refusal of existing output'
    assert sentinel.read_text()=='preserve'

def test_failed_model_callback_is_counted_without_logging_secrets(tmp_path):
    def broken_client(prompt,repair):raise RuntimeError('private exception detail')
    out=tmp_path/'failed_callback'
    summary=e.run(2,out,1,1234,'unused',live=True,client=broken_client)
    assert summary['status']=='MODEL_ERROR' and summary['live_model_calls']==1
    assert summary['iterations']==1
    assert 'private exception detail' not in (out/'iter0/model_error.txt').read_text()
