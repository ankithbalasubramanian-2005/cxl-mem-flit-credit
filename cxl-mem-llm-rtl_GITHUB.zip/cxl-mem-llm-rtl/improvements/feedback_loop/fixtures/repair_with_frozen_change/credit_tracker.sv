module credit_tracker #(
  parameter int DIRECTION  = 0,
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) (
  input  logic       clk,
  input  logic       rst_n,
  input  logic [1:0] tx_send,
  output logic [6:0] tx_credits_0,
  output logic [6:0] tx_credits_1,
  output logic [1:0] can_send,
  input  logic       rx_crd_valid,
  input  logic [3:0] rx_reqcrd,
  input  logic [3:0] rx_datacrd,
  input  logic [3:0] rx_rspcrd,
  input  logic [1:0] buf_free,
  output logic [3:0] crd_req_field,
  output logic [3:0] crd_data_field,
  output logic [3:0] crd_rsp_field,
  input  logic       crd_taken,
  output logic       crd_pending,
  output logic [7:0] pend_0,
  output logic [7:0] pend_1
);

  logic [6:0] snd [0:1];
  logic [7:0] pend [0:1];

  assign tx_credits_0 = snd[0];
  assign tx_credits_1 = snd[1];
  assign can_send = {snd[1] != 0, snd[0] != 0};
  assign pend_0 = pend[0];
  assign pend_1 = pend[1];
  assign crd_pending = (pend[0] != 0) || (pend[1] != 0);

  function automatic logic [2:0] enc_credit(input logic [7:0] cnt);
    logic [2:0] c;
    begin
      if      (cnt >= 64) c = 3'd7;
      else if (cnt >= 32) c = 3'd6;
      else if (cnt >= 16) c = 3'd5;
      else if (cnt >=  8) c = 3'd4;
      else if (cnt >=  4) c = 3'd3;
      else if (cnt >=  2) c = 3'd2;
      else if (cnt >=  1) c = 3'd1;
      else                c = 3'd0;
      return c;
    end
  endfunction

  function automatic logic [7:0] dec_credit(input logic [2:0] code);
    logic [7:0] v;
    begin
      unique case (code)
        3'd0: v = 8'd0;
        3'd1: v = 8'd1;
        3'd2: v = 8'd2;
        3'd3: v = 8'd4;
        3'd4: v = 8'd8;
        3'd5: v = 8'd16;
        3'd6: v = 8'd32;
        3'd7: v = 8'd64;
        default: v = 8'd0;
      endcase
      return v;
    end
  endfunction

  logic [3:0] req_field_c, data_field_c, rsp_field_c;
  logic [7:0] pend0_val, pend1_val;

  always_comb begin
    if (DIRECTION == 0) begin
      pend0_val = pend[0];
      pend1_val = pend[1];
      req_field_c = 4'b0000;
      data_field_c = {1'b1, enc_credit(pend1_val)};
      rsp_field_c = {1'b1, enc_credit(pend0_val)};
    end else begin
      pend0_val = pend[0];
      pend1_val = pend[1];
      req_field_c = {1'b1, enc_credit(pend0_val)};
      data_field_c = {1'b1, enc_credit(pend1_val)};
      rsp_field_c = 4'b0000;
    end
  end

  assign crd_req_field = req_field_c;
  assign crd_data_field = data_field_c;
  assign crd_rsp_field = rsp_field_c;

  logic [6:0] snd_n [0:1];
  logic [7:0] pend_n [0:1];
  logic [8:0] snd_next_0, snd_next_1;
  logic [8:0] pend_add_0, pend_add_1;

  always_comb begin
    snd_next_0 = snd[0];
    snd_next_1 = snd[1];

    if (rx_crd_valid) begin
      if (DIRECTION == 0) begin
        if (rx_reqcrd[3]) snd_next_0 = snd_next_0 + dec_credit(rx_reqcrd[2:0]);
        if (rx_datacrd[3]) snd_next_1 = snd_next_1 + dec_credit(rx_datacrd[2:0]);
      end else begin
        if (rx_rspcrd[3]) snd_next_0 = snd_next_0 + dec_credit(rx_rspcrd[2:0]);
        if (rx_datacrd[3]) snd_next_1 = snd_next_1 + dec_credit(rx_datacrd[2:0]);
      end
    end

    if (tx_send[0] && snd[0] != 0) snd_next_0 = snd_next_0 - 1;
    if (tx_send[1] && snd[1] != 0) snd_next_1 = snd_next_1 - 1;

    snd_n[0] = (snd_next_0 > CREDIT_MAX) ? CREDIT_MAX : snd_next_0[6:0];
    snd_n[1] = (snd_next_1 > CREDIT_MAX) ? CREDIT_MAX : snd_next_1[6:0];

    // Return fields encode the OLD pending state. Keep all arithmetic wide,
    // subtract that returned amount, add a freed buffer, then saturate once.
    pend_add_0 = {1'b0, pend[0]};
    pend_add_1 = {1'b0, pend[1]};
    if (crd_taken) begin
      if (DIRECTION == 0) begin
        pend_add_0 = pend_add_0 - dec_credit(rsp_field_c[2:0]);
      end else begin
        pend_add_0 = pend_add_0 - dec_credit(req_field_c[2:0]);
      end
      pend_add_1 = pend_add_1 - dec_credit(data_field_c[2:0]);
    end
    pend_add_0 = pend_add_0 + {8'b0, buf_free[0]};
    pend_add_1 = pend_add_1 + {8'b0, buf_free[1]};
    pend_n[0] = (pend_add_0 > PEND_MAX) ? PEND_MAX : pend_add_0[7:0];
    pend_n[1] = (pend_add_1 > PEND_MAX) ? PEND_MAX : pend_add_1[7:0];
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      snd[0] <= 7'd0;
      snd[1] <= 7'd0;
      pend[0] <= RX_DEPTH;
      pend[1] <= RX_DEPTH;
    end else begin
      snd[0] <= snd_n[0];
      snd[1] <= snd_n[1];
      pend[0] <= pend_n[0];
      pend[1] <= pend_n[1];
    end
  end

endmodule
