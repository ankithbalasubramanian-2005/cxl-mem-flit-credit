# Optional assertion-and-synthesis-aware repair loop

This is a separate post-experiment extension. It leaves the original nine runs, judge, orchestrator source, and selected RTL unchanged.

A candidate must pass the original syntax/interface check, the uploaded frozen cocotb tests, the supplemental SystemVerilog assertion monitors, and the uniform synthesis flow. Every module is checked with DIRECTION=0 and 1. Per-module freezing begins only after all six module/direction gate results pass. Replies that try to change a frozen module are retained in raw_reply.txt but the passing module is restored before evaluation. Hash-identical frozen modules reuse their recorded checks within the same run and settings. Best-so-far failing modules are selected by number of failed gate checks, not by a fabricated failed-test count.

Feedback includes candidate output mismatches, assertion labels, and synthesis diagnostics. It does not include monitor source, Python golden-model source, a reference RTL implementation, or the manually corrected code as a suggested fix. Tool/runtime failures, missing/incomplete JUnit results, and timeouts stop as INCONCLUSIVE/BLOCKED_BY_TOOL rather than being relabeled as protocol defects. Every output directory must be new; existing results are preserved.

## Executed evidence

- `replays/original_then_repaired`: the original S2 run 2 passes functional simulation but is rejected for its credit assertions and D0 packer structural error. The next response is the stored manual repair, and it is accepted after all checks pass.
- `replays/freeze_protection`: a hybrid fixture starts with the passing S2 run 1 packer and the faulty S2 run 2 tracker. The next fixture attempts to replace the frozen packer with a different version. The loop ignores that change, preserves the original passing packer hash, and evaluates the repaired tracker.
- `replays/tool_failure_stop`: deliberately removes the compiler from PATH. The loop records BLOCKED_BY_TOOL and does not claim acceptance.
- `unit_tests.xml` and `unit_tests.log`: six guard tests cover missing/incomplete XML, actual test failures, compiler infrastructure failure, output preservation, and failed model-callback accounting.

The fixture directories combine stored code solely to test orchestration. They are not extra official runs, and none of these replays demonstrates that an LLM produced the manual repair. **No external model API calls were made.**

## Reproduce offline (from evidence-pack root)

Install Icarus Verilog on PATH and the pinned `requirements-verification.txt`. Choose fresh output paths:

```bash
python improvements/feedback_loop/enhanced_loop.py \
  --strategy 2 --max-iter 2 --yosys yowasp-yosys \
  --out feedback_replay \
  --replay synthesis_bundle/rtl/s2_final_run2 \
           improvements/repair_study/rtl/s2_run2_repair_candidate

python -m pytest improvements/feedback_loop/test_enhanced_loop.py -q
```

## Future live experiment (not executed in this study)

`--live` is explicit opt-in; it imports the original model client. That branch needs the original client's additional packages (`openai`, `httpx`, `python-dotenv`) and the `OPENROUTER_API_KEY` and `LLM_MODEL` environment variables. Do not put an API key in source control or a report. The free model route can change availability. The executed evidence validates offline orchestration, not provider authentication, live API availability, or live convergence rates.

Use a fresh experimental tag/directory and record model settings, retries, budgets and all gate versions for a future comparison. No original strategy success count should be changed on the basis of fixture replay.
