from pathlib import Path
import hashlib,json,re
from docx import Document
import fitz
R=Path(__file__).resolve().parent;B=R.parent.parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks={}
def check(k,v):
 checks[k]=bool(v)
 if not v:print('FAILED',k)
selection=read(R/'selection.json')
check('baseline_copies_match_uploaded_original_bytes',len(selection)==2 and all(sha(R/x['rtl'])==x['sha256'] and (R/x['rtl']).read_bytes()==(B/'original_archives'/f"baseline_{x['module']}.sv").read_bytes() for x in selection))
check('interface_check_pass',read(R/'interface_check.json')['ok'])
rows=read(R/'checks/summary.json');f=[x for x in rows if x['kind']=='frozen']
check('40_frozen_groups_620_executions_pass',len(f)==40 and sum(x['tests'] for x in f)==620 and all(x['status']=='PASS' and x['failures']==0 for x in f))
check('matching_ten_seeds_each_block_and_direction',all({x['seed'] for x in f if x['module']==m and x['direction']==d}==set(range(1234,1244)) for m in ['flit_packer','credit_tracker'] for d in [0,1]))
check('four_assertion_groups_pass',sum(x['kind']=='assertions' and x['status']=='PASS' for x in rows)==4)
check('both_credit_corner_cases_pass',sum(x['kind']=='corner' and x['status']=='PASS' for x in rows)==2)
syn=read(R/'synthesis/summary.json');check('four_synthesis_configurations_pass',len(syn)==4 and all(x['status']=='PASS' for x in syn))
raw=[]
for x in syn:
 d=R/'synthesis'/x['tag']/x['module']/f"D{x['direction']}";s=read(d/'stat.json')['modules']['\\'+x['module']]
 depth=int(re.search(r'length\s*=\s*(\d+)',(d/'ltp.txt').read_text()).group(1))
 raw.append(s['num_cells']==x['cells'] and depth==x['logic_depth'] and sha(d/'input.sv')==x['sha256'])
check('synthesis_metrics_match_raw_stats_and_source_hashes',all(raw))
check('same_tool_build_as_original_comparison',(R/'synthesis/tool_version.txt').read_bytes()==(B/'synthesis_fresh/tool_version.txt').read_bytes())
a=read(R/'synthesis/settings.json');b=read(B/'synthesis_fresh/settings.json')
check('same_flow_limits_and_unroll_setting',all(a[k]==b[k] for k in ['timeout','memory_mb','unroll_limit']))
c=read(R/'comparison.json');valid=[]
for x in c:
 ref=next(z for z in syn if z['module']==x['module'] and z['direction']==x['direction'])
 valid.append(abs(x['cell_delta_vs_baseline_pct']-100*(x['cells']-ref['cells'])/ref['cells'])<.0001 and x['depth_delta_levels']==x['logic_depth']-ref['logic_depth'])
check('comparison_ratios_and_depth_changes_correct',len(c)==16 and all(valid))
p=read(B/'improvements/repair_study/protected_original_hashes.json')
check('original_selected_RTL_and_judge_sources_unchanged',all(sha(B/k)==v for k,v in p.items()))
pdf=fitz.open(B/'CXL_Project_Handoff_v3.pdf');text='\n'.join(p.get_text() for p in pdf)
check('integrated_v3_includes_baseline_and_14_figures',len(Document(B/'CXL_Project_Handoff_v3.docx').inline_shapes)==14 and all(f'Figure {n}.' in text for n in range(1,15)) and 'Reference baseline received' in text)
report={'overall':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'summary':{'frozen_test_executions':620,'synthesis_configs_pass':4,'baseline_packer_cells_D0_D1':[9717,8877],'baseline_tracker_cells_D0_D1':[539,539],'baseline_packer_depth_D0_D1':[14,11],'baseline_tracker_depth_D0_D1':[36,36],'original_generation_sample_size':9,'user_baseline_authorship':'user-provided reference; no independent authorship assertion','pdf_pages':len(pdf)}}
(R/'BASELINE_AUDIT.json').write_text(json.dumps(report,indent=2));print('Baseline audit:',report['overall'],sum(checks.values()),'/',len(checks),'checks');assert all(checks.values())
