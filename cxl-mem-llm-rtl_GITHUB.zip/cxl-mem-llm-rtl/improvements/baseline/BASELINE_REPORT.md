
# Reference baseline: verification and hardware comparison

The user supplied `credit_tracker.sv` and `flit_packer.sv` as the project baseline. Their headers identify them as the known-good reference used for testbench validation. For this report they are attributed as the **user-provided reference baseline**; authorship is not independently established. Source bytes were copied unchanged, and SHA-256 hashes are recorded in `improvements/baseline/provenance.json`.

This baseline was added after the original generation experiments. No archived generation prompts, original run results, or generated RTL were changed. No new model generation was performed using these files. The baseline and manual repair remain separate from the original n=9 sample.

## Validation under matching settings

| Check | Result |
| --- | --- |
| Original syntax/interface checker | Pass |
| Frozen regression, seeds 1234–1243 | 40/40 groups pass; 620 test executions; zero failures |
| Supplemental assertions | 4/4 module/direction groups pass |
| Supplemental saturation/drain test using original golden model | 2/2 directions pass |
| Uniform synthesis | 4/4 module/direction configurations pass |

The same uploaded judge, assertion monitors, pinned Yosys/slang build, generic mapping gate set, structural checks, and depth command were used. Parameters remain MAX_CHUNKS=8, RX_DEPTH=16, CREDIT_MAX=64, PEND_MAX=255; both DIRECTION values are tested. Full logs, JUnit XML, scripts and source hashes are retained under `improvements/baseline/`. The six assertion/mutation checks reported earlier were not rerun against new mutants; the baseline uses the already validated monitors.

## Baseline measurements

| Module | Direction | Generic cells | FF | Latches | Depth |
| --- | --- | --- | --- | --- | --- |
| credit_tracker | 0 | 539 | 30 | 0 | 36 |
| credit_tracker | 1 | 539 | 30 | 0 | 36 |
| flit_packer | 0 | 9717 | 1547 | 0 | 14 |
| flit_packer | 1 | 8877 | 1547 | 0 | 11 |


## Comparison with functionally validated candidates

Only the original S1 run 3 and S2 run 1 candidates, plus the separately repaired S2 run 2 copy, are compared here. All pass their completed verification and synthesis checks. Earlier tables retain all nine original designs and their failure labels.

A positive cell delta means more generic cells than the baseline; a negative delta means fewer. Depth differences are cell-path levels, not time or Fmax. All measurements synthesize modules separately and do not establish the timing or area of a physically integrated controller.

| Design | Module / dir | Cells | Change vs reference | Depth | Depth change |
| --- | --- | --- | --- | --- | --- |
| S1 run 3 | Packer D0 | 9674 | -0.44% | 20 | +6 |
| S1 run 3 | Packer D1 | 9319 | +4.98% | 17 | +6 |
| S1 run 3 | Tracker D0 | 547 | +1.48% | 35 | -1 |
| S1 run 3 | Tracker D1 | 547 | +1.48% | 35 | -1 |
| S2 run 1 | Packer D0 | 8538 | -12.13% | 15 | +1 |
| S2 run 1 | Packer D1 | 8508 | -4.16% | 16 | +5 |
| S2 run 1 | Tracker D0 | 617 | +14.47% | 31 | -5 |
| S2 run 1 | Tracker D1 | 617 | +14.47% | 31 | -5 |
| S2 run 2 repaired | Packer D0 | 13499 | +38.92% | 25 | +11 |
| S2 run 2 repaired | Packer D1 | 12430 | +40.02% | 25 | +14 |
| S2 run 2 repaired | Tracker D0 | 450 | -16.51% | 28 | -8 |
| S2 run 2 repaired | Tracker D1 | 450 | -16.51% | 28 | -8 |


![Figure 13. Generic packer cell count and topological depth relative to the verified user-provided baseline.](figures/flit_packer_baseline_comparison.png)

![Figure 14. Tracker tradeoffs for the same validated candidates; the manually repaired copy remains a separate case study.](figures/credit_tracker_baseline_comparison.png)



## What the baseline comparison supports

The S2 run 1 packer uses 8,538 versus 9,717 generic cells in D0 (12.13% fewer), and 8,508 versus 8,877 in D1 (4.16% fewer). Its depth is 15 versus 14 in D0 and 16 versus 11 in D1. Thus its lower mapped cell count comes with longer topological paths in this flow.

The S2 run 1 tracker uses 617 versus 539 cells (14.47% more), while depth is 31 versus 36. S1 run 3 uses nearly the same D0 packer count as the baseline, a larger D1 packer count, and greater packer depth in both directions. The repaired S2 run 2 tracker uses fewer cells and lower depth than the baseline, while its packer is substantially larger and deeper. These are implementation-specific tradeoffs, not a universal ranking of prompting strategies.

No physical area, clock frequency, power, or technology-mapped timing saving is claimed. The original prompt comparison still has only three runs per strategy. The baseline strengthens the hardware comparison, but does not increase that experimental sample.

## Reproduce the baseline checks

From the extracted evidence-pack root, with Icarus Verilog on PATH and the pinned verification dependencies installed:

```bash
python improvements/baseline/run_baseline_checks.py --out baseline_checks_repeat
python improvements/baseline/run_synthesis.py --yosys yowasp-yosys \
  --out synthesis_repeat --timeout 120
```

Use new output directories. The comparison data is available in `improvements/baseline/comparison.csv` and `.json`. Plot and report generation are reproduced by `document_tools/build_handoff_v3.py` with the document-generation dependencies.

## Updated report-ready conclusion

The user-provided reference baseline passed the same 620 frozen-test executions, supplemental assertion and credit-corner checks, and four synthesis configurations as the validated candidates. Relative to that reference, the observed S2 run 1 packer used 12.13% fewer generic cells in D0 and 4.16% fewer in D1, with longer topological paths in both directions; its tracker used more cells with lower depth. The comparison therefore exposes a block-specific cell-count/depth tradeoff. The original nine-run convergence counts, the separately validated manual repair, and the offline-only feedback-loop evidence remain unchanged. Technology-mapped timing, physical area, power, and improved live LLM convergence remain future work.
