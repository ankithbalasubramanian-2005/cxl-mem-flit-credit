#!/usr/bin/env python3
"""Sequential, reproducible synthesis of the 36 selected configurations (Linux/WSL)."""
import argparse,csv,hashlib,json,os,re,shlex,signal,subprocess,time
from pathlib import Path

BASE=Path(__file__).resolve().parent

def execute(cmd, log, cwd, seconds, memory_mb):
    start=time.monotonic(); status=None; peak=0
    with log.open('w') as f:
        p=subprocess.Popen(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        while p.poll() is None:
            # Sum RSS of Yosys and descendants in its private process group.
            ps=subprocess.run(['ps','-eo','pgid=,rss='],capture_output=True,text=True)
            rss=sum(int(v[1]) for line in ps.stdout.splitlines() if len(v:=line.split())==2 and int(v[0])==p.pid)
            peak=max(peak,rss)
            if time.monotonic()-start>seconds: status='TIMEOUT'
            elif memory_mb and rss>memory_mb*1024: status='MEMORY_LIMIT'
            if status:
                try: os.killpg(p.pid,signal.SIGKILL)
                except ProcessLookupError: pass
                break
            time.sleep(.25)
        rc=p.wait()
    return status or ('PASS' if rc==0 else 'ERROR'),round(time.monotonic()-start,2),round(peak/1024,1)

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--yosys',default=os.environ.get('YOSYS','yosys'))
    ap.add_argument('--timeout',type=int,default=300,help='seconds per configuration')
    ap.add_argument('--memory-mb',type=int,default=3072,help='process-group RSS limit; 0 disables')
    ap.add_argument('--out',default='runs')
    ap.add_argument('--filter',default='',help='substring of tag/module/Dn')
    ap.add_argument('--unroll-limit',type=int,default=4000)
    args=ap.parse_args(); out=(BASE/args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    ys=shlex.split(args.yosys)
    # New releases embed slang; older OSS CAD Suite releases load it as a plugin.
    plugin=[]
    probe=subprocess.run(ys+['-Q','-T','-p','help read_slang'],capture_output=True,text=True)
    if probe.returncode or 'Read SystemVerilog sources' not in probe.stdout:
        plugin=['-m','slang']
        probe=subprocess.run(ys+plugin+['-Q','-T','-p','help read_slang'],capture_output=True,text=True)
    (out/'frontend_help.txt').write_text(probe.stdout+probe.stderr)
    if probe.returncode or 'Read SystemVerilog sources' not in probe.stdout:
        raise SystemExit('read_slang unavailable. Activate your OSS CAD Suite environment.')
    version=subprocess.run(ys+plugin+['-T','-p','slang_version'],capture_output=True,text=True)
    (out/'tool_version.txt').write_text(version.stdout+version.stderr)
    (out/'settings.json').write_text(json.dumps(vars(args),indent=2))
    rows=[]
    for selected in json.loads((BASE/'selection.json').read_text()):
        for direction in [0,1]:
            name=f"{selected['tag']}/{selected['module']}/D{direction}"
            if args.filter not in name: continue
            d=out/selected['tag']/selected['module']/f'D{direction}';d.mkdir(parents=True,exist_ok=True)
            src=BASE/selected['rtl']; data=src.read_bytes()
            if hashlib.sha256(data).hexdigest()!=selected['sha256']: raise SystemExit(f'RTL changed: {src}')
            # Copy under a simple local name, so paths with spaces never enter Yosys commands.
            (d/'input.sv').write_bytes(data); top=selected['module']
            script=f'''read_slang -j 1 input.sv --top {top} -G DIRECTION={direction} --unroll-limit {args.unroll_limit}
proc
opt
check -assert
tee -o elaboration.txt stat
synth -flatten -noabc -top {top}
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
check -assert
tee -o stat.json stat -json
tee -o stat.txt stat
tee -o ltp.txt ltp -noff
write_verilog -noattr netlist.v
'''
            (d/'synth.ys').write_text(script)
            # Reject reused output directories to prevent stale success artifacts.
            if (d/'yosys.log').exists(): raise SystemExit(f'Output already exists: {d}; choose a new --out directory.')
            print('RUN',name,flush=True)
            status,elapsed,peak=execute(ys+plugin+['-T','-s','synth.ys'],d/'yosys.log',d,args.timeout,args.memory_mb)
            row={**selected,'direction':direction,'status':status,'phase':'synthesis' if (d/'elaboration.txt').exists() else 'elaboration', 'cells':'','flipflops':'','latches':'','logic_depth':'','seconds':elapsed,'peak_rss_mb':peak,'log':str((d/'yosys.log').relative_to(out)),'error':''}
            if status=='PASS':
                stats=json.loads((d/'stat.json').read_text())
                mods=stats['modules']; mod=mods.get('\\'+top,mods.get(top))
                if mod is None: raise RuntimeError(f'Missing top in stat: {top}')
                types=mod['num_cells_by_type']
                row.update(cells=mod['num_cells'],flipflops=sum(v for k,v in types.items() if 'DFF' in k.upper()),latches=sum(v for k,v in types.items() if 'LATCH' in k.upper()))
                match=re.search(r'length\s*=\s*(\d+)',(d/'ltp.txt').read_text())
                if match: row['logic_depth']=int(match[1])
            else:
                lines=(d/'yosys.log').read_text(errors='replace').splitlines()
                row['error']=next((x[:500] for x in lines if re.search(r'\berror\b',x,re.I)),status)
                full_log='\n'.join(lines)
                if status=='ERROR':
                    if 'wasm trap: call stack exhausted' in full_log:
                        row['status']='TOOL_RUNTIME_ERROR'
                        row['error']='YoWASP runtime: wasm trap: call stack exhausted'
                    elif "problems in 'check -assert'" in full_log:
                        row['status']='STRUCTURAL_ERROR'
                    else:
                        row['status']='FRONTEND_ERROR' if row['phase']=='elaboration' else 'SYNTHESIS_ERROR'
            rows.append(row)
            with (out/'summary.csv').open('w',newline='') as f:
                w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
            print(row['status'],'cells=',row['cells'],'depth=',row['logic_depth'],row['error'],flush=True)
    (out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(f'Completed {len(rows)} configurations; summary: {out / "summary.csv"}')

if __name__=='__main__': main()
