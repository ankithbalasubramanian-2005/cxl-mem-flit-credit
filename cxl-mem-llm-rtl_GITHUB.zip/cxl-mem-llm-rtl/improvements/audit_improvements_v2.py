#!/usr/bin/env python3
"""Audit final repair, waveform, acceptance, and optional-loop evidence."""
import bisect,hashlib,importlib.util,json,zipfile
import xml.etree.ElementTree as ET
from pathlib import Path

I=Path(__file__).resolve().parent;B=I.parent;R=I/'repair_study';L=I/'feedback_loop'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks={}
def check(name,value):
    checks[name]=bool(value)
    if not value:print('FAILED:',name)
protected=read(R/'protected_original_hashes.json')
check('protected_RTL_and_judge_sources_unchanged',all(sha(B/p)==h for p,h in protected.items()))
with zipfile.ZipFile(B/'original_archives/orchestrator.zip') as z:
    names=[n for n in z.namelist() if n.endswith('.py')]
    check('uploaded_original_orchestrator_sources_unchanged',all(z.read(n)==(B/'original_project'/n).read_bytes() for n in names))
repair=read(R/'checks/summary.json');frozen=[x for x in repair if x['kind']=='frozen']
check('repair_40_groups_620_frozen_tests_pass',len(frozen)==40 and sum(x['tests'] for x in frozen)==620 and all(x['status']=='PASS' and x['failures']==0 for x in frozen))
check('repair_all_four_assertion_groups_pass',sum(x['kind']=='assertions' and x['status']=='PASS' for x in repair)==4)
check('repair_both_golden_corner_tests_pass',sum(x['kind']=='corner' and x['status']=='PASS' for x in repair)==2)
synth=read(R/'synthesis/summary.json')
check('repair_four_synthesis_configs_pass',len(synth)==4 and all(x['status']=='PASS' for x in synth))
check('repair_synthesis_uses_recorded_candidate_hashes',all(sha(R/x['rtl'])==x['sha256'] for x in synth))
spec=importlib.util.spec_from_file_location('wave_reader',R/'make_waveforms.py');wave_reader=importlib.util.module_from_spec(spec);spec.loader.exec_module(wave_reader)
wave=read(R/'waveforms/summary.json');valid=[]
for w in wave:
    d=R/'waveforms'/f"D{w['direction']}";traces=wave_reader.parse_vcd(d/'credit_repair.vcd')
    def value(name):
        changes=traces[name];index=bisect.bisect_right([x[0] for x in changes],w['event_ns'])-1
        return changes[index][1]
    valid.append(sha(d/'credit_repair.vcd')==w['vcd_sha256'] and value('before_pend_0')==value('before_pend_1')==191 and value('after_pend_0')==value('after_pend_1')==value('expected_pending')==192 and value('returned_credits')==64)
check('both_VCDs_confirm_original_191_repaired_192',len(valid)==2 and all(valid))
check('original_acceptance_counts_stay_4_3_2_of_9',[x['passing_designs'] for x in read(I/'acceptance_stages.json')]==[4,3,2])
first=L/'replays/original_then_repaired';h=read(first/'history.json');g=read(first/'iter0/gates.json')
check('enhanced_loop_rejects_original_despite_functional_pass',len(h)==2 and not h[0]['accepted'] and all(x['status']=='PASS' for r in g['modules'].values() for x in r['checks'] if x['gate']=='functional') and not g['modules']['credit_tracker']['passed'] and not g['modules']['flit_packer']['passed'])
check('enhanced_loop_accepts_manually_repaired_fixture',h[-1]['accepted'] and read(first/'summary.json')['status']=='ACCEPTED')
freeze=L/'replays/freeze_protection';h=read(freeze/'history.json')
check('fully_passing_module_freeze_is_enforced',h[0]['module_states']['flit_packer']['passed'] and h[1]['module_states']['flit_packer']['reused'] and h[1]['ignored_changes_to_frozen_modules']==['flit_packer'] and sha(freeze/'accepted_rtl/flit_packer.sv')==sha(B/'synthesis_bundle/rtl/s2_final_run1/flit_packer.sv'))
stop=L/'replays/tool_failure_stop'
check('missing_compiler_stops_without_acceptance',read(stop/'summary.json')['status']=='BLOCKED_BY_TOOL' and not (stop/'accepted_rtl').exists())
names=['original_then_repaired','freeze_protection','tool_failure_stop']
check('published_replays_match_final_loop_source',all(read(L/'replays'/n/'summary.json')['loop_source_sha256']==sha(L/'enhanced_loop.py') for n in names))
check('published_replays_make_no_live_model_calls',all(read(L/'replays'/n/'summary.json')['mode']=='offline_fixture_replay' and read(L/'replays'/n/'summary.json')['live_model_calls']==0 for n in names))
nodes=ET.parse(L/'unit_tests.xml').getroot().findall('.//testcase')
check('six_focused_guard_tests_pass',len(nodes)==6 and all(x.find('failure') is None and x.find('error') is None for x in nodes))
check('baseline_pending_is_explicit',(I/'BASELINE_PENDING.md').exists())
from docx import Document
import fitz
doc=Document(B/'CXL_Project_Handoff_v2.docx');pdf=fitz.open(B/'CXL_Project_Handoff_v2.pdf')
check('integrated_Word_contains_twelve_figures',len(doc.inline_shapes)==12)
text='\n'.join(p.get_text() for p in pdf)
check('PDF_contains_new_sections_and_twelve_captions',all(f'Figure {n}.' in text for n in range(1,13)) and 'Completed manual repair study' in text and 'Live model improvement' in text)
report={'overall':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'summary':{'protected_RTL_judge_files':len(protected),'original_orchestrator_source_files':len([p for p in (B/'original_project/orchestrator').glob('*.py')]),'repair_frozen_test_executions':620,'repair_synthesis_pass':4,'offline_accepting_replays':2,'missing_tool_replay':'BLOCKED_BY_TOOL','guard_tests':6,'external_model_calls_in_replays':0,'baseline':'pending original reference RTL','pdf_pages':len(pdf),'Word_figures':len(doc.inline_shapes)}}
(I/'IMPROVEMENTS_CHECKS_V2.json').write_text(json.dumps(report,indent=2))
print('Improvements audit:',report['overall'],sum(checks.values()),'/',len(checks),'checks')
raise SystemExit(0 if all(checks.values()) else 1)
