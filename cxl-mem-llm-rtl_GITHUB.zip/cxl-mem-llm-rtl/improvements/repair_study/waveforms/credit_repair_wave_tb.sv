`timescale 1ns/1ps
module credit_repair_wave_tb;
parameter integer DIRECTION=0;
reg clk=0,rst_n=0;always #5 clk=~clk;
reg [1:0] tx_send=0,buf_free=0;
reg rx_crd_valid=0,crd_taken=0;
reg [3:0] rx_reqcrd=0,rx_datacrd=0,rx_rspcrd=0;
reg [7:0] expected_pending=16;
integer expected_next;
function automatic integer returned_value(input integer p);
  if(p>=64)returned_value=64;
  else if(p>=32)returned_value=32;
  else if(p>=16)returned_value=16;
  else if(p>=8)returned_value=8;
  else if(p>=4)returned_value=4;
  else if(p>=2)returned_value=2;
  else if(p>=1)returned_value=1;
  else returned_value=0;
endfunction
always @(posedge clk) begin
  if(!rst_n)expected_pending<=16;
  else begin
    expected_next=expected_pending-(crd_taken?returned_value(expected_pending):0)+buf_free[0];
    expected_pending<=expected_next>255?255:expected_next;
  end
end
wire [6:0] before_tx_credits_0;
wire [6:0] before_tx_credits_1;
wire [1:0] before_can_send;
wire [3:0] before_crd_req_field;
wire [3:0] before_crd_data_field;
wire [3:0] before_crd_rsp_field;
wire [0:0] before_crd_pending;
wire [7:0] before_pend_0;
wire [7:0] before_pend_1;
credit_tracker_before #(.DIRECTION(DIRECTION)) before_dut (.clk(clk), .rst_n(rst_n), .tx_send(tx_send), .rx_crd_valid(rx_crd_valid), .rx_reqcrd(rx_reqcrd), .rx_datacrd(rx_datacrd), .rx_rspcrd(rx_rspcrd), .buf_free(buf_free), .crd_taken(crd_taken), .tx_credits_0(before_tx_credits_0), .tx_credits_1(before_tx_credits_1), .can_send(before_can_send), .crd_req_field(before_crd_req_field), .crd_data_field(before_crd_data_field), .crd_rsp_field(before_crd_rsp_field), .crd_pending(before_crd_pending), .pend_0(before_pend_0), .pend_1(before_pend_1));
wire [6:0] after_tx_credits_0;
wire [6:0] after_tx_credits_1;
wire [1:0] after_can_send;
wire [3:0] after_crd_req_field;
wire [3:0] after_crd_data_field;
wire [3:0] after_crd_rsp_field;
wire [0:0] after_crd_pending;
wire [7:0] after_pend_0;
wire [7:0] after_pend_1;
credit_tracker #(.DIRECTION(DIRECTION)) after_dut (.clk(clk), .rst_n(rst_n), .tx_send(tx_send), .rx_crd_valid(rx_crd_valid), .rx_reqcrd(rx_reqcrd), .rx_datacrd(rx_datacrd), .rx_rspcrd(rx_rspcrd), .buf_free(buf_free), .crd_taken(crd_taken), .tx_credits_0(after_tx_credits_0), .tx_credits_1(after_tx_credits_1), .can_send(after_can_send), .crd_req_field(after_crd_req_field), .crd_data_field(after_crd_data_field), .crd_rsp_field(after_crd_rsp_field), .crd_pending(after_crd_pending), .pend_0(after_pend_0), .pend_1(after_pend_1));
wire [7:0] returned_credits = crd_taken && before_crd_data_field[3]
  ? (before_crd_data_field[2:0]==0 ? 0 : (1 << (before_crd_data_field[2:0]-1))) : 0;
task tick;begin @(posedge clk);#1;@(negedge clk);end endtask
initial begin
  $dumpfile("credit_repair.vcd");$dumpvars(0,credit_repair_wave_tb);$dumpoff;
  tick();rst_n=1;buf_free=3;
  repeat(235)tick();
  $dumpon;
  repeat(4)tick();
  assert(before_pend_0==255 && after_pend_0==255 && expected_pending==255)
    else $fatal(1,"WAVE_SETUP_FAILED");
  crd_taken=1;tick();
  $display("DIRECTION=%0d BEFORE=%0d AFTER=%0d EXPECTED=%0d",DIRECTION,before_pend_0,after_pend_0,expected_pending);
  assert(before_pend_0==191 && before_pend_1==191)else $fatal(1,"NEGATIVE_CONTROL_CHANGED");
  assert(after_pend_0==192 && after_pend_1==192 && expected_pending==192)
    else $fatal(1,"REPAIR_FAILED");
  crd_taken=0;buf_free=0;repeat(3)tick();
  $display("PASS: original counterexample and repaired result captured together");$finish;
end
initial begin #100000;$fatal(1,"TB_TIMEOUT");end
endmodule
