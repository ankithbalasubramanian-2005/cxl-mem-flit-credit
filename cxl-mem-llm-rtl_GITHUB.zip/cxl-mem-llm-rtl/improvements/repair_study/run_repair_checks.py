#!/usr/bin/env python3
"""Validate only the isolated manual repair. No official RTL/judge is modified."""
import argparse,csv,json,os,signal,subprocess,sys,time
import xml.etree.ElementTree as ET
from pathlib import Path
R=Path(__file__).resolve().parent
B=R.parent.parent
TAG='s2_run2_repair_candidate'

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=R/'checks')
    ap.add_argument('--corner-one',type=int,choices=[0,1])
    args=ap.parse_args();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    if args.corner_one is not None:
        from cocotb_tools.runner import get_runner
        direction=args.corner_one
        sys.path[:0]=[str(B/'original_project'),str(B/'verification')]
        d=out/'corner'/f'D{direction}';d.mkdir(parents=True,exist_ok=True)
        runner=get_runner('icarus')
        runner.build(sources=[R/'rtl'/TAG/'credit_tracker.sv'],hdl_toplevel='credit_tracker',parameters={'DIRECTION':direction},build_args=['-g2012'],build_dir=d/'build',timescale=('1ns','1ps'),log_file=d/'build.log')
        runner.test(test_module='credit_corner_cocotb',hdl_toplevel='credit_tracker',seed=1234,build_dir=d/'build',test_dir=d,results_xml=str(d/'results.xml'),extra_env={'TB_DIRECTION':str(direction),'TB_SEED':'1234','TB_RX_DEPTH':'16'})
        return
    if (out/'summary.json').exists():raise SystemExit('Output already exists. Choose a fresh --out directory.')
    rows=[]
    def execute(kind,module,direction,seed,cmd,log,xml=None,expected_tests=None):
        start=time.monotonic();log.parent.mkdir(parents=True,exist_ok=True)
        with log.open('w') as f:
            p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
            try:rc=p.wait(timeout=180)
            except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();rc=None
        tests=failures=None
        if xml is not None and xml.exists():
            nodes=ET.parse(xml).getroot().findall('.//testcase');tests=len(nodes)
            failures=sum(n.find('failure') is not None or n.find('error') is not None for n in nodes)
            passed=rc==0 and failures==0 and tests==expected_tests
        else:passed=xml is None and rc==0
        row={'kind':kind,'module':module,'direction':direction,'seed':seed,'status':'PASS' if passed else ('TIMEOUT' if rc is None else 'FAIL'),'tests':tests,'failures':failures,'returncode':rc,'seconds':round(time.monotonic()-start,2),'log':str(log.relative_to(out))};rows.append(row)
        (out/'summary.json').write_text(json.dumps(rows,indent=2))
        print(kind,module,f'D{direction}',f'seed={seed}',row['status'],f'tests={tests}',flush=True)
    for module in ['flit_packer','credit_tracker']:
        for direction in [0,1]:
            for seed in range(1234,1244):
                d=out/'frozen'/TAG/module/f'D{direction}'
                cmd=[sys.executable,str(B/'verification/run_frozen_regression.py'),'--rtl-root',str(R),'--project',str(B/'original_project'),'--out',str(out/'frozen'),'--one',TAG,module,str(direction),str(seed)]
                execute('frozen',module,direction,seed,cmd,d/f'seed{seed}.log',d/f'seed{seed}.xml',21 if module=='flit_packer' else 10)
    for module in ['flit_packer','credit_tracker']:
        for direction in [0,1]:
            d=out/'assertions';d.mkdir(exist_ok=True)
            top='packer_assert_tb' if module=='flit_packer' else 'credit_assert_tb'
            net=d/f'{module}_D{direction}.vvp'
            cmd=['iverilog','-g2012','-s',top,'-P',f'{top}.DIRECTION={direction}','-o',str(net),str(R/'rtl'/TAG/f'{module}.sv'),str(B/'verification'/f'{module}_assertions.sv'),str(B/'verification'/f'{top}.sv')]
            c=subprocess.run(cmd,capture_output=True,text=True,timeout=30);(d/f'{module}_D{direction}.compile.log').write_text(c.stdout+c.stderr)
            if c.returncode:raise RuntimeError(c.stderr)
            execute('assertions',module,direction,None,['vvp',str(net)],d/f'{module}_D{direction}.log')
            net.unlink()
    for direction in [0,1]:
        d=out/'corner'/f'D{direction}'
        execute('corner','credit_tracker',direction,1234,[sys.executable,str(Path(__file__).resolve()),'--out',str(out),'--corner-one',str(direction)],d/'sim.log',d/'results.xml',1)
    with (out/'summary.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    (out/'settings.json').write_text(json.dumps({'study':'post-experiment manual repair, not a tenth official generation run','seeds':list(range(1234,1244)),'frozen_tests':'uploaded test modules and Python golden models unchanged','assertions':'same supplemental monitors and deterministic seeds as original validation','timeout_seconds':180,'sources':'rtl/'+TAG},indent=2))
    print('Repair validation:',sum(x['status']=='PASS' for x in rows),'/',len(rows),'groups pass',flush=True)
    raise SystemExit(0 if all(x['status']=='PASS' for x in rows) else 1)
if __name__=='__main__':main()
