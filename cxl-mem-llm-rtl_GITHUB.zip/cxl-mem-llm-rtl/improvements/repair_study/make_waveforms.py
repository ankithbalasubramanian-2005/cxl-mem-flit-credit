#!/usr/bin/env python3
"""Capture genuine side-by-side VCD traces, then plot values read from the VCD."""
import argparse,bisect,hashlib,json,os,re,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
B=R.parent.parent
TAG='s2_run2_repair_candidate'

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,default=R/'waveforms')
    args=ap.parse_args();out=args.out.resolve();out.mkdir(parents=True,exist_ok=True)
    original=B/'synthesis_bundle/rtl/s2_final_run2/credit_tracker.sv'
    source=original.read_text();assert source.count('module credit_tracker #(')==1
    (out/'credit_tracker_before.sv').write_text('// Mechanical module-name-only change for side-by-side simulation.\n'+source.replace('module credit_tracker #(','module credit_tracker_before #(',1))
    inputs=['clk','rst_n','tx_send','rx_crd_valid','rx_reqcrd','rx_datacrd','rx_rspcrd','buf_free','crd_taken']
    ports={'tx_credits_0':7,'tx_credits_1':7,'can_send':2,'crd_req_field':4,'crd_data_field':4,'crd_rsp_field':4,'crd_pending':1,'pend_0':8,'pend_1':8}
    tb='''`timescale 1ns/1ps
module credit_repair_wave_tb;
parameter integer DIRECTION=0;
reg clk=0,rst_n=0;always #5 clk=~clk;
reg [1:0] tx_send=0,buf_free=0;
reg rx_crd_valid=0,crd_taken=0;
reg [3:0] rx_reqcrd=0,rx_datacrd=0,rx_rspcrd=0;
reg [7:0] expected_pending=16;
integer expected_next;
function automatic integer returned_value(input integer p);
  if(p>=64)returned_value=64;
  else if(p>=32)returned_value=32;
  else if(p>=16)returned_value=16;
  else if(p>=8)returned_value=8;
  else if(p>=4)returned_value=4;
  else if(p>=2)returned_value=2;
  else if(p>=1)returned_value=1;
  else returned_value=0;
endfunction
always @(posedge clk) begin
  if(!rst_n)expected_pending<=16;
  else begin
    expected_next=expected_pending-(crd_taken?returned_value(expected_pending):0)+buf_free[0];
    expected_pending<=expected_next>255?255:expected_next;
  end
end
'''
    for prefix,module in [('before','credit_tracker_before'),('after','credit_tracker')]:
        for name,width in ports.items():tb+=f'wire [{width-1}:0] {prefix}_{name};\n'
        conn=[f'.{x}({x})' for x in inputs]+[f'.{x}({prefix}_{x})' for x in ports]
        tb+=module+' #(.DIRECTION(DIRECTION)) '+prefix+'_dut ('+', '.join(conn)+');\n'
    tb+='''wire [7:0] returned_credits = crd_taken && before_crd_data_field[3]
  ? (before_crd_data_field[2:0]==0 ? 0 : (1 << (before_crd_data_field[2:0]-1))) : 0;
task tick;begin @(posedge clk);#1;@(negedge clk);end endtask
initial begin
  $dumpfile("credit_repair.vcd");$dumpvars(0,credit_repair_wave_tb);$dumpoff;
  tick();rst_n=1;buf_free=3;
  repeat(235)tick();
  $dumpon;
  repeat(4)tick();
  assert(before_pend_0==255 && after_pend_0==255 && expected_pending==255)
    else $fatal(1,"WAVE_SETUP_FAILED");
  crd_taken=1;tick();
  $display("DIRECTION=%0d BEFORE=%0d AFTER=%0d EXPECTED=%0d",DIRECTION,before_pend_0,after_pend_0,expected_pending);
  assert(before_pend_0==191 && before_pend_1==191)else $fatal(1,"NEGATIVE_CONTROL_CHANGED");
  assert(after_pend_0==192 && after_pend_1==192 && expected_pending==192)
    else $fatal(1,"REPAIR_FAILED");
  crd_taken=0;buf_free=0;repeat(3)tick();
  $display("PASS: original counterexample and repaired result captured together");$finish;
end
initial begin #100000;$fatal(1,"TB_TIMEOUT");end
endmodule
'''
    (out/'credit_repair_wave_tb.sv').write_text(tb)
    records=[]
    for direction in [0,1]:
        d=out/f'D{direction}';d.mkdir(exist_ok=True);net=d/'wave.vvp'
        cmd=['iverilog','-g2012','-s','credit_repair_wave_tb','-P',f'credit_repair_wave_tb.DIRECTION={direction}','-o',str(net),str(out/'credit_tracker_before.sv'),str(R/'rtl'/TAG/'credit_tracker.sv'),str(out/'credit_repair_wave_tb.sv')]
        c=subprocess.run(cmd,capture_output=True,text=True,timeout=30);(d/'compile.log').write_text(c.stdout+c.stderr);assert c.returncode==0,c.stderr
        v=subprocess.run(['vvp',str(net)],cwd=d,capture_output=True,text=True,timeout=30);(d/'sim.log').write_text(v.stdout+v.stderr);assert v.returncode==0,v.stdout+v.stderr
        print(v.stdout,flush=True);net.unlink()
        trace=parse_vcd(d/'credit_repair.vcd')
        event=next(t for t,value in trace['before_pend_0'] if value==191)
        row={'direction':direction,'original':191,'repaired':192,'expected':192,'event_ns':event,'status':'PASS','original_source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'repaired_source_sha256':hashlib.sha256((R/'rtl'/TAG/'credit_tracker.sv').read_bytes()).hexdigest(),'vcd_sha256':hashlib.sha256((d/'credit_repair.vcd').read_bytes()).hexdigest()};records.append(row)
        (d/'parsed_top_signals.json').write_text(json.dumps(trace,indent=2))
        plot_trace(trace,event,direction,d)
    (out/'summary.json').write_text(json.dumps(records,indent=2))

def parse_vcd(path):
    raw=path.read_text();header,body=raw.split('$enddefinitions $end',1)
    unit=re.search(r'\$timescale\s+(\d+)\s*(s|ms|us|ns|ps|fs)\s+\$end',header)
    assert unit,'missing timescale'
    scale=int(unit.group(1))*{'s':1e9,'ms':1e6,'us':1e3,'ns':1,'ps':1e-3,'fs':1e-6}[unit.group(2)]
    scope=[];ids={};trace={}
    for line in header.splitlines():
        words=line.split()
        if not words:continue
        if words[0]=='$scope':scope.append(words[2])
        elif words[0]=='$upscope':scope.pop()
        elif words[0]=='$var' and scope==['credit_repair_wave_tb']:
            name=words[4];ids.setdefault(words[3],[]).append(name);trace[name]=[]
    t=0
    for line in body.splitlines():
        line=line.strip()
        if not line:continue
        if line.startswith('#'):t=int(line[1:])*scale;continue
        if line[0] in 'bB':
            val,code=line[1:].split();value=None if any(c in val.lower() for c in 'xz') else int(val,2)
        elif line[0] in '01xXzZ':code=line[1:];value=int(line[0]) if line[0] in '01' else None
        else:continue
        for name in ids.get(code,[]):trace[name].append([t,value])
    return trace

def plot_trace(trace,event,direction,d):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    t=np.arange(event-45,event+25.25,.25)
    def sample(name):
        changes=trace[name];times=[x[0] for x in changes]
        vals=[]
        for x in t:
            i=bisect.bisect_right(times,x)-1;v=changes[i][1] if i>=0 else None
            vals.append(float('nan') if v is None else v)
        return np.array(vals)
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,axes=plt.subplots(6,1,figsize=(11,8),sharex=True,gridspec_kw={'height_ratios':[.65,.65,.65,.8,1.6,1.2]})
    names=['clk','buf_free','crd_taken','returned_credits'];labels=['clk','buf_free[0]','crd_taken','Returned credits']
    for ax,name,label in zip(axes[:4],names,labels):
        values=sample(name);values=(values.astype(float)%2 if name=='buf_free' else values)
        ax.step(t,values,where='post',color='#274b67',linewidth=1.5);ax.set_ylabel(label,rotation=0,ha='right',va='center',labelpad=12)
        ax.set_yticks([0,64] if name=='returned_credits' else [0,1]);ax.set_ylim(-3,70) if name=='returned_credits' else ax.set_ylim(-.15,1.15)
    for ax in axes[4:]:
        ax.step(t,sample('expected_pending'),where='post',color='#2b3e50',linestyle=':',linewidth=2.4,label='Expected contract')
        ax.step(t,sample('before_pend_0'),where='post',color='#bd4d40',linewidth=1.8,label='Original RTL')
        ax.step(t,sample('after_pend_0'),where='post',color='#168376',linewidth=1.8,label='Repaired RTL')
    axes[4].set_ylabel('Pending ch0');axes[4].set_ylim(180,260);axes[4].legend(loc='lower left',frameon=False,ncol=3,fontsize=9)
    axes[4].annotate('255 before edge',xy=(event-.25,255),xytext=(event-30,233),arrowprops={'arrowstyle':'->','color':'#496276'})
    axes[5].set_ylim(190,193);axes[5].set_yticks([191,192]);axes[5].set_ylabel('After-edge zoom')
    axes[5].text(event+4,191.18,'Original: 191 (one credit lost)',color='#bd4d40',fontsize=10)
    axes[5].text(event+4,192.18,'Repaired = expected: 192',color='#168376',fontsize=10)
    for ax in axes:
        ax.axvline(event,color='#aa7834',linestyle='--',alpha=.8);ax.grid(axis='x',alpha=.13);ax.set_xlim(t[0],t[-1])
    axes[-1].set_xlabel('Simulation time (ns); dashed line marks the simultaneous drain/free edge')
    fig.suptitle(f'Credit-counter repair: genuine VCD trace, DIRECTION={direction}',x=.16,ha='left',fontsize=15,fontweight='bold')
    fig.text(.16,.925,'min(255 - 64 + 1, 255) = 192; both DUTs receive identical inputs',fontsize=10,color='#41596b')
    fig.subplots_adjust(left=.19,right=.98,top=.89,bottom=.09,hspace=.23)
    for ext in ['png','svg','pdf']:fig.savefig(d/f'before_after_waveform.{ext}',dpi=220)
    plt.close(fig)

if __name__=='__main__':main()
