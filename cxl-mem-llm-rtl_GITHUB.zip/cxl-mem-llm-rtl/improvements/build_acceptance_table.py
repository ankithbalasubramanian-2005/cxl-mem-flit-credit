#!/usr/bin/env python3
"""Summarize post-experiment gates; do not add the repaired candidate to n=9."""
import csv,json
from pathlib import Path
I=Path(__file__).resolve().parent
B=I.parent
def read(p):return json.loads((B/p).read_text())
def main():
    official=read('evidence/official_runs.json');frozen=read('frozen_regression/summary.json');assertions=read('assertion_results/summary.json');synth=read('synthesis_fresh/summary.json')
    rows=[]
    for run in official:
        tag=run['tag'];f=[x for x in frozen if x['tag']==tag and x['seed']==1234]
        a=[x for x in assertions if x['label']==tag and not x['mutant']]
        s=[x for x in synth if x['tag']==tag]
        fp=len(f)==4 and all(x['status']=='PASS' for x in f)
        ap=len(a)==4 and all(x['status']=='PASS' for x in a)
        sp=len(s)==4 and all(x['status']=='PASS' for x in s)
        rows.append({'strategy':run['strategy'],'run':run['run'],'tag':tag,'frozen_pass':fp,'assertions_pass':ap,'synthesis_pass':sp,'frozen_and_assertions':fp and ap,'all_three_gates':fp and ap and sp})
    stages=[{'stage':'Frozen judge','passing_designs':sum(x['frozen_pass'] for x in rows),'denominator':9},
            {'stage':'Frozen judge + assertions','passing_designs':sum(x['frozen_and_assertions'] for x in rows),'denominator':9},
            {'stage':'Frozen judge + assertions + synthesis','passing_designs':sum(x['all_three_gates'] for x in rows),'denominator':9}]
    for name,data in [('per_design_acceptance',rows),('acceptance_stages',stages)]:
        (I/f'{name}.json').write_text(json.dumps(data,indent=2))
        with (I/f'{name}.csv').open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=data[0]);w.writeheader();w.writerows(data)
    assert [x['passing_designs'] for x in stages]==[4,3,2]
    (I/'acceptance_stages.md').write_text('| Cumulative acceptance stage | Passing original designs |\n| --- | --- |\n'+''.join(f"| {x['stage']} | {x['passing_designs']}/9 |\n" for x in stages)+'\nThe manually repaired copy is a separate post-experiment case study, not an additional original sample. Counts refer to observed tests and this synthesis flow, not formal proof or full protocol compliance.\n')
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax=plt.subplots(figsize=(8.5,4));values=[x['passing_designs'] for x in stages]
    labels=['Frozen judge','+ supplemental\nassertions','+ synthesis, both modules\nand both directions']
    bars=ax.bar(labels,values,color=['#466c90','#2b8581','#173d51'],width=.55)
    for bar,n in zip(bars,values):ax.text(bar.get_x()+bar.get_width()/2,n+.13,f'{n}/9',ha='center',fontweight='bold',fontsize=13)
    ax.set_ylim(0,5);ax.set_yticks(range(6));ax.set_ylabel('Original designs passing cumulative gates');ax.set_title('Post-experiment acceptance stages',loc='left',fontweight='bold',fontsize=15)
    ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',alpha=.17);ax.set_axisbelow(True)
    fig.text(.12,.015,'Original sample stays n=9. Repaired candidate is reported separately.',fontsize=9,color='#486071')
    fig.tight_layout(rect=(0,.045,1,1));figs=I/'figures';figs.mkdir(exist_ok=True)
    for ext in ['png','svg','pdf']:fig.savefig(figs/f'acceptance_stages.{ext}',dpi=220)
    plt.close(fig)
    print('Acceptance stages:',[f"{x['passing_designs']}/9" for x in stages])
if __name__=='__main__':main()
