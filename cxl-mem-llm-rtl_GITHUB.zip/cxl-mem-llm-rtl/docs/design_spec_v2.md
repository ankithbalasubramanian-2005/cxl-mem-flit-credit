# CXL.mem Link-Layer Design Specification (v2)

**Project:** M2S/S2M Flit Packing and LLCRD Credit-Based Flow Control
**Source authority:** *Compute Express Link Specification, Revision 2.0, Version 1.0 (October 26, 2020)*. Every section / table / figure number below refers to that document; "p.N" is the printed page number (equal to the PDF page number in this edition).
**Status:** v2 — audited against the CXL 2.0 spec. Items marked **PROJECT DECISION – APPROVED** were not defined by the CXL spec and were approved on 2026-10-11 (see `SPEC_DECISIONS_NEEDED.md`). Changes from v1 are logged in `SPEC_CHANGELOG.md`.

**Layer note.** Both blocks in this project are **Link Layer** functions (CXL 2.0 Chapter 4, §4.2 "CXL.mem and CXL.cache Common Link Layer"). Chapter 3 (Transaction Layer, §3.3) defines *what* the CXL.mem messages are — their fields and opcodes; Chapter 4 defines *how* those messages are packed into 528-bit flits and how credits are returned. We use Chapter 3 only as the source of message field tables and opcode encodings; the behavior we design and verify is Chapter 4's.

---

## 1. Flit Structure (§4.2.2, p.119; Figures 46, 47)

"The CXL.cache/mem flit size is a fixed 528b. There are 2B of CRC code and 4 slots of 16B each" (§4.2.2, p.119).

```
528 bits = 66 bytes = 4 slots x 16 B (512 b) + 2 B CRC (16 b)
```

| Slot | Role (§4.2.2, p.119–120) |
|---|---|
| Slot 0 | **Header Slot** — the 32-bit flit header plus up to 96 bits of message content (H formats) |
| Slots 1–3 | **Generic Slots** — "one or more request/response messages or a single 16B data chunk" (G formats) |

A flit is either a Header Slot + 3 Generic Slots, **or four 16B data chunks** (all-data flit, §4.2.2 p.120, Figure 47).

**"68B" naming.** At the Physical Layer "a 16-bit Protocol ID field is associated with each 528-bit flit payload (512 bits of payload + 16 bits of CRC)" (§6.2.1, p.181). 66 B flit + 2 B Protocol ID = 68 B. This project uses "flit" for the 66-byte (528-bit) unit; the Protocol ID is outside the DUT.

### 1.1 Flit Header (Table 45, p.120; bit positions from Figures 53, 54, 66, 67, 68)

Present in every protocol flit; 32 bits; occupies **Slot 0 bytes 0–3** contiguously.

| Field | Bits | Slot-0 bit position | Purpose |
|---|---|---|---|
| Type | 1 | [0] | 0 = Protocol, 1 = Control (Table 46) |
| RV (reserved) | 1 | [1] | Reserved, sent as 0 |
| Ak | 1 | [2] | Ack of 8 flits (retry protocol) — **tied to 0** in this project (simplification #11) |
| BE | 1 | [3] | Byte-Enable slot follows the data of the data message begun in this flit (§4.2.2 p.121) |
| Sz | 1 | [4] | 1 = full cacheline (4 data chunks), 0 = half (2 chunks) (§4.2.2 p.121) |
| Slot0 | 3 | [7:5] | Slot 0 format (Table 50) |
| Slot1 | 3 | [10:8] | Slot 1 format |
| Slot2 | 3 | [13:11] | Slot 2 format |
| Slot3 | 3 | [16:14] | Slot 3 format (figures label [1:0] in byte 1 bits 6–7 and "Sl3" = Slot3[2] in byte 2 bit 0) |
| RSVD | 3 | [19:17] | Reserved, sent as 0 |
| RspCrd | 4 | [23:20] | Response credit return |
| ReqCrd | 4 | [27:24] | Request credit return |
| DataCrd | 4 | [31:28] | Data credit return |
| **Total** | **32** | | (Table 45 lists RSVD = 4 = RV[1] + RSVD[19:17]) |

Note: Table 45 lists the fields in the order Type, Ak, BE, Sz, ReqCrd, DataCrd, RspCrd, Slot0–3, RSVD — that is **not** the bit order. The bit order above is read from the slot figures (Figure 53/54 for M2S, Figure 66/68 for S2M; all identical in bytes 0–3).

### 1.2 Credit Return Encoding (Table 48, p.122)

Each credit field is 4 bits:

| Bit | Meaning |
|---|---|
| [3] | Protocol select: **0 = CXL.cache, 1 = CXL.mem** |
| [2:0] | Number of credits, exponential: |

| [2:0] | 000 | 001 | 010 | 011 | 100 | 101 | 110 | 111 |
|---|---|---|---|---|---|---|---|---|
| Credits | 0 | 1 | 2 | 4 | 8 | 16 | 32 | 64 |

"Credits returned for channels not supported by the device or host should be silently discarded." (§4.2.2 p.121). Granularity is per message; a data message consumes **one** data credit regardless of 64B/32B/BE (§4.2.2 p.121 Note).

### 1.3 Channel Mapping (Table 49, p.122) and who returns credit

In Table 49 the "Link Direction" column names the direction of the **channel being credited**, not the direction of the flit that carries the credit. Evidence: §4.2.2 p.121 — "The transmitter sets the Credit Return fields to indicate resources available in the co-located receiver for use by the remote transmitter" — and Table 49 marks CXL.mem ReqCrd/Upstream and RspCrd/Downstream as *Reserved*, exactly the channels that do not exist (no S2M request, no M2S response).

| Credit field (bit3 = 1, CXL.mem) | Channel credited | Channel data flows | Credit is returned by | Carried on flits going |
|---|---|---|---|---|
| ReqCrd | M2S Req | Downstream (Host→Device) | Device | Upstream (S2M flits) |
| DataCrd | M2S RwD | Downstream | Device | Upstream (S2M flits) |
| DataCrd | S2M DRS | Upstream (Device→Host) | Host | Downstream (M2S flits) |
| RspCrd | S2M NDR | Upstream | Host | Downstream (M2S flits) |
| ReqCrd on M2S flits / RspCrd on S2M flits | Reserved for CXL.mem | — | — | sent as 4'b0000 (§8.4) |

"It is the responsibility of the Rx to transmit credits to the sender using standard credit return mechanisms after link initialization" (§4.2.7, p.146).

### 1.4 Data Chunks, Sz and BE (§4.2.2 p.121; Table 47; Figure 57)

- Sz = 1 → "the link layer Rx expects four slots of data chunks, corresponding to a full cacheline"; Sz = 0 → two chunks (§4.2.2 p.121).
- Table 47 (legal values): **CXL.mem M2S Data — 32B transfer: No; BE: Yes. CXL.mem S2M Data — 32B transfer: Yes; BE: No.** Therefore RwD always uses Sz = 1. In this project DRS also always uses Sz = 1 (simplification #15).
- BE = 0 → Rx regenerates all byte enables as ones. BE = 1 → "the link layer Rx expects an additional data chunk slot containing byte enable information … this will always be the last slot of data for the associated request" (§4.2.2 p.121). The byte-enable chunk format is **G0 – M2S Byte Enable** (Figure 57, p.129): BE[31:0] in slot bytes 0–3, BE[63:32] in bytes 4–7, bytes 8–15 RSVD.
- "the Tx flit packer may begin at most one data message per flit" (§4.2.2 p.121).
- Chunks are sent in cacheline order 0,1,2,3 (§4.2.5 p.140).

| Message | Data chunks (incl. BE chunk) |
|---|---|
| M2S Req (MemRd, MemRdData) | 0 |
| M2S RwD MemWr (Sz=1, BE=0) | 4 |
| M2S RwD MemWrPtl (Sz=1, BE=1) | 5 = 4 data + 1 BE (**PROJECT DECISION – APPROVED, D7**) |
| S2M NDR (Cmp) | 0 |
| S2M DRS MemData (Sz=1) | 4 |

### 1.5 Rollover Rules (§4.2.5, p.139)

"Rollover is defined as any time a data transfer needs more than one flit." A 128-bit G0 data chunk "can only be scheduled in Slots 1, 2, and 3 of a protocol flit since Slot 0 has only 96b available".

| Rollover chunks remaining | Rule (verbatim meaning, §4.2.5 p.139) |
|---|---|
| > 3 | The next flit **must** be an all-data flit (all 4 slots are data chunks). |
| = 3 | Slots 1, 2, 3 **must** contain the 3 rollover chunks. Slot 0 is packed independently (may hold the Data Header of the next transfer). |
| = 2 | Slots 1, 2 **must** contain the 2 rollover chunks. Slots 0 and 3 are packed independently. |
| = 1 | Slot 1 **must** contain the rollover chunk. Slots 0, 2, 3 are packed independently. |
| 0 | Each of the 4 slots is packed independently. |

Related rules (§4.2.5 p.140):
- "If a valid Data Header is packed in a given slot, the next available slot for data transfer (Slot 1, Slot 2, Slot 3 or an all-data flit) will be guaranteed to have data associated with the header."
- "Control flits cannot be interleaved with all-data flits … when an all-data flit is expected following a protocol flit (due to Rollover), the Tx cannot send a Control flit before the all-data flit."
- "For non-MDH containing flits, there can be at most 1 valid Data Header in that flit."
- A multi-data-header (MDH) slot format (e.g. S2M H5) "must be chosen by the Tx only if there is more than 1 valid Data Header to pack in that slot", and only with BE = 0, Sz = 1.

Real traffic in this project produces rollover of **1** (MemWr, MemData: 4 chunks, 3 fit in the first flit) or **2** (MemWrPtl: 5 chunks). Rollover 0, 3 and >3 are reachable only through the testbench override `data_chunks_total` (simplification #10).

### 1.6 All-Data Flit (Figure 47, p.119; note on p.120)

Four 128-bit data chunks occupying slots 0–3 plus the 16-bit CRC. **No header region**: no Type, Ak, credit or slot-format fields. The p.120 text notes that an "all-data-flit can alias to control messages after a CRC error", confirming that it carries no Type bit of its own. Credits cannot be piggybacked on an all-data flit.

---

## 2. Slot Formats In Scope (§4.2.3; Tables 50, 51, 52)

### 2.1 Slot format selector encoding (Table 50, p.123)

| Encoding | M2S Slot 0 | M2S Slots 1–3 | S2M Slot 0 | S2M Slots 1–3 |
|---|---|---|---|---|
| 000 | H0 | **G0 (data chunk)** | H0 | **G0 (data chunk)** |
| 011 | H3 | G3 | **H3** | G3 |
| 100 | **H4** | G4 | H4 | G4 |
| 101 | **H5** | G5 | H5 | G5 |

### 2.2 Formats used

| Direction | Format | Content | Size (bits) | Source |
|---|---|---|---|---|
| M2S | **H4** (100) | M2S RwD Header | 87 | Table 51, Figure 53 (p.127) |
| M2S | **H5** (101) | M2S Req | 87 | Table 51, Figure 54 (p.127) |
| S2M | **H3** (011) | S2M DRS Header + S2M NDR | 70 | Table 52, Figure 66 (p.133) |
| both | **G0** (000) | Data chunk | 128 | Tables 51/52, Figures 56, 69 |
| M2S | **G0** (000) | M2S Byte Enable chunk | 128 | Figure 57 (p.129) |

Defined by the spec but **not used** under this project's packing policy (§8.6): S2M H4 (2×NDR, 60 b, Figure 67 — first NDR is bit-split around the second), S2M H5 (2×DRS, 80 b, Figure 68 — an MDH format, illegal with only one DRS, §4.2.5 p.140).

### 2.3 M2S Req — Table 29 (p.94), layout Figure 54 (H5)

| Field | Bits | Slot-0 bit position (Fig. 54) | Notes |
|---|---|---|---|
| Valid | 1 | [32] | |
| MemOpcode | 4 | [36:33] | Table 30 |
| SnpType | 3 | [39:37] | Fixed No-Op `000` (simplification #4) |
| MetaField | 2 | [41:40] | Fixed No-Op `11` (simplification #3; Table 31) |
| MetaValue | 2 | [43:42] | `00` (don't-care when MetaField = No-Op) |
| Tag | 16 | [59:44] | |
| Address[51:5] | 47 | [106:60] | Addr[5] "provisioned for future usages" (Table 29) |
| TC | 2 | [108:107] | "reserved for future usage" — sent as 0 |
| LD-ID[3:0] | 4 | [112:109] | Fixed 0 (simplification #2). Figure shows LD-ID[2:0] + "LI3" = LD-ID[3]; contiguous |
| RSVD | 6 | [118:113] | 0 |
| **Total** | **87** | [118:32] | Pad [127:119] = 9 bits of 0 |

Note: the field order in the slot (Figure 54) differs from the row order of Table 29 — SnpType precedes MetaField.

### 2.4 M2S RwD — Table 35 (p.97), layout Figure 53 (H4)

| Field | Bits | Slot-0 bit position (Fig. 53) |
|---|---|---|
| Valid | 1 | [32] |
| MemOpcode | 4 | [36:33] (Table 36) |
| SnpType | 3 | [39:37] — `000` |
| MetaField | 2 | [41:40] — `11` |
| MetaValue | 2 | [43:42] — `00` |
| Tag | 16 | [59:44] |
| Address[51:6] | 46 | [105:60] |
| Poison | 1 | [106] |
| TC | 2 | [108:107] — 0 |
| LD-ID[3:0] | 4 | [112:109] — 0 |
| RSVD | 6 | [118:113] — 0 |
| **Total** | **87** | [118:32]; pad [127:119] = 0 |

RwD carries Address[51:6] only; address bit 5 of the request **must not appear** anywhere in an RwD header.

### 2.5 S2M DRS — Table 41 (p.100), layout Figure 66 (H3, first message)

| Field | Bits | Slot-0 bit position (Fig. 66) |
|---|---|---|
| Valid | 1 | [32] |
| Opcode | 3 | [35:33] (Table 42) |
| MetaField | 2 | [37:36] — `11` |
| MetaValue | 2 | [39:38] — `00` |
| Tag | 16 | [55:40] |
| Poison | 1 | [56] |
| LD-ID[3:0] | 4 | [60:57] — 0 |
| DevLoad | 2 | [62:61] — `00` |
| RSVD | 9 | [71:63] (RV bit 63 + byte 8) |
| **Total** | **40** | [71:32] |

### 2.6 S2M NDR — Table 38 (p.98–99), layout Figure 66 (H3, second message)

| Field | Bits | Slot-0 bit position (Fig. 66) |
|---|---|---|
| Valid | 1 | [72] |
| Opcode | 3 | [75:73] (Table 39) |
| MetaField | 2 | [77:76] — `11` |
| MetaValue | 2 | [79:78] — `00` |
| Tag | 16 | [95:80] |
| LD-ID[3:0] | 4 | [99:96] — 0 |
| DevLoad | 2 | [101:100] — `00` |
| **Total** | **30** | [101:72]; RSVD/pad [127:102] = 0 |

H3 total = 40 + 30 = 70 (Table 52). For S2M, the figure order equals the table row order.

---

## 3. Opcodes In Scope

| Channel | Opcode | Encoding | Source |
|---|---|---|---|
| M2S Req | `MemRd` | `0001` | Table 30, p.95 |
| M2S Req | `MemRdData` | `0010` | Table 30, p.95 |
| M2S RwD | `MemWr` | `0001` | Table 36, p.98 |
| M2S RwD | `MemWrPtl` | `0010` | Table 36, p.98 ("Contains 64 byte enables, one for each byte of data") |
| S2M NDR | `Cmp` | `000` | Table 39, p.99 ("Completions for Writebacks, Reads and Invalidates") |
| S2M DRS | `MemData` | `000` | Table 42, p.100 |

`Cmp-S` (`001`) and `Cmp-E` (`010`) exist (Table 39) but are coherence-state indications, out of scope. **There is no `MemWrCmp` opcode in CXL 2.0** — a full-text search of all 628 pages finds no occurrence of "MemWrCmp" or "WrCmp". Table 37 (p.98) shows the NDR response to MemWr/MemWrPtl is `Cmp`.

---

## 4. Credit-Based Flow Control (§4.2.2 p.121, §4.2.6 p.141, §4.2.7 p.146, §4.2.8.2 p.149)

### 4.1 Primary mechanism: piggybacked credit return
Every protocol flit header carries ReqCrd/DataCrd/RspCrd. The receiver of a channel accumulates credits to return (one per freed buffer) and packs them, exponentially encoded, into the next header it transmits. The sender of a channel decrements its credit counter by 1 per message sent and may not send when the counter is 0. Sender credit counters **must be saturating** (§4.2.7 p.146: "it is therefore required that the credit counters at the sender be saturating").

### 4.2 Fallback mechanism: LLCRD control flit (§4.2.6; Tables 53, 54; Figure 78)
LLCRD is a control flit (Type = 1, CTL_FMT = `000`, LLCTRL = `0000`) "containing only link layer QoS Telemetry, credit return and/or Ack information, but no protocol information" (Table 53, p.141). Only Slot 0 is valid; Slots 1–3 are reserved (Figure 78, p.144). Its credit fields sit at the same bit positions as in a protocol header. Exact layout in §8.5.

"Link Layer Control flits do not follow flow control rules applicable to protocol flits. That is, they can be sent from an entity without any credits." (§4.2.6 p.141). "Immediately after link initialization, the credit exchange mechanism will use the LLCRD flit format" (§4.2.7 p.146).

### 4.3 LLCRD forcing — what the spec says and what this project models
The spec (§4.2.8.2, p.149) defines two forcing triggers: (a) a programmable number of pending **Acks** (recommended threshold ≥ 16), and (b) a timer that clears whenever an Ack/credit-carrying message is sent and increments every cycle while "any Credit value to return is greater than 0 or Acknowledge to return is greater than 1"; when it reaches a programmed threshold, an LLCRD is forced.

**This project's model:**
- Trigger (a) does not exist: Ak is tied to 0 and no Acks are tracked (simplification #11).
- Trigger (b)'s **timer is outside the DUT**. The testbench (standing in for the timer) drives the `force_llcrd` input. `force_llcrd` is latched by the packer.
- The only condition that makes an LLCRD meaningful is "credits pending to return > 0"; the credit_tracker exposes this as `crd_pending`.
- Injection point: an LLCRD is emitted only at a flit boundary where no rollover is in progress; at such a boundary a latched `force_llcrd` takes priority over a pending message (simplification #9; §4.2.5 p.140: control flits cannot be interleaved with all-data flits).

---

## 5. Simplifications (documented, with justification)

| # | Simplification | Justification |
|---|---|---|
| 1 | Single virtual channel / single message class | Multi-VC arbitration is a scheduling problem orthogonal to flit-packing/credit correctness, which is this project's focus. |
| 2 | LD-ID always 0 | Multi-Logical-Device support (§2.4, p.44) is a separate feature; not needed to show flit/credit correctness. |
| 3 | MetaField = No-Op (`11`), MetaValue = `00` | Meta0-State tracking belongs to the coherence model, outside the CXL.mem-link-layer scope (Table 31). |
| 4 | SnpType = No-Op (`000`) | Snoop semantics depend on the DCOH; out of scope (Table 33). |
| 5 | DevLoad = Light Load (`00`) | QoS throttling is a performance feature, not a packing-correctness requirement (Table 40). |
| 6 | LLCRD forcing timer/threshold not implemented in the DUT; the testbench drives a latched `force_llcrd` input | §4.2.8.2's threshold/timer values are register-programmable tuning; this project verifies that an LLCRD carries the right credits and is injected at a legal point. |
| 7 | "68B flit" used informally for the 528-bit flit + 2B Protocol ID | Common usage; spec calls it a 528-bit flit (§4.2.2) with the Protocol ID added by the Physical Layer (§6.2.1, p.181). |
| 8 | No `MemWrCmp`; write completion = NDR `Cmp` | `MemWrCmp` does not occur anywhere in the CXL 2.0 spec; Table 37 shows `Cmp` as the NDR for MemWr/MemWrPtl. |
| 9 | LLCRD never interrupts a rollover; it is injected only at a flit boundary with no rollover active, and there it takes priority over a newly pending message | §4.2.5 p.140: "Control flits cannot be interleaved with all-data flits … the Tx cannot send a Control flit before the all-data flit." The LLCRD format (Figure 78) has only Slot 0 valid, so it cannot carry rollover chunks either. |
| 10 | Rollover tests use an injectable `data_chunks_total` override, decoupled from the chunk count implied by the message | Real traffic only produces rollover 1 (4-chunk messages) or 2 (MemWrPtl with BE chunk); rollover 0, 3 and >3 can only be exercised through this testbench-only override. |
| 11 | `Ak` tied to 0; no Ack accounting | Ak drives the Link Layer Retry state machine (§4.2.8.1); retry is out of scope. |
| 12 | credit_tracker accumulates a raw pending count and drains it by greedy largest-representable-first decomposition across successive return opportunities | Table 48's values are 0 and powers of two up to 64, so any count drains exactly (binary decomposition, at most 64 per field per flit). A pending count of e.g. 3 cannot be sent in one field. |
| 13 | Slot 0 = 32-bit header in bits [31:0], then the message, then zero pad | This **is** the spec layout: Figures 53, 54, 66 place the header contiguously in bytes 0–3 and the message from bit 32. Message field positions follow the figures exactly (§2.3–2.6). |
| 14 | `flit_packer` has a distinct `flit_is_alldata` output, separate from `flit_is_control` | An all-data flit has no header (Figure 47) and cannot be identified from its own bits. |
| 15 | DRS is always a full 64B line (Sz = 1); no 32B half-line transfers | Table 47 permits 32B for S2M, but half-line transfers add a second data header per line; full-line transfers suffice to verify packing and rollover. RwD is always Sz = 1 per Table 47. — **APPROVED** |
| 16 | One message per flit, carried in Slot 0; the other message position in Slot 0 has Valid = 0; Slots 1–3 carry only data chunks | Keeps the packer's expected output fully deterministic for the judge testbench; legal per §4.2.5 (empty message positions have Valid = 0). — **APPROVED (D6)** |
| 17 | S2M single messages both use H3 (DRS in the first position, NDR in the second; the unused one has Valid = 0); S2M H4/H5 unused | H5 is an MDH format and is illegal with one DRS (§4.2.5 p.140); H4 splits the first NDR's bits (Figure 67). H3 holds either message contiguously. — **APPROVED (D6)** |
| 18 | CRC field driven as 16'h0000 | CRC generation/checking is Physical/retry scope, excluded. — **APPROVED (D3)** |
| 19 | Credit fields in use are sent as `{1'b1, enc[2:0]}` (CXL.mem select bit always 1, even for 0 credits); fields reserved for the direction are 4'b0000 | Table 48 bit 3 = 1 selects CXL.mem; Table 49 marks the other fields Reserved, and RSVD bits "should be set to 0" (p.120). — **APPROVED (D4)** |
| 20 | Credit counters: sender counters reset to 0 and are filled by returned credits; receiver pending-return counters reset to the receive-buffer depth; all counters saturate at CREDIT_MAX = 64 (sender) / PEND_MAX = 255 (pending) | Follows §4.2.7 p.146 (Rx sets its credit return counters to its buffer count; sender counters saturate). Widths are project choices. — **APPROVED (D8)** |
| 21 | One RTL module per block with a `DIRECTION` parameter (0 = M2S/host side, 1 = S2M/device side) | Both directions share the header, rollover and LLCRD logic; only slot formats and credit-field roles differ. — **APPROVED (D9)** |

**FSM behavior note (simplification #9):** `force_llcrd` is latched. If asserted during a rollover sequence, the packer completes that sequence and evaluates the LLCRD at the next flit boundary with no rollover active. At such a boundary, if the latch and a pending message are both set, the LLCRD flit is emitted first and normal packing resumes on the following flit. During an all-data flit, credit piggyback is structurally impossible (no header), which independently forces the same behavior.

---

## 6. Worked Example — Single `MemRd` Transaction

1. **Host → Device, M2S flit (Slot0 = H5 `101`):** header Type=0, Ak=0, BE=0, Sz=0 (no data message in this flit), Slot1–3 = empty-slot encoding (§8.6); credit fields per §8.4. Message: `Valid=1, MemOpcode=0001, SnpType=000, MetaField=11, MetaValue=00, Address[51:5]=<addr>, Tag=<TID>, TC=00, LD-ID=0000`.
2. The host's sender counter for **M2S Req** decrements by 1.
3. **Device → Host, S2M flit (Slot0 = H3 `011`):** header Type=0, Sz=1, BE=0, Slot1–3 = G0 `000`. DRS message: `Valid=1, Opcode=000 (MemData), MetaField=11, MetaValue=00, Tag=<TID>, Poison=0, LD-ID=0, DevLoad=00`; NDR position Valid=0. Slots 1–3 carry data chunks 0, 1, 2.
4. **Next S2M flit:** rollover of 1 → Slot 1 carries chunk 3 (§4.2.5 rule "= 1"). Slots 0, 2, 3 are packed independently (empty under this example).
5. The device's sender counter for **S2M DRS** decrements by 1 when the DRS is sent.
6. Credit returns (§4.2.7):
   - Device (Rx of M2S Req) returns the Req credit in **ReqCrd** of an S2M header it sends, e.g. `ReqCrd = 4'b1001` (CXL.mem, 1 credit) in the flit of step 3.
   - Host (Rx of S2M DRS) returns the DRS credit in **DataCrd** of an M2S header (`4'b1001`), or via an LLCRD if the testbench asserts `force_llcrd` while the link is otherwise idle.

This trace is reproduced field-by-field by a directed test (test plan, group A).

---

## 7. Scope boundary

**In scope:** CXL 2.0 Link Layer (§4.2) for CXL.mem only; single VC; M2S Req/RwD and S2M NDR/DRS; opcodes `MemRd`, `MemRdData`, `MemWr`, `MemWrPtl`, `Cmp`, `MemData`; LLCRD control-flit credit return.

**Out of scope:** CXL.cache and CXL.io; multiple message classes; CXL 3.0 256B flit; BISnp coherence; Physical Layer, link training, Link Layer Retry, CRC/FEC; multi-device pooling / MLD.

---

## 8. Interface and Bit-Level Definitions

Legend: **[A]** = defined by the CXL 2.0 spec (citation given). **[B] PROJECT DECISION – APPROVED** = not defined by the spec; proposed default, listed in `SPEC_DECISIONS_NEEDED.md`.

### 8.1 Bit order of fields — [A]
§4.2.5 p.141: "For a given slot, lower bit positions are defined as bit positions that appear starting from lower order Byte #. That is, bits are ordered starting from (Byte 0, Bit 0) through (Byte 15, Bit 7)." and "less significant bits will appear in lower order bit positions." Slot bit index = 8 × byte + bit. Field positions are taken from the figures and listed in §1.1 and §2.3–2.6. Header in [31:0], message from [32], zero pad on top.

### 8.2 `flit_out` layout — [A] with [B] packaging
Flit byte *n* (Figure 46 numbering, bytes 0–65) maps to `flit_out[8n+7:8n]`, so Slot *k* = `flit_out[128k+127:128k]` and CRC = `flit_out[527:512]`. Message ordering follows flit bit numbering (§4.2.5 p.141). Representing the flit as one 528-bit bus is a project choice **[B, D2]**.

### 8.3 CRC — [B] PROJECT DECISION – APPROVED (D3)
`flit_out[527:512] = 16'h0000` for every flit. CRC is excluded scope.

### 8.4 Slot-format selectors and credit fields — [A] + [B]
- Selectors [A, Table 50]: M2S Req → Slot0 `101` (H5); M2S RwD → Slot0 `100` (H4); S2M DRS/NDR → Slot0 `011` (H3); data or BE chunk in Slots 1–3 → `000` (G0).
- Credit select bit [A, Table 48]: bit 3 = 1 means CXL.mem.
- [B, D4] Fields carried per direction:

| Flit direction | ReqCrd | DataCrd | RspCrd |
|---|---|---|---|
| M2S (host sends) | 4'b0000 (reserved) | `{1, enc(DRS credits)}` | `{1, enc(NDR credits)}` |
| S2M (device sends) | `{1, enc(M2S Req credits)}` | `{1, enc(RwD credits)}` | 4'b0000 (reserved) |

- [B, D4] Sz/BE in a protocol flit that **begins** a data message: Sz = 1, BE = 1 only for MemWrPtl. In a protocol flit that begins no data message: Sz = 0, BE = 0.
- [B, D6] Empty Slot 0 message positions: all bits of the unused message = 0 (Valid = 0). Empty Generic Slots (no data chunk scheduled): 128 bits of 0, with selector M2S `100` (G4, mem Req + cache DH) / S2M `101` (G5, 2×NDR) — both formats whose content is all Valid=0 messages, i.e. "slots without any valid bits set" (§4.2.5 p.140). Selector `000` (G0) is **not** used for an empty slot because G0 has no Valid bit.
- [B, D6] A protocol flit with no message in Slot 0 (e.g. a rollover-only flit) uses Slot0 = H5 (M2S) / H3 (S2M) with all message bits 0.

### 8.5 LLCRD control flit layout — [A] (Figure 78 p.144; Tables 53, 54 p.141)

| Slot-0 bits | Field | Value |
|---|---|---|
| [0] | Type | 1 |
| [1] | RV | 0 |
| [2] | Ak | 0 (tied) |
| [4:3] | RSVD | 0 |
| [7:5] | CTL_FMT | `000` |
| [15:8] | RSVD | 0 |
| [19:16] | RSVD | 0 |
| [23:20] | RspCrd | per §8.4 |
| [27:24] | ReqCrd | per §8.4 |
| [31:28] | DataCrd | per §8.4 |
| [35:32] | LLCTRL | `0000` (LLCRD) |
| [39:36] | SubType | `0000` [B, D5] (`0001` = Acknowledge is unused because no Acks are returned) |
| [63:40] | bytes 5–7 | `0x0` (shown as "0x0" in Figure 78) |
| [127:64] | Payload[63:0] | 0 (SubType 0000 payload is RSVD, Table 54) |
| Slots 1–3 | Reserved | 0 |
| CRC | | 16'h0000 (D3) |

### 8.6 Packing policy — [B] PROJECT DECISION – APPROVED (D6)
1. At most one new message per flit, placed in Slot 0 (M2S: H5 for Req, H4 for RwD; S2M: H3 with DRS in the first position or NDR in the second).
2. Slots 1–3 carry only data chunks (G0) or are empty (§8.4).
3. Data chunks fill "the next available slot for data transfer" in order (§4.2.5 p.140).
4. **While a rollover is pending, no new message is started**: Slot 0 of a rollover protocol flit carries no message (all Valid = 0). The rollover chunks occupy the slots required by §4.2.5; remaining slots are empty. *(The spec would also allow a new message in Slot 0 during rollover ≤ 3; rejected for determinism, D6b.)*
5. LLCRD: per simplification #9.
6. Header credit fields are filled on every protocol flit (§8.4); an all-data flit carries none.

### 8.7 MemWrPtl byte enables — [A] behavior, [B] scope (D7)
Spec [A]: BE = 1 in the header, and the 64 byte enables travel in one additional G0 "M2S Byte Enable" chunk (Figure 57) after the 4 data chunks. **Approved:** implement this exactly (5 chunks → rollover 2). The v1 proposal "BE = 0, byte enables not carried" was rejected: per §4.2.2 p.121 BE = 0 means the receiver regenerates all-ones byte enables, turning MemWrPtl into a full-line write.

### 8.8 credit_tracker parameters — [B] PROJECT DECISION – APPROVED (D8)
- Per side, two **sender counters** (channels this side transmits) and two **pending-return counters** (channels this side receives):

| DIRECTION | Sender counters | Pending-return counters |
|---|---|---|
| 0 (host / M2S Tx) | M2S Req, M2S RwD | S2M NDR, S2M DRS |
| 1 (device / S2M Tx) | S2M NDR, S2M DRS | M2S Req, M2S RwD |

- Sender counters: reset to 0, width 7 bits, saturate at CREDIT_MAX = 64; +N on a received credit field with bit3 = 1 for that channel; −1 per message sent; a send with counter 0 is blocked (`can_send = 0`). Fields with bit3 = 0 (CXL.cache) are silently discarded (§4.2.2 p.121; §4.2.7 p.146).
- Pending-return counters: reset to parameter RX_DEPTH (default 16), width 8 bits, saturate at PEND_MAX = 255; +1 per `buf_free` pulse; drained by greedy largest-first (simplification #12) by the value placed in the outgoing field when that field is consumed (`crd_taken`).

### 8.9 Direction handling — [B] PROJECT DECISION – APPROVED (D9)
One `flit_packer` and one `credit_tracker` module, each with `parameter int DIRECTION = 0` (0 = M2S, 1 = S2M).

### 8.10 Port lists — [B] PROJECT DECISION – APPROVED (D10)

**flit_packer** (`parameter DIRECTION = 0, MAX_CHUNKS = 8`)

| Port | Dir | Width | Meaning |
|---|---|---|---|
| clk | in | 1 | Clock, rising edge |
| rst_n | in | 1 | Active-low synchronous reset |
| msg_valid | in | 1 | A message is offered |
| msg_ready | out | 1 | Packer accepts the message this cycle (handshake = valid & ready) |
| msg_kind | in | 1 | DIRECTION 0: 0 = Req, 1 = RwD. DIRECTION 1: 0 = NDR, 1 = DRS |
| msg_opcode | in | 4 | Opcode (NDR/DRS use [2:0]; [3] must be 0) |
| msg_addr | in | 52 | Host physical address; Req packs [51:5], RwD packs [51:6] |
| msg_tag | in | 16 | Tag |
| msg_poison | in | 1 | Poison (RwD, DRS) |
| msg_byte_en | in | 64 | Byte enables (MemWrPtl only) |
| msg_data | in | 128×MAX_CHUNKS | Data chunks, chunk *i* at [128i+127:128i] |
| chunks_ovr_en | in | 1 | Testbench-only: use `chunks_ovr` instead of the natural chunk count |
| chunks_ovr | in | 4 | Testbench-only `data_chunks_total` (0..MAX_CHUNKS) |
| crd_req_field | in | 4 | Encoded ReqCrd from credit_tracker |
| crd_data_field | in | 4 | Encoded DataCrd |
| crd_rsp_field | in | 4 | Encoded RspCrd |
| crd_taken | out | 1 | Pulses when a header (protocol or LLCRD) carrying the crd_* fields is emitted |
| force_llcrd | in | 1 | Request an LLCRD; latched inside |
| flit_valid | out | 1 | A flit is presented |
| flit_ready | in | 1 | Downstream accepts the flit (handshake = valid & ready) |
| flit_out | out | 528 | The flit (layout §8.2) |
| flit_is_control | out | 1 | Flit is a control (LLCRD) flit |
| flit_is_alldata | out | 1 | Flit is an all-data flit (no header) |

**credit_tracker** (`parameter DIRECTION = 0, RX_DEPTH = 16, CREDIT_MAX = 64, PEND_MAX = 255`)

| Port | Dir | Width | Meaning |
|---|---|---|---|
| clk, rst_n | in | 1 | As above |
| tx_send | in | 2 | Pulse per sender channel (bit 0 = Req/NDR, bit 1 = RwD/DRS): one message sent |
| tx_credits_0 / tx_credits_1 | out | 7 | Current sender credit count per channel |
| can_send | out | 2 | Counter > 0 per sender channel |
| rx_crd_valid | in | 1 | A received header's credit fields are valid this cycle |
| rx_reqcrd / rx_datacrd / rx_rspcrd | in | 4 each | Credit fields from the received flit |
| buf_free | in | 2 | Pulse per receive channel: one buffer freed (bit 0 = Req/NDR, bit 1 = RwD/DRS) |
| crd_req_field / crd_data_field / crd_rsp_field | out | 4 each | Encoded fields to piggyback (§8.4) |
| crd_taken | in | 1 | The current fields were sent; subtract their values |
| crd_pending | out | 1 | Any pending-return counter > 0 |
| pend_0 / pend_1 | out | 8 | Pending-return counts (observability for the testbench) |

### 8.11 Test groups — [B] PROJECT DECISION – APPROVED (D11)
A — field/opcode packing; B — credit tracking; C — rollover (directed, `data_chunks_total` sweep); D — LLCRD injection; E — constrained-random.

### 8.12 Cycle-level behavior contract — [B] PROJECT DECISION – APPROVED (D13, D14)
The judge testbench compares the DUT with the golden model **every clock cycle**, so timing is part of the contract.

**Common:** single clock `clk`, rising-edge registers; `rst_n` is active-low and **synchronous** (sampled on the rising edge). While `rst_n = 0` all combinational outputs that signal an action (`msg_ready`, `crd_taken`) are 0.

**flit_packer.** State: output register (`flit_valid`, `flit_out`, `flit_is_control`, `flit_is_alldata`), rollover buffer (remaining chunk count `rem`), LLCRD latch `lat`. Reset: `flit_valid = 0`, all flit outputs 0, `rem = 0`, `lat = 0`.
- `slot_free = !flit_valid || flit_ready` (the output register can take a new flit at the next edge).
- `llcrd_eff = lat || force_llcrd`.
- `msg_ready = rst_n && slot_free && rem == 0 && !llcrd_eff` (does not depend on `msg_valid`).
- When `slot_free`, the next flit is chosen by strict priority: (1) `rem > 0` → rollover flit; (2) `llcrd_eff` → LLCRD flit, `lat` cleared; (3) `msg_valid` → first flit of the message (handshake); (4) none → `flit_valid` becomes 0.
- When `!slot_free` the output register holds; `lat` captures `llcrd_eff`. In cases (1) and (3) `lat` also captures `llcrd_eff`.
- `crd_taken = 1` in a cycle where `slot_free` and the chosen flit carries a header: case (2), case (3), or case (1) when `rem ≤ 3` (protocol rollover flit). Never for an all-data flit.
- The `crd_*_field` inputs are copied into the header of the chosen flit in that same cycle.
- Rollover flit: `rem > 3` → all-data flit with the next 4 chunks, `rem -= 4`; else protocol flit with the `rem` chunks in Slots 1.., `rem = 0`.

**credit_tracker.** State: two sender counters `snd[i]`, two pending counters `pend[i]`. Reset: `snd = 0`, `pend = RX_DEPTH`.
- `can_send[i] = snd[i] != 0`; `crd_*_field` and `crd_pending` are combinational from `pend` (§8.4, greedy).
- Next state: `snd[i] ← min(snd[i] − (tx_send[i] && snd[i] != 0) + add[i], CREDIT_MAX)`, where `add[i]` is the decoded count of the received field mapped to channel *i* when `rx_crd_valid` and the field's bit 3 = 1 (otherwise 0).
- `pend[i] ← min(pend[i] − (crd_taken ? value(field_i) : 0) + buf_free[i], PEND_MAX)`.

Received-field mapping: DIRECTION 0 (host) — sender ch0 = M2S Req ← `rx_reqcrd`, ch1 = M2S RwD ← `rx_datacrd`; pending ch0 = S2M NDR → `crd_rsp_field`, ch1 = S2M DRS → `crd_data_field`; `crd_req_field = 0000`. DIRECTION 1 (device) — sender ch0 = S2M NDR ← `rx_rspcrd`, ch1 = S2M DRS ← `rx_datacrd`; pending ch0 = M2S Req → `crd_req_field`, ch1 = M2S RwD → `crd_data_field`; `crd_rsp_field = 0000`.

**Chunk list of a message** (MAX_CHUNKS = 8): if `chunks_ovr_en`, chunks `0..chunks_ovr−1` are taken from `msg_data` (0 ≤ `chunks_ovr` ≤ 8). Otherwise: Req/NDR → none; RwD MemWr / DRS → `msg_data` chunks 0–3; RwD MemWrPtl → chunks 0–3 then the BE chunk `{64'b0, msg_byte_en}` (Figure 57). Header Sz = 1 for RwD/DRS, else 0; BE = 1 only for RwD MemWrPtl. The override changes only the chunk list, never the header fields.

---

## 9. Width self-check

| Item | Sum | Claimed | OK |
|---|---|---|---|
| Header | 1+1+1+1+1+3+3+3+3+3+4+4+4 = 32 (Type, RV, Ak, BE, Sz, Slot0–3, RSVD[3], Rsp, Req, Data) | 32 | ✔ |
| M2S Req | 1+4+3+2+2+16+47+2+4+6 = 87 | 87 | ✔ |
| M2S RwD | 1+4+3+2+2+16+46+1+2+4+6 = 87 | 87 | ✔ |
| S2M NDR | 1+3+2+2+16+4+2 = 30 | 30 | ✔ |
| S2M DRS | 1+3+2+2+16+1+4+2+9 = 40 | 40 | ✔ |
| Slot 0 H5/H4 | 32 + 87 + 9 pad = 128 | 128 | ✔ |
| Slot 0 H3 | 32 + 40 + 30 + 26 pad = 128 | 128 | ✔ |
| LLCRD Slot 0 | 32 + 4 + 4 + 24 + 64 = 128 | 128 | ✔ |
| BE chunk | 64 + 64 RSVD = 128 | 128 | ✔ |
| Flit | 4 × 128 + 16 = 528 | 528 | ✔ |
