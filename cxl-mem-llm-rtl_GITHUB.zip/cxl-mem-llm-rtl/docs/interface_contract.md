# DUT Interface Contract

Source: `docs/spec/design_spec_v2.md` §8.10 (ports) and §8.12 (cycle behavior). Any RTL judged by this testbench — the known-good reference and every LLM-generated variant — **must** expose exactly these modules, parameters and ports. Port names used by the testbench live in one file: `tb/dut_ports.py`.

Language: SystemVerilog compatible with Icarus Verilog `-g2012`. Single clock, rising edge. Active-low **synchronous** reset.

## Module `flit_packer`

```systemverilog
module flit_packer #(
  parameter int DIRECTION  = 0,   // 0 = M2S (host Tx), 1 = S2M (device Tx)
  parameter int MAX_CHUNKS = 8
) ( ... );
```

| Port | Dir | Width | Meaning | Spec |
|---|---|---|---|---|
| clk | in | 1 | Clock | — |
| rst_n | in | 1 | Synchronous active-low reset | §8.12 |
| msg_valid | in | 1 | Message offered | §8.10 |
| msg_ready | out | 1 | Message accepted this cycle (comb.) | §8.12 |
| msg_kind | in | 1 | DIR0: 0 Req, 1 RwD. DIR1: 0 NDR, 1 DRS | §8.10 |
| msg_opcode | in | 4 | Opcode (S2M uses [2:0]) | §3 |
| msg_addr | in | 52 | Address; Req packs [51:5], RwD packs [51:6]; ignored for S2M | §2.3, §2.4 |
| msg_tag | in | 16 | Tag | §2 |
| msg_poison | in | 1 | Poison (RwD, DRS) | §2.4, §2.5 |
| msg_byte_en | in | 64 | Byte enables (MemWrPtl) | §1.4, §8.7 |
| msg_data | in | 128·MAX_CHUNKS | Chunk *i* at [128i+127:128i] | §1.4 |
| chunks_ovr_en | in | 1 | Testbench-only chunk-count override enable | §5 #10 |
| chunks_ovr | in | 4 | Override `data_chunks_total` (0..8) | §5 #10 |
| crd_req_field | in | 4 | ReqCrd value to place in the header | §8.4 |
| crd_data_field | in | 4 | DataCrd value | §8.4 |
| crd_rsp_field | in | 4 | RspCrd value | §8.4 |
| crd_taken | out | 1 | A header carrying crd_* is being emitted (comb.) | §8.12 |
| force_llcrd | in | 1 | LLCRD request, latched | §4.3, §8.12 |
| flit_valid | out | 1 | Flit presented (registered) | §8.12 |
| flit_ready | in | 1 | Flit consumed | §8.12 |
| flit_out | out | 528 | Flit; Slot k = [128k+127:128k], CRC [527:512] | §8.2 |
| flit_is_control | out | 1 | LLCRD flit | §8.10 |
| flit_is_alldata | out | 1 | All-data flit | §5 #14 |

## Module `credit_tracker`

```systemverilog
module credit_tracker #(
  parameter int DIRECTION  = 0,   // 0 = host side, 1 = device side
  parameter int RX_DEPTH   = 16,
  parameter int CREDIT_MAX = 64,
  parameter int PEND_MAX   = 255
) ( ... );
```

| Port | Dir | Width | Meaning | Spec |
|---|---|---|---|---|
| clk | in | 1 | Clock | — |
| rst_n | in | 1 | Synchronous active-low reset | §8.12 |
| tx_send | in | 2 | One message sent on sender channel 0/1 | §8.8 |
| tx_credits_0 | out | 7 | Sender credits ch0 (DIR0 M2S Req, DIR1 S2M NDR) | §8.8 |
| tx_credits_1 | out | 7 | Sender credits ch1 (DIR0 M2S RwD, DIR1 S2M DRS) | §8.8 |
| can_send | out | 2 | `tx_credits_i != 0` | §8.8 |
| rx_crd_valid | in | 1 | Received header's credit fields valid | §8.12 |
| rx_reqcrd | in | 4 | Received ReqCrd | Table 48/49 |
| rx_datacrd | in | 4 | Received DataCrd | Table 48/49 |
| rx_rspcrd | in | 4 | Received RspCrd | Table 48/49 |
| buf_free | in | 2 | One receive buffer freed on receive channel 0/1 | §8.8 |
| crd_req_field | out | 4 | Outgoing ReqCrd | §8.4 |
| crd_data_field | out | 4 | Outgoing DataCrd | §8.4 |
| crd_rsp_field | out | 4 | Outgoing RspCrd | §8.4 |
| crd_taken | in | 1 | Outgoing fields were used this cycle | §8.12 |
| crd_pending | out | 1 | Any pending counter > 0 | §4.3 |
| pend_0 | out | 8 | Pending-return ch0 (DIR0 S2M NDR, DIR1 M2S Req) | §8.8 |
| pend_1 | out | 8 | Pending-return ch1 (DIR0 S2M DRS, DIR1 M2S RwD) | §8.8 |

## Timing rules (summary of v2 §8.12)
- Outputs marked *comb.* must reflect the **current** cycle's inputs and state (checked just after inputs change, before the next rising edge).
- `flit_*` outputs are registered: they change only on a rising edge.
- Credit-tracker counters change only on a rising edge; field outputs are combinational from counters.
- Every output is compared with the golden model every cycle, from the first cycle after reset onward.
